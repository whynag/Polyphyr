using System;
using System.IO;
using System.Linq;
using Godot;
using Polyphyr.Core;
using Polyphyr.Core.Storage;
using Polyphyr.Core.Text;

namespace Polyphyr.Dev;

/// <summary>
/// Run dev/core_self_test.tscn to exercise the core model and folder storage end to end.
/// Prints PASS/FAIL lines and quits. Uses a scratch workspace under user://, never your real data.
/// </summary>
public partial class CoreSelfTest : Node
{
    private int _checks;
    private int _failures;

    public override void _Ready()
    {
        try
        {
            Run();
            RunTextTests();
        }
        catch (Exception e)
        {
            _failures++;
            GD.PrintErr($"SELFTEST EXCEPTION: {e}");
        }

        if (_failures == 0) GD.Print($"SELFTEST PASS ({_checks} checks)");
        else GD.PrintErr($"SELFTEST FAIL ({_failures} of {_checks} checks failed)");
        GetTree().Quit(_failures == 0 ? 0 : 1);
    }

    private void Check(bool condition, string label)
    {
        _checks++;
        if (condition) return;
        _failures++;
        GD.PrintErr($"FAIL: {label}");
    }

    private void Run()
    {
        var root = ProjectSettings.GlobalizePath("user://selftest_workspace");
        if (Directory.Exists(root)) Directory.Delete(root, recursive: true);

        // --- Create and save ---
        var (ws, store) = FolderWorkspaceStore.CreateNew(root, "Test", "Alice");
        Check(FolderWorkspaceStore.Exists(root), "workspace.json written");
        Check(ws.Board.Columns.Count == 3, "three default columns");
        Check(ws.Flowcharts.Count == 1, "one default flowchart");
        Check(!ws.Pending.HasChanges, "nothing pending after save");

        var todo = ws.Board.Columns[0].Id;
        var done = ws.Board.Columns[2].Id;
        var alice = ws.CurrentUser;

        // --- Cards ---
        var a = ws.NewCard(todo, "Design login");
        var b = ws.NewCard(todo, "Build login");
        Check(ws.Cards[a].Meta.CreatedBy == alice, "card authored by current user");
        Check(ws.Cards[a].Number == 1 && ws.Cards[b].Number == 2, "cards are numbered in order");
        Check(Workspace.KeyOf(ws.Cards[b]) == "TASK-2", "card key format");
        Check(ws.Apply(new MoveCard(b, done, 0)), "move card");
        Check(ws.GetColumnOf(b)?.Id == done, "card is in Done");
        Check(!ws.Apply(new SetCardTitle(CardId.New(), "nope")), "editing a missing card is a no-op");
        Check(!ws.Apply(new SetCardTitle(a, "Design login")), "setting the same title is a no-op");

        var bob = UserId.New();
        Check(ws.Apply(new AddUser(bob, "Bob", "#E85D75")), "add second user");
        Check(ws.Apply(new AssignUser(a, bob)), "assign Bob");

        // --- Notes ---
        var note = ws.NewNote("Login: plan?");
        Check(ws.Notes[note].FileName == "Login_ plan_.md", $"note file name sanitized (got '{ws.Notes[note].FileName}')");
        ws.Apply(new SetNoteText(note, "# Plan\n- step one\n= check it\n*bold* //italic// --gone--"));
        Check(ws.Apply(new AttachToCard(a, Attachment.Of(note))), "attach note");

        // --- Sheets ---
        var sheet = ws.NewSheet("Estimates", 20, 5);
        ws.Apply(new SetSheetCell(sheet, 2, 3, "*3 days*"));
        ws.Apply(new SetSheetColumnWidth(sheet, 1, 180f));
        Check(ws.Apply(new AttachToCard(a, Attachment.Of(sheet))), "attach sheet");

        // --- Images ---
        var image = store.ImportImage(ws, ProjectSettings.GlobalizePath("res://icon.svg"));
        Check(File.Exists(store.GetImagePath(image)), "image copied into workspace");
        Check(ws.Apply(new AttachToCard(a, Attachment.Of(image.Id))), "attach image");
        Check(ws.Cards[a].CoverImage == image.Id, "first attached image becomes the cover");

        // --- Flowchart ---
        var flow = ws.Flowcharts.Keys.First();
        var start = ws.NewFlowNode(flow, FlowShape.Terminal, 100, 50, "Start");
        var check = ws.NewFlowNode(flow, FlowShape.Decision, 400, 50, "Ready?");
        Check(ws.Apply(new SetFlowNodeColor(flow, check, "#3fb950")), "recolor node");
        var edge = ws.Connect(flow, start, FlowSide.Right, check, FlowSide.Left, "then");
        Check(!edge.IsEmpty, "connect nodes");
        Check(ws.Connect(flow, start, FlowSide.Right, check, FlowSide.Left).IsEmpty, "duplicate connection rejected");
        Check(!ws.Connect(flow, start, FlowSide.Bottom, check, FlowSide.Top).IsEmpty, "same nodes, other sides allowed");

        store.Save(ws);

        // --- Reload and compare ---
        var reloaded = store.Load();
        reloaded.CurrentUser = alice;
        Check(reloaded.Cards.Count == 2, "cards reloaded");
        Check(reloaded.Cards[b].Number == 2, "card number reloaded");
        Check(reloaded.GetColumnOf(b)?.Id == done, "board position reloaded");
        Check(reloaded.Cards[a].Assignees.Contains(bob), "assignee reloaded");
        Check(reloaded.Cards[a].Attachments.Count == 3, "attachments reloaded");
        Check(reloaded.Cards[a].CoverImage == image.Id, "cover reloaded");
        Check(reloaded.Notes[note].Text.StartsWith("# Plan"), "note text reloaded from .md");
        Check(reloaded.Sheets[sheet].GetCell(2, 3) == "*3 days*", "sheet cell reloaded");
        Check(reloaded.Sheets[sheet].ColumnWidths[1] == 180f, "column width reloaded");
        Check(reloaded.Flowcharts[flow].Nodes[check].X == 400f, "node position reloaded");
        Check(reloaded.Flowcharts[flow].Nodes[check].Shape == FlowShape.Decision, "node shape reloaded");
        Check(reloaded.Flowcharts[flow].Nodes[check].Color == "#3fb950", "node color reloaded");
        Check(reloaded.Flowcharts[flow].Edges.Count == 2, "edges reloaded");
        Check(!reloaded.Pending.HasChanges, "clean after load");

        // --- Rename and delete clean up files ---
        var oldNotePath = Path.Combine(root, "notes", reloaded.Notes[note].FileName);
        reloaded.Apply(new RenameNote(note, "Login plan"));
        store.Save(reloaded);
        Check(!File.Exists(oldNotePath), "old note file removed after rename");
        Check(File.Exists(Path.Combine(root, "notes", "Login plan.md")), "renamed note file exists");

        reloaded.Apply(new DeleteNote(note));
        reloaded.Apply(new DeleteCard(b));
        store.Save(reloaded);
        Check(!File.Exists(Path.Combine(root, "notes", "Login plan.md")), "deleted note file removed");
        Check(reloaded.Cards[a].Attachments.All(x => x.Kind != AttachmentKind.Note), "deleted note detached from card");
        reloaded.Apply(new RemoveFlowNode(flow, check));
        Check(reloaded.Flowcharts[flow].Edges.Count == 0, "removing a node removes its arrows");

        // --- Change serialization (groundwork for sync) ---
        var change = reloaded.History[^1];
        var roundTrip = ChangeJson.Deserialize(ChangeJson.Serialize(change));
        Check(roundTrip is DeleteCard d && d.Card == b && d.Author == alice, "change round-trips through JSON");

        Directory.Delete(root, recursive: true);
    }

    // ------------------------------------------------------------------
    // Formatting parser and text document
    // ------------------------------------------------------------------

    /// <summary>Returns the visible (non-marker) characters that have the given style.</summary>
    private static string Styled(string line, InlineStyle style)
    {
        var p = MarkupParser.Parse(line);
        var sb = new System.Text.StringBuilder();
        for (int i = 0; i < line.Length; i++)
            if ((p.Styles[i] & style) != 0 && (p.Styles[i] & InlineStyle.Marker) == 0) sb.Append(line[i]);
        return sb.ToString();
    }

    private void RunTextTests()
    {
        // Blocks
        var h2 = MarkupParser.Parse("## Plan");
        Check(h2.Kind == BlockKind.Heading && h2.HeadingLevel == 2 && h2.ContentStart == 3, "## is a level-2 heading");
        Check(MarkupParser.Parse("#nospace").Kind == BlockKind.Paragraph, "# needs a space to be a heading");
        Check(MarkupParser.Parse("#### four").Kind == BlockKind.Paragraph, "only three heading levels");
        var bullet = MarkupParser.Parse("  - item");
        Check(bullet.Kind == BlockKind.Bullet && bullet.IndentLength == 2 && bullet.ContentStart == 4, "indented bullet");
        var box = MarkupParser.Parse("= todo");
        Check(box.Kind == BlockKind.Checkbox && !box.Checked, "= is an unchecked checkbox");
        var done = MarkupParser.Parse("=x done");
        Check(done.Kind == BlockKind.Checkbox && done.Checked && done.ContentStart == 3, "=x is a checked checkbox");
        Check(MarkupParser.Parse("--strike--").Kind == BlockKind.Paragraph, "--text-- at line start is not a bullet");

        // Inline styles
        Check(Styled("a *bold* b", InlineStyle.Bold) == "bold", "*bold*");
        Check(Styled("a //it// b", InlineStyle.Italic) == "it", "//italic//");
        Check(Styled("a _under_ b", InlineStyle.Underline) == "under", "_underline_");
        Check(Styled("a --gone-- b", InlineStyle.Strike) == "gone", "--strike--");
        Check(Styled("a `x*y*z` b", InlineStyle.Code) == "x*y*z", "`code` content");
        Check(Styled("a `x*y*z` b", InlineStyle.Bold) == "", "no formatting inside code");
        Check(Styled("*bold //both//*", InlineStyle.Italic) == "both" && Styled("*bold //both//*", InlineStyle.Bold) == "bold both", "nested styles");

        // Things that must stay plain
        Check(Styled("--text-text-", InlineStyle.Strike) == "", "--text-text- is not struck");
        Check(Styled("see https://example.com and //x//", InlineStyle.Italic) == "x", "only the real //x// is italic, not the URL");
        Check(Styled("go to https://example.com now", InlineStyle.Italic) == "", "URL is not italic");
        Check(Styled("10/17/26 and a/b/c", InlineStyle.Italic) == "", "dates and paths are not italic");
        Check(Styled("my_snake_case_name", InlineStyle.Underline) == "", "snake_case is not underlined");
        Check(Styled("2*3*4", InlineStyle.Bold) == "", "multiplication is not bold");
        Check(Styled("a * b * c", InlineStyle.Bold) == "", "spaced asterisks are not bold");
        Check(Styled("well-known--thing", InlineStyle.Strike) == "", "hyphenated words are not struck");
        Check(Styled(@"\*literal\*", InlineStyle.Bold) == "", "escaped markers stay literal");

        // Document editing and undo
        var doc = new TextDocument();
        doc.SetText("hello\nworld");
        Check(doc.LineCount == 2 && doc[1] == "world", "document splits lines");
        var end = doc.Replace(new TextPos(0, 5), new TextPos(0, 5), "!\nnew", new TextPos(0, 5));
        Check(doc.GetText() == "hello!\nnew\nworld" && end == new TextPos(1, 3), "insert with newline");
        doc.Replace(new TextPos(0, 2), new TextPos(2, 2), "", end);
        Check(doc.GetText() == "herld", "delete across lines");
        doc.Undo();
        Check(doc.GetText() == "hello!\nnew\nworld", "undo delete");
        doc.Undo();
        Check(doc.GetText() == "hello\nworld", "undo insert");
        doc.Redo();
        Check(doc.GetText() == "hello!\nnew\nworld", "redo");

        var typing = new TextDocument();
        var caret = new TextPos(0, 0);
        foreach (char ch in "abc") caret = typing.Replace(caret, caret, ch.ToString(), caret, mergeable: true);
        typing.Undo();
        Check(typing.GetText() == "", "consecutive typing undoes as one step");
    }
}
