using System;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace Polyphyr.Core;

/// <summary>
/// A Guid wrapped in its own type, so a CardId can never be passed where a NoteId is expected.
/// IDs are permanent and globally unique, which is what lets changes from different users merge later.
/// </summary>
public interface IStronglyTypedId<TSelf> where TSelf : struct, IStronglyTypedId<TSelf>
{
    Guid Value { get; }
    static abstract TSelf From(Guid value);
}

/// <summary>Writes IDs as plain Guid strings in JSON, both as values and as dictionary keys.</summary>
public sealed class IdJsonConverter<T> : JsonConverter<T> where T : struct, IStronglyTypedId<T>
{
    public override T Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
        => T.From(reader.GetGuid());

    public override void Write(Utf8JsonWriter writer, T value, JsonSerializerOptions options)
        => writer.WriteStringValue(value.Value);

    public override T ReadAsPropertyName(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
        => T.From(Guid.Parse(reader.GetString() ?? throw new JsonException("Missing ID.")));

    public override void WriteAsPropertyName(Utf8JsonWriter writer, T value, JsonSerializerOptions options)
        => writer.WritePropertyName(value.Value.ToString("D"));
}

[JsonConverter(typeof(IdJsonConverter<UserId>))]
public readonly record struct UserId(Guid Value) : IStronglyTypedId<UserId>
{
    public static UserId New() => new(Guid.NewGuid());
    public static UserId From(Guid value) => new(value);
    public bool IsEmpty => Value == Guid.Empty;
    public override string ToString() => Value.ToString("N");
}

[JsonConverter(typeof(IdJsonConverter<CardId>))]
public readonly record struct CardId(Guid Value) : IStronglyTypedId<CardId>
{
    public static CardId New() => new(Guid.NewGuid());
    public static CardId From(Guid value) => new(value);
    public bool IsEmpty => Value == Guid.Empty;
    public override string ToString() => Value.ToString("N");
}

[JsonConverter(typeof(IdJsonConverter<ColumnId>))]
public readonly record struct ColumnId(Guid Value) : IStronglyTypedId<ColumnId>
{
    public static ColumnId New() => new(Guid.NewGuid());
    public static ColumnId From(Guid value) => new(value);
    public bool IsEmpty => Value == Guid.Empty;
    public override string ToString() => Value.ToString("N");
}

[JsonConverter(typeof(IdJsonConverter<NoteId>))]
public readonly record struct NoteId(Guid Value) : IStronglyTypedId<NoteId>
{
    public static NoteId New() => new(Guid.NewGuid());
    public static NoteId From(Guid value) => new(value);
    public bool IsEmpty => Value == Guid.Empty;
    public override string ToString() => Value.ToString("N");
}

[JsonConverter(typeof(IdJsonConverter<SheetId>))]
public readonly record struct SheetId(Guid Value) : IStronglyTypedId<SheetId>
{
    public static SheetId New() => new(Guid.NewGuid());
    public static SheetId From(Guid value) => new(value);
    public bool IsEmpty => Value == Guid.Empty;
    public override string ToString() => Value.ToString("N");
}

[JsonConverter(typeof(IdJsonConverter<ImageId>))]
public readonly record struct ImageId(Guid Value) : IStronglyTypedId<ImageId>
{
    public static ImageId New() => new(Guid.NewGuid());
    public static ImageId From(Guid value) => new(value);
    public bool IsEmpty => Value == Guid.Empty;
    public override string ToString() => Value.ToString("N");
}

[JsonConverter(typeof(IdJsonConverter<FlowchartId>))]
public readonly record struct FlowchartId(Guid Value) : IStronglyTypedId<FlowchartId>
{
    public static FlowchartId New() => new(Guid.NewGuid());
    public static FlowchartId From(Guid value) => new(value);
    public bool IsEmpty => Value == Guid.Empty;
    public override string ToString() => Value.ToString("N");
}

[JsonConverter(typeof(IdJsonConverter<NodeId>))]
public readonly record struct NodeId(Guid Value) : IStronglyTypedId<NodeId>
{
    public static NodeId New() => new(Guid.NewGuid());
    public static NodeId From(Guid value) => new(value);
    public bool IsEmpty => Value == Guid.Empty;
    public override string ToString() => Value.ToString("N");
}

[JsonConverter(typeof(IdJsonConverter<EdgeId>))]
public readonly record struct EdgeId(Guid Value) : IStronglyTypedId<EdgeId>
{
    public static EdgeId New() => new(Guid.NewGuid());
    public static EdgeId From(Guid value) => new(value);
    public bool IsEmpty => Value == Guid.Empty;
    public override string ToString() => Value.ToString("N");
}

[JsonConverter(typeof(IdJsonConverter<ChangeId>))]
public readonly record struct ChangeId(Guid Value) : IStronglyTypedId<ChangeId>
{
    public static ChangeId New() => new(Guid.NewGuid());
    public static ChangeId From(Guid value) => new(value);
    public bool IsEmpty => Value == Guid.Empty;
    public override string ToString() => Value.ToString("N");
}
