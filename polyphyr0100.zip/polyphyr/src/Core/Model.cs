using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Polyphyr.Core;

/// <summary>Who created and last edited an item, and when.</summary>
public sealed class ItemMeta
{
    public UserId CreatedBy { get; set; }
    public DateTimeOffset CreatedAt { get; set; }
    public UserId ModifiedBy { get; set; }
    public DateTimeOffset ModifiedAt { get; set; }

    public static ItemMeta Create(UserId by, DateTimeOffset at)
        => new() { CreatedBy = by, CreatedAt = at, ModifiedBy = by, ModifiedAt = at };

    public void Touch(UserId by, DateTimeOffset at)
    {
        ModifiedBy = by;
        ModifiedAt = at;
    }
}

public sealed class User
{
    public UserId Id { get; set; }
    public string DisplayName { get; set; } = "";
    /// <summary>Hex color used for avatars and authorship highlights, e.g. "#4F8CFF".</summary>
    public string Color { get; set; } = "#4F8CFF";
    public DateTimeOffset CreatedAt { get; set; }
}

[JsonConverter(typeof(JsonStringEnumConverter<Priority>))]
/// <summary>Card priority. Urgent is shown as "Highest". Lowest was added later, so it comes last.</summary>
public enum Priority { None, Low, Medium, High, Urgent, Lowest }

[JsonConverter(typeof(JsonStringEnumConverter<AttachmentKind>))]
public enum AttachmentKind { Note, Sheet, Image }

/// <summary>A link from a card to a note, sheet or image.</summary>
public readonly record struct Attachment(AttachmentKind Kind, Guid TargetId)
{
    public static Attachment Of(NoteId id) => new(AttachmentKind.Note, id.Value);
    public static Attachment Of(SheetId id) => new(AttachmentKind.Sheet, id.Value);
    public static Attachment Of(ImageId id) => new(AttachmentKind.Image, id.Value);
}

/// <summary>
/// The Jira-style work item. Which column it sits in is stored only on the board,
/// so a card can never disagree with the board about its status.
/// </summary>
public sealed class Card
{
    public CardId Id { get; set; }
    /// <summary>Short sequential number for the card's key, e.g. 14 for TASK-14.</summary>
    public int Number { get; set; }
    public string Title { get; set; } = "";
    /// <summary>Short description in the note formatting syntax.</summary>
    public string Description { get; set; } = "";
    public Priority Priority { get; set; }
    public DateOnly? DueDate { get; set; }
    public List<UserId> Assignees { get; set; } = new();
    public List<string> Tags { get; set; } = new();
    public List<Attachment> Attachments { get; set; } = new();
    /// <summary>Image shown as the background of this card's flowchart node.</summary>
    public ImageId? CoverImage { get; set; }
    public ItemMeta Meta { get; set; } = new();
}

public sealed class BoardColumn
{
    public ColumnId Id { get; set; }
    public string Name { get; set; } = "";
    /// <summary>Cards in this column, top to bottom.</summary>
    public List<CardId> Cards { get; set; } = new();
}

public sealed class Board
{
    public List<BoardColumn> Columns { get; set; } = new();
}

/// <summary>A markdown note. The text lives in its own .md file; everything else lives in workspace.json.</summary>
public sealed class Note
{
    public NoteId Id { get; set; }
    public string Title { get; set; } = "";
    /// <summary>File name inside the notes folder, e.g. "Sprint plan.md".</summary>
    public string FileName { get; set; } = "";
    public ItemMeta Meta { get; set; } = new();

    [JsonIgnore] public string Text { get; set; } = "";
}

public readonly record struct CellRef(int Row, int Column);

/// <summary>Which color of a cell a style change sets.</summary>
[JsonConverter(typeof(JsonStringEnumConverter<CellStylePart>))]
public enum CellStylePart { Fill, Text, Outline }

/// <summary>A cell's colors as "#rrggbb" (or "#rrggbbaa"); null means the default.</summary>
public sealed record CellStyle(string? Fill, string? Text, string? Outline)
{
    public bool IsEmpty => Fill is null && Text is null && Outline is null;

    public CellStyle With(CellStylePart part, string? color) => part switch
    {
        CellStylePart.Fill => this with { Fill = color },
        CellStylePart.Text => this with { Text = color },
        _ => this with { Outline = color },
    };
}

/// <summary>
/// A note-style grid. Each cell holds text in the note formatting syntax.
/// Cells are stored sparsely, so a huge mostly-empty sheet costs almost nothing.
/// </summary>
public sealed class Sheet
{
    public SheetId Id { get; set; }
    public string Title { get; set; } = "";
    public ItemMeta Meta { get; set; } = new();

    // Content below is saved in the sheet's own file, not in workspace.json.
    [JsonIgnore] public int RowCount { get; set; } = 50;
    [JsonIgnore] public int ColumnCount { get; set; } = 10;
    [JsonIgnore] public Dictionary<int, float> ColumnWidths { get; } = new();
    [JsonIgnore] public Dictionary<CellRef, string> Cells { get; } = new();
    /// <summary>Per-cell colors (only cells that have any).</summary>
    [JsonIgnore] public Dictionary<CellRef, CellStyle> Styles { get; } = new();

    public string GetCell(int row, int column)
        => Cells.TryGetValue(new CellRef(row, column), out var text) ? text : "";
}

public sealed class ImageAsset
{
    public ImageId Id { get; set; }
    /// <summary>File name inside the images folder, e.g. "3f2a9c0d.png".</summary>
    public string FileName { get; set; } = "";
    /// <summary>The name the file had when it was imported, for display.</summary>
    public string OriginalName { get; set; } = "";
    public ItemMeta Meta { get; set; } = new();
}

[JsonConverter(typeof(JsonStringEnumConverter<FlowShape>))]
/// <summary>Flowchart node shapes: rounded terminal, square process, diamond decision, and delay (flat left, round right).</summary>
public enum FlowShape { Terminal, Process, Decision, Delay }

[JsonConverter(typeof(JsonStringEnumConverter<FlowSide>))]
/// <summary>Which side of a node a connection leaves from or arrives at.</summary>
public enum FlowSide { Top, Right, Bottom, Left }

/// <summary>A shape on a flowchart. Position and size are free-form, in canvas pixels.</summary>
public sealed class FlowNode
{
    public NodeId Id { get; set; }
    public FlowShape Shape { get; set; }
    public string Text { get; set; } = "";
    /// <summary>Fill color as "#rrggbb"; null uses the shape's default.</summary>
    public string? Color { get; set; }
    public float X { get; set; }
    public float Y { get; set; }
    public float Width { get; set; } = 180f;
    public float Height { get; set; } = 80f;
    /// <summary>Optional task this node stands for.</summary>
    public CardId? Card { get; set; }
}

/// <summary>An arrow from one side of a node to a side of another.</summary>
public sealed class FlowEdge
{
    public EdgeId Id { get; set; }
    public NodeId From { get; set; }
    public FlowSide FromSide { get; set; } = FlowSide.Right;
    public NodeId To { get; set; }
    public FlowSide ToSide { get; set; } = FlowSide.Left;
    public string Label { get; set; } = "";
}

/// <summary>One flowchart: shapes and the arrows between them.</summary>
public sealed class Flowchart
{
    public FlowchartId Id { get; set; }
    public string Name { get; set; } = "";
    public ItemMeta Meta { get; set; } = new();

    // Content below is saved in the flowchart's own file, not in workspace.json.
    [JsonIgnore] public Dictionary<NodeId, FlowNode> Nodes { get; } = new();
    [JsonIgnore] public List<FlowEdge> Edges { get; } = new();
}
