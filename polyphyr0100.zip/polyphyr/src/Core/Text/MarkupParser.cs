using System;
using System.Collections.Generic;

namespace Polyphyr.Core.Text;

public enum BlockKind : byte
{
    Paragraph,
    Heading,
    Bullet,
    Checkbox,
}

[Flags]
public enum InlineStyle : ushort
{
    None = 0,
    Bold = 1 << 0,
    Italic = 1 << 1,
    Underline = 1 << 2,
    Strike = 1 << 3,
    Code = 1 << 4,
    /// <summary>Formatting syntax (e.g. the * in *bold*). Hidden in preview, dimmed while editing.</summary>
    Marker = 1 << 5,
}

/// <summary>
/// A colored stretch of text: <c>{f=#hex t=#hex o=#hex|text}</c> (fill, text color, outline;
/// each optional). Indices are raw columns: <see cref="Open"/> is the "{", the content is
/// [<see cref="Start"/>, <see cref="End"/>) and <see cref="End"/> is the "}".
/// </summary>
public readonly record struct ColorSpan(int Open, int Start, int End, string? Fill, string? Text, string? Outline);

/// <summary>The result of parsing one line of note text.</summary>
public sealed class ParsedLine
{
    public BlockKind Kind { get; init; }
    /// <summary>1–3 for headings, otherwise 0.</summary>
    public int HeadingLevel { get; init; }
    public bool Checked { get; init; }
    /// <summary>Leading spaces/tabs.</summary>
    public int IndentLength { get; init; }
    /// <summary>Length of the block marker after the indent, including its space ("# ", "- ", "=x ").</summary>
    public int PrefixLength { get; init; }
    public int ContentStart => IndentLength + PrefixLength;
    /// <summary>Style of every character in the raw line.</summary>
    public InlineStyle[] Styles { get; init; } = Array.Empty<InlineStyle>();
    /// <summary>Colored spans, in order. They never nest.</summary>
    public ColorSpan[] Colors { get; init; } = Array.Empty<ColorSpan>();
}

/// <summary>
/// Parses the note syntax:
/// <code>
/// # / ## / ###    headings          - text   bullet
/// = text          checkbox          =x text  checked checkbox
/// *bold*  //italic//  _underline_  --strike--  `code`
/// {f=#4a3b12 t=#e3b341 o=#4f8cff|colored text}   (fill / text / outline, any of them)
/// </code>
/// Inline rules, which keep normal writing from being formatted by accident:
/// <list type="bullet">
/// <item>An opening marker must be followed by a non-space and come after a space, punctuation or the line start.</item>
/// <item>A closing marker must come after a non-space and be followed by a space, punctuation or the line end.</item>
/// <item>Doubled markers must match exactly, so --text-text- is not struck through.</item>
/// <item>// right after a colon is never italic, so https://… stays plain.</item>
/// <item>A backslash makes the next marker literal: \*not bold\*.</item>
/// <item>Nothing inside `code` is formatted.</item>
/// </list>
/// </summary>
public static class MarkupParser
{
    public static ParsedLine Parse(string line)
    {
        var styles = new InlineStyle[line.Length];

        int indent = 0;
        while (indent < line.Length && (line[indent] == ' ' || line[indent] == '\t')) indent++;

        var kind = BlockKind.Paragraph;
        int level = 0, prefix = 0;
        bool isChecked = false;
        var rest = line.AsSpan(indent);

        if (indent == 0 && TryHeading(rest, out level))
        {
            kind = BlockKind.Heading;
            prefix = level + 1;
        }
        else if (rest.StartsWith("- "))
        {
            kind = BlockKind.Bullet;
            prefix = 2;
        }
        else if (rest.StartsWith("=x ") || rest.StartsWith("=X "))
        {
            kind = BlockKind.Checkbox;
            isChecked = true;
            prefix = 3;
        }
        else if (rest.StartsWith("= "))
        {
            kind = BlockKind.Checkbox;
            prefix = 2;
        }

        for (int i = indent; i < indent + prefix; i++) styles[i] = InlineStyle.Marker;

        List<ColorSpan>? colors = null;
        ParseInline(line, indent + prefix, line.Length, InlineStyle.None, styles, ref colors, allowColor: true);

        return new ParsedLine
        {
            Kind = kind,
            HeadingLevel = level,
            Checked = isChecked,
            IndentLength = indent,
            PrefixLength = prefix,
            Styles = styles,
            Colors = colors?.ToArray() ?? Array.Empty<ColorSpan>(),
        };
    }

    private static bool TryHeading(ReadOnlySpan<char> s, out int level)
    {
        level = 0;
        while (level < s.Length && level < 4 && s[level] == '#') level++;
        if (level is >= 1 and <= 3 && level < s.Length && s[level] == ' ') return true;
        level = 0;
        return false;
    }

    // ------------------------------------------------------------------
    // Inline
    // ------------------------------------------------------------------

    private static void ParseInline(string s, int start, int end, InlineStyle inherited, InlineStyle[] styles,
        ref List<ColorSpan>? colors, bool allowColor)
    {
        int i = start;
        while (i < end)
        {
            char c = s[i];

            // Escape: \* \/ \_ \- \` \\
            if (c == '\\' && i + 1 < end && IsEscapable(s[i + 1]))
            {
                styles[i] = inherited | InlineStyle.Marker;
                styles[i + 1] = inherited;
                i += 2;
                continue;
            }

            // Code: `text`. Contents are literal.
            if (c == '`')
            {
                int close = s.IndexOf('`', i + 1, end - i - 1);
                if (close > i + 1)
                {
                    styles[i] = inherited | InlineStyle.Marker;
                    for (int k = i + 1; k < close; k++) styles[k] = inherited | InlineStyle.Code;
                    styles[close] = inherited | InlineStyle.Marker;
                    i = close + 1;
                    continue;
                }
            }

            // Color: {f=#.. t=#.. o=#..|text}
            if (c == '{' && allowColor && TryColorSpan(s, i, end, out var span))
            {
                for (int k = span.Open; k < span.Start; k++) styles[k] = inherited | InlineStyle.Marker;
                ParseInline(s, span.Start, span.End, inherited, styles, ref colors, allowColor: false);
                styles[span.End] = inherited | InlineStyle.Marker;
                (colors ??= new List<ColorSpan>()).Add(span);
                i = span.End + 1;
                continue;
            }

            if (TryGetMarker(s, i, end, out int len, out var style) && IsOpener(s, i, len, end))
            {
                int close = FindCloser(s, i + len, end, len, c);
                if (close >= 0)
                {
                    for (int k = i; k < i + len; k++) styles[k] = inherited | InlineStyle.Marker;
                    ParseInline(s, i + len, close, inherited | style, styles, ref colors, allowColor);
                    for (int k = close; k < close + len; k++) styles[k] = inherited | InlineStyle.Marker;
                    i = close + len;
                    continue;
                }
            }

            styles[i] = inherited;
            i++;
        }
    }

    private static bool IsEscapable(char c) => c is '*' or '/' or '_' or '-' or '`' or '\\' or '=' or '#' or '{' or '}';

    /// <summary>Parses "{f=#hex t=#hex o=#hex|" at i and finds the closing "}" (skipping escapes and code).</summary>
    private static bool TryColorSpan(string s, int i, int end, out ColorSpan span)
    {
        span = default;
        int bar = s.IndexOf('|', i + 1, end - i - 1);
        if (bar < 0 || bar - i > 64) return false;
        string? fill = null, text = null, outline = null;
        foreach (var part in s.AsSpan(i + 1, bar - i - 1).ToString().Split(' ', StringSplitOptions.RemoveEmptyEntries))
        {
            if (part.Length < 4 || part[1] != '=' || part[2] != '#' || !IsHex(part.AsSpan(3))) return false;
            string value = part[2..];
            switch (part[0])
            {
                case 'f': fill = value; break;
                case 't': text = value; break;
                case 'o': outline = value; break;
                default: return false;
            }
        }
        if (fill is null && text is null && outline is null) return false;

        for (int j = bar + 1; j < end; j++)
        {
            char ch = s[j];
            if (ch == '\\' && j + 1 < end && IsEscapable(s[j + 1])) { j++; continue; }
            if (ch == '`')
            {
                int close = s.IndexOf('`', j + 1, end - j - 1);
                if (close > j + 1) { j = close; continue; }
            }
            if (ch == '{') return false;          // no nesting
            if (ch != '}') continue;
            if (j == bar + 1) return false;       // needs some text
            span = new ColorSpan(i, bar + 1, j, fill, text, outline);
            return true;
        }
        return false;
    }

    private static bool IsHex(ReadOnlySpan<char> s)
    {
        if (s.Length is not (3 or 6 or 8)) return false;
        foreach (char ch in s)
            if (!Uri.IsHexDigit(ch)) return false;
        return true;
    }

    private static bool TryGetMarker(string s, int i, int end, out int len, out InlineStyle style)
    {
        char c = s[i];
        bool doubled = i + 1 < end && s[i + 1] == c;
        switch (c)
        {
            case '*': len = 1; style = InlineStyle.Bold; return true;
            case '_': len = 1; style = InlineStyle.Underline; return true;
            case '/' when doubled: len = 2; style = InlineStyle.Italic; return true;
            case '-' when doubled: len = 2; style = InlineStyle.Strike; return true;
            default: len = 0; style = InlineStyle.None; return false;
        }
    }

    private static bool IsOpener(string s, int i, int len, int end)
    {
        char c = s[i];
        int after = i + len;
        if (after >= end || char.IsWhiteSpace(s[after])) return false;
        if (len == 2 && s[after] == c) return false;             // "---", "///"
        if (i > 0)
        {
            char prev = s[i - 1];
            if (char.IsLetterOrDigit(prev)) return false;          // snake_case, 2*3
            if (len == 2 && prev == c) return false;               // exact pairs only
            if (c == '/' && prev == ':') return false;             // https://
        }
        return true;
    }

    /// <summary>Finds the first valid closing marker, skipping over code spans and escapes.</summary>
    private static int FindCloser(string s, int from, int end, int len, char c)
    {
        for (int j = from; j <= end - len; j++)
        {
            char ch = s[j];
            if (ch == '\\' && j + 1 < end && IsEscapable(s[j + 1])) { j++; continue; }
            if (ch == '`')
            {
                int close = s.IndexOf('`', j + 1, end - j - 1);
                if (close > j + 1) { j = close; continue; }
            }
            if (ch != c || (len == 2 && s[j + 1] != c)) continue;
            if (j == from || char.IsWhiteSpace(s[j - 1])) continue;          // needs content, no space before
            if (len == 2 && s[j - 1] == c) continue;                          // exact pairs only
            int after = j + len;
            if (after < s.Length)
            {
                char next = s[after];
                if (char.IsLetterOrDigit(next)) continue;                     // closer must end a word
                if (len == 2 && next == c) continue;
            }
            return j;
        }
        return -1;
    }
}
