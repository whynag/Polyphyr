using System;
using System.Collections.Generic;
using System.Text;

namespace Polyphyr.Core.Text;

/// <summary>A position in a document: line index and UTF-16 column within the line.</summary>
public readonly record struct TextPos(int Line, int Col) : IComparable<TextPos>
{
    public int CompareTo(TextPos other) => Line != other.Line ? Line.CompareTo(other.Line) : Col.CompareTo(other.Col);
    public static bool operator <(TextPos a, TextPos b) => a.CompareTo(b) < 0;
    public static bool operator >(TextPos a, TextPos b) => a.CompareTo(b) > 0;
    public static bool operator <=(TextPos a, TextPos b) => a.CompareTo(b) <= 0;
    public static bool operator >=(TextPos a, TextPos b) => a.CompareTo(b) >= 0;
    public static TextPos Min(TextPos a, TextPos b) => a <= b ? a : b;
    public static TextPos Max(TextPos a, TextPos b) => a >= b ? a : b;
}

/// <summary>
/// Editable text stored as a list of lines, so an edit only touches the lines it changes.
/// Every edit goes through <see cref="Replace"/>, which records it for undo/redo.
/// </summary>
public sealed class TextDocument
{
    private readonly List<string> _lines = new() { "" };
    private readonly List<Edit> _undo = new();
    private readonly List<Edit> _redo = new();
    private const int UndoLimit = 2000;
    private static readonly TimeSpan MergeWindow = TimeSpan.FromSeconds(1);

    /// <summary>One recorded edit: at Start, Removed was replaced by Inserted.</summary>
    private sealed class Edit
    {
        public TextPos Start;
        public string Removed = "";
        public string Inserted = "";
        public TextPos CaretBefore;
        public TextPos CaretAfter;
        public DateTime Time;
        public bool Mergeable;
    }

    /// <summary>
    /// Raised after every change with (first line, number of old lines removed, number of new lines inserted),
    /// so views can update only the affected lines.
    /// </summary>
    public event Action<int, int, int>? LinesReplaced;

    public int LineCount => _lines.Count;
    public string this[int line] => _lines[line];
    public bool CanUndo => _undo.Count > 0;
    public bool CanRedo => _redo.Count > 0;
    public TextPos End => new(_lines.Count - 1, _lines[^1].Length);

    public string GetText() => string.Join('\n', _lines);

    /// <summary>Replaces all text and clears undo history.</summary>
    public void SetText(string text)
    {
        int old = _lines.Count;
        _lines.Clear();
        _lines.AddRange(SplitLines(text));
        _undo.Clear();
        _redo.Clear();
        LinesReplaced?.Invoke(0, old, _lines.Count);
    }

    public TextPos Clamp(TextPos p)
    {
        int line = Math.Clamp(p.Line, 0, _lines.Count - 1);
        return new TextPos(line, Math.Clamp(p.Col, 0, _lines[line].Length));
    }

    public string GetRange(TextPos a, TextPos b)
    {
        (a, b) = (TextPos.Min(a, b), TextPos.Max(a, b));
        if (a.Line == b.Line) return _lines[a.Line].Substring(a.Col, b.Col - a.Col);
        var sb = new StringBuilder();
        sb.Append(_lines[a.Line], a.Col, _lines[a.Line].Length - a.Col);
        for (int i = a.Line + 1; i < b.Line; i++) sb.Append('\n').Append(_lines[i]);
        sb.Append('\n').Append(_lines[b.Line], 0, b.Col);
        return sb.ToString();
    }

    /// <summary>
    /// Replaces the text between two positions and returns the position just after the inserted text.
    /// <paramref name="mergeable"/> lets consecutive typing collapse into one undo step.
    /// </summary>
    public TextPos Replace(TextPos a, TextPos b, string text, TextPos caretBefore, bool mergeable = false)
    {
        a = Clamp(a);
        b = Clamp(b);
        if (a > b) (a, b) = (b, a);
        text = text.Replace("\r\n", "\n").Replace('\r', '\n');

        var removed = GetRange(a, b);
        if (removed.Length == 0 && text.Length == 0) return a;

        var end = ReplaceRaw(a, b, text);
        RecordEdit(new Edit
        {
            Start = a,
            Removed = removed,
            Inserted = text,
            CaretBefore = caretBefore,
            CaretAfter = end,
            Time = DateTime.UtcNow,
            Mergeable = mergeable,
        });
        return end;
    }

    /// <summary>Undoes the last edit and returns where the caret should go, or null if there's nothing to undo.</summary>
    public TextPos? Undo()
    {
        if (_undo.Count == 0) return null;
        var e = _undo[^1];
        _undo.RemoveAt(_undo.Count - 1);
        ReplaceRaw(e.Start, EndOf(e.Start, e.Inserted), e.Removed);
        _redo.Add(e);
        return e.CaretBefore;
    }

    public TextPos? Redo()
    {
        if (_redo.Count == 0) return null;
        var e = _redo[^1];
        _redo.RemoveAt(_redo.Count - 1);
        ReplaceRaw(e.Start, EndOf(e.Start, e.Removed), e.Inserted);
        _undo.Add(e);
        return e.CaretAfter;
    }

    /// <summary>Stops the next edit from merging into the previous undo step (e.g. after the caret moves).</summary>
    public void BreakUndoGroup()
    {
        if (_undo.Count > 0) _undo[^1].Mergeable = false;
    }

    // ------------------------------------------------------------------

    private void RecordEdit(Edit e)
    {
        _redo.Clear();
        if (e.Mergeable && _undo.Count > 0)
        {
            var last = _undo[^1];
            bool recent = e.Time - last.Time < MergeWindow;
            // Typing: the new insert starts exactly where the last insert ended, and nothing was removed.
            bool typing = last.Mergeable && last.Removed.Length == 0 && e.Removed.Length == 0
                          && EndOf(last.Start, last.Inserted) == e.Start
                          && !e.Inserted.Contains('\n');
            // Backspacing: the new delete ends exactly where the last delete started.
            bool backspacing = last.Mergeable && last.Inserted.Length == 0 && e.Inserted.Length == 0
                               && EndOf(e.Start, e.Removed) == last.Start;
            if (recent && typing)
            {
                last.Inserted += e.Inserted;
                last.CaretAfter = e.CaretAfter;
                last.Time = e.Time;
                return;
            }
            if (recent && backspacing)
            {
                last.Start = e.Start;
                last.Removed = e.Removed + last.Removed;
                last.CaretAfter = e.CaretAfter;
                last.Time = e.Time;
                return;
            }
        }
        _undo.Add(e);
        if (_undo.Count > UndoLimit) _undo.RemoveRange(0, _undo.Count - UndoLimit);
    }

    private TextPos ReplaceRaw(TextPos a, TextPos b, string text)
    {
        string head = _lines[a.Line].Substring(0, a.Col);
        string tail = _lines[b.Line].Substring(b.Col);
        int removedLines = b.Line - a.Line + 1;

        var parts = SplitLines(text);
        parts[0] = head + parts[0];
        int lastIndex = parts.Count - 1;
        int endCol = parts[lastIndex].Length;
        parts[lastIndex] += tail;

        _lines.RemoveRange(a.Line, removedLines);
        _lines.InsertRange(a.Line, parts);
        LinesReplaced?.Invoke(a.Line, removedLines, parts.Count);
        return new TextPos(a.Line + lastIndex, endCol);
    }

    private static TextPos EndOf(TextPos start, string text)
    {
        int lastNl = text.LastIndexOf('\n');
        if (lastNl < 0) return new TextPos(start.Line, start.Col + text.Length);
        int newlines = 0;
        foreach (char ch in text) if (ch == '\n') newlines++;
        return new TextPos(start.Line + newlines, text.Length - lastNl - 1);
    }

    private static List<string> SplitLines(string text)
        => new(text.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n'));
}
