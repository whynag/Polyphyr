// The chat feature was removed. This file is intentionally empty and can be deleted
// (along with ChatLog.cs.uid if Godot created one).
