using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Polyphyr.Core.Storage;

/// <summary>Contents of workspace.json: everything except note text, sheet cells and flowchart layouts.</summary>
internal sealed class WorkspaceFile
{
    public int FormatVersion { get; set; } = FolderWorkspaceStore.FormatVersion;
    public string Name { get; set; } = "";
    public List<User> Users { get; set; } = new();
    public Board Board { get; set; } = new();
    public List<Card> Cards { get; set; } = new();
    public List<Note> Notes { get; set; } = new();
    public List<Sheet> Sheets { get; set; } = new();
    public List<ImageAsset> Images { get; set; } = new();
    public List<Flowchart> Flowcharts { get; set; } = new();
}

/// <summary>Contents of sheets/&lt;id&gt;.json.</summary>
internal sealed class SheetFile
{
    public int RowCount { get; set; }
    public int ColumnCount { get; set; }
    public Dictionary<int, float> ColumnWidths { get; set; } = new();
    public List<CellEntry> Cells { get; set; } = new();
    public List<StyleEntry> Styles { get; set; } = new();
}

internal sealed record CellEntry(int Row, int Column, string Text);

internal sealed record StyleEntry(int Row, int Column, string? Fill, string? Text, string? Outline);

/// <summary>Contents of flowcharts/&lt;id&gt;.json.</summary>
internal sealed class FlowchartFile
{
    public List<FlowNode> Nodes { get; set; } = new();
    public List<FlowEdge> Edges { get; set; } = new();
}

/// <summary>
/// Compile-time generated JSON code: no reflection at runtime, so loading and saving are fast
/// and allocation-light.
/// </summary>
[JsonSourceGenerationOptions(WriteIndented = true, DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull)]
[JsonSerializable(typeof(WorkspaceFile))]
[JsonSerializable(typeof(SheetFile))]
[JsonSerializable(typeof(FlowchartFile))]
[JsonSerializable(typeof(Change))]
internal sealed partial class StorageJsonContext : JsonSerializerContext
{
}
