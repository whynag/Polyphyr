using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.Json;

namespace Polyphyr.Core.Storage;

/// <summary>
/// Saves and loads a workspace. The app talks to this interface only, so a database or a
/// sync server can replace the folder store later without touching the rest of the code.
/// </summary>
public interface IWorkspaceStore
{
    Workspace Load(TimeProvider? clock = null);
    /// <summary>Writes only what changed since the last save.</summary>
    void Save(Workspace workspace);
    /// <summary>Copies an image file into the workspace and registers it.</summary>
    ImageAsset ImportImage(Workspace workspace, string sourcePath);
    string GetImagePath(ImageAsset image);
}

/// <summary>
/// Stores a workspace as a plain folder:
/// <code>
/// MyWorkspace/
///   workspace.json         users, cards, board, and the list of notes/sheets/images/flowcharts
///   notes/Sprint plan.md   one markdown file per note, readable in any editor
///   sheets/&lt;id&gt;.json       one file per sheet
///   flowcharts/&lt;id&gt;.json   one file per flowchart layout
///   images/&lt;id&gt;.png        imported images
/// </code>
/// Every file is written to a temporary file first and then swapped in, so a crash mid-save
/// never leaves a half-written file behind.
/// </summary>
public sealed class FolderWorkspaceStore : IWorkspaceStore
{
    public const int FormatVersion = 1;
    public const string IndexFileName = "workspace.json";
    public const string NotesFolder = "notes";
    public const string SheetsFolder = "sheets";
    public const string FlowchartsFolder = "flowcharts";
    public const string ImagesFolder = "images";

    private static readonly UTF8Encoding Utf8NoBom = new(encoderShouldEmitUTF8Identifier: false);

    public string Root { get; }

    public FolderWorkspaceStore(string root)
    {
        Root = Path.GetFullPath(root);
    }

    public static bool Exists(string root) => File.Exists(Path.Combine(root, IndexFileName));

    /// <summary>Creates a new workspace in an empty (or missing) folder and saves it.</summary>
    public static (Workspace Workspace, FolderWorkspaceStore Store) CreateNew(string root, string name, string ownerName, TimeProvider? clock = null, UserId? ownerId = null)
    {
        if (Exists(root)) throw new IOException($"A workspace already exists in '{root}'.");
        var store = new FolderWorkspaceStore(root);
        var ws = Workspace.CreateNew(name, ownerName, clock, ownerId);
        store.Save(ws);
        return (ws, store);
    }

    // ------------------------------------------------------------------
    // Load
    // ------------------------------------------------------------------

    public Workspace Load(TimeProvider? clock = null)
    {
        var indexPath = Path.Combine(Root, IndexFileName);
        WorkspaceFile index;
        using (var stream = File.OpenRead(indexPath))
        {
            index = JsonSerializer.Deserialize(stream, StorageJsonContext.Default.WorkspaceFile)
                    ?? throw new InvalidDataException($"'{indexPath}' is empty.");
        }
        if (index.FormatVersion > FormatVersion)
            throw new InvalidDataException($"This workspace was saved by a newer version of the app (format {index.FormatVersion}).");

        foreach (var note in index.Notes)
        {
            // Never let a hand-edited file name point outside the notes folder.
            note.FileName = Path.GetFileName(note.FileName);
            if (note.FileName.Length == 0) note.FileName = FileNames.Sanitize(note.Title) + ".md";
            var path = Path.Combine(Root, NotesFolder, note.FileName);
            note.Text = File.Exists(path) ? File.ReadAllText(path, Encoding.UTF8) : "";
        }

        foreach (var sheet in index.Sheets)
        {
            var path = SheetPath(sheet.Id);
            if (!File.Exists(path)) continue;
            using var stream = File.OpenRead(path);
            var file = JsonSerializer.Deserialize(stream, StorageJsonContext.Default.SheetFile);
            if (file is null) continue;
            sheet.RowCount = Math.Clamp(file.RowCount, 1, Workspace.MaxSheetRows);
            sheet.ColumnCount = Math.Clamp(file.ColumnCount, 1, Workspace.MaxSheetColumns);
            // A hand-edited file may say "ColumnWidths": null; treat that as empty.
            if (file.ColumnWidths is { } widths)
                foreach (var (col, width) in widths) sheet.ColumnWidths[col] = width;
            if (file.Cells is { } cells)
            {
                sheet.Cells.EnsureCapacity(cells.Count);
                foreach (var cell in cells)
                    if (!string.IsNullOrEmpty(cell.Text)) sheet.Cells[new CellRef(cell.Row, cell.Column)] = cell.Text;
            }
            if (file.Styles is { } styles)
                foreach (var s in styles)
                {
                    var style = new CellStyle(s.Fill, s.Text, s.Outline);
                    if (!style.IsEmpty) sheet.Styles[new CellRef(s.Row, s.Column)] = style;
                }
        }

        var cardIds = new HashSet<CardId>();
        foreach (var c in index.Cards) cardIds.Add(c.Id);

        foreach (var flow in index.Flowcharts)
        {
            var path = FlowchartPath(flow.Id);
            if (!File.Exists(path)) continue;
            using var stream = File.OpenRead(path);
            var file = JsonSerializer.Deserialize(stream, StorageJsonContext.Default.FlowchartFile);
            if (file is null) continue;
            foreach (var node in file.Nodes ?? new())
            {
                if (node.Id.IsEmpty) continue;          // older card-based layouts
                if (node.Card is { } card && !cardIds.Contains(card)) node.Card = null;
                flow.Nodes[node.Id] = node;
            }
            foreach (var edge in file.Edges ?? new())
                if (flow.Nodes.ContainsKey(edge.From) && flow.Nodes.ContainsKey(edge.To)) flow.Edges.Add(edge);
        }

        return new Workspace(index.Name, index.Board, index.Users, index.Cards, index.Notes,
            index.Sheets, index.Images, index.Flowcharts, clock);
    }

    // ------------------------------------------------------------------
    // Save
    // ------------------------------------------------------------------

    public void Save(Workspace ws)
    {
        var pending = ws.Pending;
        if (!pending.HasChanges) return;

        Directory.CreateDirectory(Root);

        // 1. Write changed content files.
        foreach (var id in pending.Notes)
        {
            if (!ws.Notes.TryGetValue(id, out var note)) continue;
            WriteAtomic(Path.Combine(Root, NotesFolder, note.FileName), Utf8NoBom.GetBytes(note.Text));
        }

        foreach (var id in pending.Sheets)
        {
            if (!ws.Sheets.TryGetValue(id, out var sheet)) continue;
            var file = new SheetFile
            {
                RowCount = sheet.RowCount,
                ColumnCount = sheet.ColumnCount,
                ColumnWidths = new Dictionary<int, float>(sheet.ColumnWidths),
                Cells = new List<CellEntry>(sheet.Cells.Count),
                Styles = new List<StyleEntry>(sheet.Styles.Count),
            };
            foreach (var (cell, style) in sheet.Styles) file.Styles.Add(new StyleEntry(cell.Row, cell.Column, style.Fill, style.Text, style.Outline));
            file.Styles.Sort(static (a, b) => a.Row != b.Row ? a.Row.CompareTo(b.Row) : a.Column.CompareTo(b.Column));
            foreach (var (cell, text) in sheet.Cells) file.Cells.Add(new CellEntry(cell.Row, cell.Column, text));
            // Stable order keeps diffs small if the folder is under version control.
            file.Cells.Sort(static (a, b) => a.Row != b.Row ? a.Row.CompareTo(b.Row) : a.Column.CompareTo(b.Column));
            WriteAtomic(SheetPath(id), JsonSerializer.SerializeToUtf8Bytes(file, StorageJsonContext.Default.SheetFile));
        }

        foreach (var id in pending.Flowcharts)
        {
            if (!ws.Flowcharts.TryGetValue(id, out var flow)) continue;
            var file = new FlowchartFile
            {
                Nodes = new List<FlowNode>(flow.Nodes.Values),
                Edges = new List<FlowEdge>(flow.Edges),
            };
            WriteAtomic(FlowchartPath(id), JsonSerializer.SerializeToUtf8Bytes(file, StorageJsonContext.Default.FlowchartFile));
        }

        // 2. Write the index, which now points at the new files.
        if (pending.IndexDirty)
        {
            var index = new WorkspaceFile
            {
                Name = ws.Name,
                Users = new List<User>(ws.Users.Values),
                Board = ws.Board,
                Cards = new List<Card>(ws.Cards.Values),
                Notes = new List<Note>(ws.Notes.Values),
                Sheets = new List<Sheet>(ws.Sheets.Values),
                Images = new List<ImageAsset>(ws.Images.Values),
                Flowcharts = new List<Flowchart>(ws.Flowcharts.Values),
            };
            WriteAtomic(Path.Combine(Root, IndexFileName), JsonSerializer.SerializeToUtf8Bytes(index, StorageJsonContext.Default.WorkspaceFile));
        }

        // 3. Only now remove files that are no longer used, so a crash before this point loses nothing.
        //    A file name may have been reused by another note in the meantime, so check first.
        var liveNoteFiles = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var n in ws.Notes.Values) liveNoteFiles.Add(n.FileName);
        foreach (var name in pending.RemovedNoteFiles)
            if (!liveNoteFiles.Contains(name)) DeleteIfExists(Path.Combine(Root, NotesFolder, Path.GetFileName(name)));
        foreach (var name in pending.RemovedImageFiles)
            DeleteIfExists(Path.Combine(Root, ImagesFolder, Path.GetFileName(name)));
        foreach (var id in pending.RemovedSheets)
            DeleteIfExists(SheetPath(id));
        foreach (var id in pending.RemovedFlowcharts)
            DeleteIfExists(FlowchartPath(id));

        pending.Clear();
    }

    // ------------------------------------------------------------------
    // Images
    // ------------------------------------------------------------------

    public ImageAsset ImportImage(Workspace ws, string sourcePath)
    {
        var id = ImageId.New();
        var ext = Path.GetExtension(sourcePath).ToLowerInvariant();
        var fileName = id + ext;
        var dest = Path.Combine(Root, ImagesFolder, fileName);
        Directory.CreateDirectory(Path.GetDirectoryName(dest)!);
        File.Copy(sourcePath, dest, overwrite: false);

        if (!ws.Apply(new AddImage(id, fileName, Path.GetFileName(sourcePath))))
        {
            File.Delete(dest);
            throw new InvalidOperationException("Could not register the imported image.");
        }
        return ws.Images[id];
    }

    public string GetImagePath(ImageAsset image) => Path.Combine(Root, ImagesFolder, Path.GetFileName(image.FileName));

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------

    private string SheetPath(SheetId id) => Path.Combine(Root, SheetsFolder, id + ".json");
    private string FlowchartPath(FlowchartId id) => Path.Combine(Root, FlowchartsFolder, id + ".json");

    private static void WriteAtomic(string path, byte[] bytes)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        var temp = path + ".tmp";
        File.WriteAllBytes(temp, bytes);
        File.Move(temp, path, overwrite: true);
    }

    private static void DeleteIfExists(string path)
    {
        if (File.Exists(path)) File.Delete(path);
    }
}

/// <summary>Turns changes into JSON and back. This is what a sync service will send between teammates.</summary>
public static class ChangeJson
{
    public static string Serialize(Change change)
        => JsonSerializer.Serialize(change, StorageJsonContext.Default.Change);

    public static Change? Deserialize(string json)
        => JsonSerializer.Deserialize(json, StorageJsonContext.Default.Change);
}
