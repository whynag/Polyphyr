using System;
using System.Text.Json.Serialization;

namespace Polyphyr.Core;

/// <summary>
/// Every edit to a workspace is one of these small records ("rename card X to Y").
/// The UI never mutates the model directly; it builds a change and calls <see cref="Workspace.Apply"/>.
///
/// This is the groundwork for multiple users: changes carry their author and time, serialize to JSON,
/// and applying one that no longer makes sense (e.g. the card was deleted) is a harmless no-op.
/// Syncing later means sending these records between machines.
/// </summary>
[JsonPolymorphic(TypeDiscriminatorPropertyName = "$op")]
// Users
[JsonDerivedType(typeof(AddUser), "user.add")]
[JsonDerivedType(typeof(RenameUser), "user.rename")]
[JsonDerivedType(typeof(SetUserColor), "user.color")]
// Board columns
[JsonDerivedType(typeof(AddColumn), "column.add")]
[JsonDerivedType(typeof(RenameColumn), "column.rename")]
[JsonDerivedType(typeof(MoveColumn), "column.move")]
[JsonDerivedType(typeof(RemoveColumn), "column.remove")]
// Cards
[JsonDerivedType(typeof(CreateCard), "card.create")]
[JsonDerivedType(typeof(DeleteCard), "card.delete")]
[JsonDerivedType(typeof(MoveCard), "card.move")]
[JsonDerivedType(typeof(SetCardTitle), "card.title")]
[JsonDerivedType(typeof(SetCardDescription), "card.description")]
[JsonDerivedType(typeof(SetCardPriority), "card.priority")]
[JsonDerivedType(typeof(SetCardDueDate), "card.due")]
[JsonDerivedType(typeof(SetCardTags), "card.tags")]
[JsonDerivedType(typeof(AssignUser), "card.assign")]
[JsonDerivedType(typeof(UnassignUser), "card.unassign")]
[JsonDerivedType(typeof(AttachToCard), "card.attach")]
[JsonDerivedType(typeof(DetachFromCard), "card.detach")]
[JsonDerivedType(typeof(SetCardCover), "card.cover")]
// Notes
[JsonDerivedType(typeof(CreateNote), "note.create")]
[JsonDerivedType(typeof(RenameNote), "note.rename")]
[JsonDerivedType(typeof(SetNoteText), "note.text")]
[JsonDerivedType(typeof(DeleteNote), "note.delete")]
// Sheets
[JsonDerivedType(typeof(CreateSheet), "sheet.create")]
[JsonDerivedType(typeof(RenameSheet), "sheet.rename")]
[JsonDerivedType(typeof(SetSheetCell), "sheet.cell")]
[JsonDerivedType(typeof(ResizeSheet), "sheet.resize")]
[JsonDerivedType(typeof(SetSheetColumnWidth), "sheet.colwidth")]
[JsonDerivedType(typeof(DeleteSheet), "sheet.delete")]
[JsonDerivedType(typeof(SetSheetStyle), "sheet.style")]
[JsonDerivedType(typeof(ClearSheetRange), "sheet.clear")]
[JsonDerivedType(typeof(InsertSheetRows), "sheet.rows.insert")]
[JsonDerivedType(typeof(DeleteSheetRows), "sheet.rows.delete")]
[JsonDerivedType(typeof(InsertSheetColumns), "sheet.cols.insert")]
[JsonDerivedType(typeof(DeleteSheetColumns), "sheet.cols.delete")]
// Images
[JsonDerivedType(typeof(AddImage), "image.add")]
[JsonDerivedType(typeof(RemoveImage), "image.remove")]
// Flowcharts
[JsonDerivedType(typeof(CreateFlowchart), "flow.create")]
[JsonDerivedType(typeof(RenameFlowchart), "flow.rename")]
[JsonDerivedType(typeof(DeleteFlowchart), "flow.delete")]
[JsonDerivedType(typeof(AddFlowNode), "flow.node.add")]
[JsonDerivedType(typeof(MoveFlowNode), "flow.node.move")]
[JsonDerivedType(typeof(ResizeFlowNode), "flow.node.resize")]
[JsonDerivedType(typeof(SetFlowNodeText), "flow.node.text")]
[JsonDerivedType(typeof(SetFlowNodeColor), "flow.node.color")]
[JsonDerivedType(typeof(SetFlowNodeShape), "flow.node.shape")]
[JsonDerivedType(typeof(RemoveFlowNode), "flow.node.remove")]
[JsonDerivedType(typeof(ConnectNodes), "flow.connect")]
[JsonDerivedType(typeof(DisconnectNodes), "flow.disconnect")]
[JsonDerivedType(typeof(SetEdgeLabel), "flow.label")]
public abstract record Change
{
    public ChangeId Id { get; init; } = ChangeId.New();
    /// <summary>Filled in by <see cref="Workspace.Apply"/> for local edits; kept as-is for changes from other users.</summary>
    public UserId Author { get; init; }
    public DateTimeOffset At { get; init; }
}

// ---- Users ----
public sealed record AddUser(UserId User, string DisplayName, string Color) : Change;
public sealed record RenameUser(UserId User, string DisplayName) : Change;
public sealed record SetUserColor(UserId User, string Color) : Change;

// ---- Board columns ----
/// <param name="Index">Position to insert at; out-of-range values append.</param>
public sealed record AddColumn(ColumnId Column, string Name, int Index) : Change;
public sealed record RenameColumn(ColumnId Column, string Name) : Change;
public sealed record MoveColumn(ColumnId Column, int Index) : Change;
/// <param name="MoveCardsTo">Column that receives the removed column's cards. If null, they go to the first remaining column.</param>
public sealed record RemoveColumn(ColumnId Column, ColumnId? MoveCardsTo) : Change;

// ---- Cards ----
public sealed record CreateCard(CardId Card, ColumnId Column, int Index, string Title) : Change;
public sealed record DeleteCard(CardId Card) : Change;
public sealed record MoveCard(CardId Card, ColumnId Column, int Index) : Change;
public sealed record SetCardTitle(CardId Card, string Title) : Change;
public sealed record SetCardDescription(CardId Card, string Description) : Change;
public sealed record SetCardPriority(CardId Card, Priority Priority) : Change;
public sealed record SetCardDueDate(CardId Card, DateOnly? DueDate) : Change;
public sealed record SetCardTags(CardId Card, string[] Tags) : Change;
public sealed record AssignUser(CardId Card, UserId User) : Change;
public sealed record UnassignUser(CardId Card, UserId User) : Change;
public sealed record AttachToCard(CardId Card, Attachment Attachment) : Change;
public sealed record DetachFromCard(CardId Card, Attachment Attachment) : Change;
public sealed record SetCardCover(CardId Card, ImageId? Image) : Change;

// ---- Notes ----
public sealed record CreateNote(NoteId Note, string Title) : Change;
public sealed record RenameNote(NoteId Note, string Title) : Change;
/// <summary>Replaces the whole text. The editor sends this after a short pause in typing, not per keystroke.</summary>
public sealed record SetNoteText(NoteId Note, string Text) : Change;
public sealed record DeleteNote(NoteId Note) : Change;

// ---- Sheets ----
public sealed record CreateSheet(SheetId Sheet, string Title, int Rows, int Columns) : Change;
public sealed record RenameSheet(SheetId Sheet, string Title) : Change;
/// <summary>Sets one cell. Empty text clears it.</summary>
public sealed record SetSheetCell(SheetId Sheet, int Row, int Column, string Text) : Change;
/// <summary>Cells outside the new size are kept, just hidden, so shrinking by mistake loses nothing.</summary>
public sealed record ResizeSheet(SheetId Sheet, int Rows, int Columns) : Change;
public sealed record SetSheetColumnWidth(SheetId Sheet, int Column, float Width) : Change;
public sealed record DeleteSheet(SheetId Sheet) : Change;
/// <summary>Sets one color (fill, text or outline) on a block of cells. Null clears it.</summary>
public sealed record SetSheetStyle(SheetId Sheet, int Row, int Column, int Rows, int Columns, CellStylePart Part, string? Color) : Change;
/// <summary>Clears the text of a block of cells (colors are kept).</summary>
public sealed record ClearSheetRange(SheetId Sheet, int Row, int Column, int Rows, int Columns) : Change;
/// <summary>Inserts empty rows before row <c>Index</c>, moving everything below down.</summary>
public sealed record InsertSheetRows(SheetId Sheet, int Index, int Count) : Change;
/// <summary>Removes rows (with their text and colors), moving everything below up.</summary>
public sealed record DeleteSheetRows(SheetId Sheet, int Index, int Count) : Change;
/// <summary>Inserts empty columns before column <c>Index</c>, moving everything to the right along.</summary>
public sealed record InsertSheetColumns(SheetId Sheet, int Index, int Count) : Change;
/// <summary>Removes columns (with their text, colors and widths), moving everything to the right back.</summary>
public sealed record DeleteSheetColumns(SheetId Sheet, int Index, int Count) : Change;

// ---- Images ----
public sealed record AddImage(ImageId Image, string FileName, string OriginalName) : Change;
public sealed record RemoveImage(ImageId Image) : Change;

// ---- Flowcharts ----
public sealed record CreateFlowchart(FlowchartId Flowchart, string Name) : Change;
public sealed record RenameFlowchart(FlowchartId Flowchart, string Name) : Change;
public sealed record DeleteFlowchart(FlowchartId Flowchart) : Change;
/// <summary>Adds the card to the flowchart, or moves it if it's already there.</summary>
public sealed record AddFlowNode(FlowchartId Flowchart, NodeId Node, FlowShape Shape, string Text, float X, float Y, float Width, float Height, string? Color) : Change;
public sealed record MoveFlowNode(FlowchartId Flowchart, NodeId Node, float X, float Y) : Change;
public sealed record ResizeFlowNode(FlowchartId Flowchart, NodeId Node, float Width, float Height) : Change;
public sealed record SetFlowNodeText(FlowchartId Flowchart, NodeId Node, string Text) : Change;
/// <summary>Null goes back to the shape's default color.</summary>
public sealed record SetFlowNodeColor(FlowchartId Flowchart, NodeId Node, string? Color) : Change;
public sealed record SetFlowNodeShape(FlowchartId Flowchart, NodeId Node, FlowShape Shape) : Change;
/// <summary>Removes a node and every arrow touching it.</summary>
public sealed record RemoveFlowNode(FlowchartId Flowchart, NodeId Node) : Change;
public sealed record ConnectNodes(FlowchartId Flowchart, EdgeId Edge, NodeId From, FlowSide FromSide, NodeId To, FlowSide ToSide, string Label) : Change;
public sealed record DisconnectNodes(FlowchartId Flowchart, EdgeId Edge) : Change;
public sealed record SetEdgeLabel(FlowchartId Flowchart, EdgeId Edge, string Label) : Change;
