using System;
using System.Collections.Generic;

namespace Polyphyr.Core;

/// <summary>
/// Which parts of the workspace changed since the last save, so saving only rewrites those files.
/// </summary>
public sealed class ChangeTracker
{
    internal bool IndexDirty;
    internal readonly HashSet<NoteId> Notes = new();
    internal readonly HashSet<SheetId> Sheets = new();
    internal readonly HashSet<FlowchartId> Flowcharts = new();
    internal readonly HashSet<string> RemovedNoteFiles = new(StringComparer.OrdinalIgnoreCase);
    internal readonly HashSet<string> RemovedImageFiles = new(StringComparer.OrdinalIgnoreCase);
    internal readonly HashSet<SheetId> RemovedSheets = new();
    internal readonly HashSet<FlowchartId> RemovedFlowcharts = new();

    public bool HasChanges =>
        IndexDirty || Notes.Count > 0 || Sheets.Count > 0 || Flowcharts.Count > 0 ||
        RemovedNoteFiles.Count > 0 || RemovedImageFiles.Count > 0 ||
        RemovedSheets.Count > 0 || RemovedFlowcharts.Count > 0;

    internal void MarkEverythingDirty(Workspace ws)
    {
        IndexDirty = true;
        foreach (var id in ws.Notes.Keys) Notes.Add(id);
        foreach (var id in ws.Sheets.Keys) Sheets.Add(id);
        foreach (var id in ws.Flowcharts.Keys) Flowcharts.Add(id);
    }

    internal void Clear()
    {
        IndexDirty = false;
        Notes.Clear();
        Sheets.Clear();
        Flowcharts.Clear();
        RemovedNoteFiles.Clear();
        RemovedImageFiles.Clear();
        RemovedSheets.Clear();
        RemovedFlowcharts.Clear();
    }
}

/// <summary>
/// The whole in-memory state of one workspace. Not thread-safe: use it from the main thread only.
/// All edits go through <see cref="Apply"/>.
/// </summary>
public sealed class Workspace
{
    public const int MaxSheetRows = 100_000;
    public const int MaxSheetColumns = 1_000;
    private const int HistoryLimit = 5_000;

    private readonly TimeProvider _clock;
    private readonly Dictionary<UserId, User> _users = new();
    private readonly Dictionary<CardId, Card> _cards = new();
    private readonly Dictionary<NoteId, Note> _notes = new();
    private readonly Dictionary<SheetId, Sheet> _sheets = new();
    private readonly Dictionary<ImageId, ImageAsset> _images = new();
    private readonly Dictionary<FlowchartId, Flowchart> _flowcharts = new();
    /// <summary>Card → its board column, so status lookups don't scan the board.</summary>
    private readonly Dictionary<CardId, BoardColumn> _cardColumn = new();
    private readonly List<Change> _history = new();

    public string Name { get; internal set; }
    public Board Board { get; }
    /// <summary>The person using this copy of the app. Local edits are attributed to them.</summary>
    public UserId CurrentUser { get; set; }

    public IReadOnlyDictionary<UserId, User> Users => _users;
    public IReadOnlyDictionary<CardId, Card> Cards => _cards;
    public IReadOnlyDictionary<NoteId, Note> Notes => _notes;
    public IReadOnlyDictionary<SheetId, Sheet> Sheets => _sheets;
    public IReadOnlyDictionary<ImageId, ImageAsset> Images => _images;
    public IReadOnlyDictionary<FlowchartId, Flowchart> Flowcharts => _flowcharts;

    /// <summary>Changes applied this session, oldest first (capped at the most recent few thousand).</summary>
    public IReadOnlyList<Change> History => _history;
    public ChangeTracker Pending { get; } = new();

    /// <summary>Raised after every change that actually modified the workspace. The UI listens to this to refresh.</summary>
    public event Action<Change>? Changed;

    internal Workspace(
        string name,
        Board board,
        IEnumerable<User> users,
        IEnumerable<Card> cards,
        IEnumerable<Note> notes,
        IEnumerable<Sheet> sheets,
        IEnumerable<ImageAsset> images,
        IEnumerable<Flowchart> flowcharts,
        TimeProvider? clock = null)
    {
        _clock = clock ?? TimeProvider.System;
        Name = name;
        Board = board;
        foreach (var u in users) _users[u.Id] = u;
        foreach (var c in cards) _cards[c.Id] = c;
        foreach (var n in notes) _notes[n.Id] = n;
        foreach (var s in sheets) _sheets[s.Id] = s;
        foreach (var i in images) _images[i.Id] = i;
        foreach (var f in flowcharts) _flowcharts[f.Id] = f;
        RepairBoard();
    }

    /// <summary>Creates a fresh workspace with default columns, one flowchart, and the owner as the current user.</summary>
    public static Workspace CreateNew(string name, string ownerName, TimeProvider? clock = null, UserId? ownerId = null)
    {
        var ws = new Workspace(name, new Board(),
            Array.Empty<User>(), Array.Empty<Card>(), Array.Empty<Note>(),
            Array.Empty<Sheet>(), Array.Empty<ImageAsset>(), Array.Empty<Flowchart>(), clock);

        var owner = ownerId is { IsEmpty: false } given ? given : UserId.New();
        ws.CurrentUser = owner;
        ws.Apply(new AddUser(owner, ownerName, "#4F8CFF"));
        ws.NewColumn("To Do");
        ws.NewColumn("In Progress");
        ws.NewColumn("Done");
        ws.NewFlowchart("Main");
        ws.Pending.MarkEverythingDirty(ws);
        return ws;
    }

    // ------------------------------------------------------------------
    // Queries
    // ------------------------------------------------------------------

    public BoardColumn? GetColumnOf(CardId card) => _cardColumn.TryGetValue(card, out var col) ? col : null;

    public BoardColumn? FindColumn(ColumnId id)
    {
        foreach (var col in Board.Columns)
            if (col.Id == id) return col;
        return null;
    }

    public bool AttachmentExists(Attachment a) => a.Kind switch
    {
        AttachmentKind.Note => _notes.ContainsKey(NoteId.From(a.TargetId)),
        AttachmentKind.Sheet => _sheets.ContainsKey(SheetId.From(a.TargetId)),
        AttachmentKind.Image => _images.ContainsKey(ImageId.From(a.TargetId)),
        _ => false,
    };

    // ------------------------------------------------------------------
    // Shortcuts for edits that need a new ID. Everything else: ws.Apply(new SetCardTitle(id, "..."))
    // ------------------------------------------------------------------

    public ColumnId NewColumn(string name, int index = int.MaxValue)
    {
        var id = ColumnId.New();
        Apply(new AddColumn(id, name, index));
        return id;
    }

    public CardId NewCard(ColumnId column, string title, int index = int.MaxValue)
    {
        var id = CardId.New();
        return Apply(new CreateCard(id, column, index, title)) ? id : default;
    }

    public NoteId NewNote(string title)
    {
        var id = NoteId.New();
        Apply(new CreateNote(id, title));
        return id;
    }

    public SheetId NewSheet(string title, int rows = 24, int columns = 24)
    {
        var id = SheetId.New();
        Apply(new CreateSheet(id, title, rows, columns));
        return id;
    }

    public FlowchartId NewFlowchart(string name)
    {
        var id = FlowchartId.New();
        Apply(new CreateFlowchart(id, name));
        return id;
    }

    public NodeId NewFlowNode(FlowchartId flowchart, FlowShape shape, float x, float y, string text = "", float width = 180f, float height = 80f)
    {
        var id = NodeId.New();
        return Apply(new AddFlowNode(flowchart, id, shape, text, x, y, width, height, null)) ? id : default;
    }

    public EdgeId Connect(FlowchartId flowchart, NodeId from, FlowSide fromSide, NodeId to, FlowSide toSide, string label = "")
    {
        var id = EdgeId.New();
        return Apply(new ConnectNodes(flowchart, id, from, fromSide, to, toSide, label)) ? id : default;
    }

    // ------------------------------------------------------------------
    // Applying changes
    // ------------------------------------------------------------------

    /// <summary>
    /// Applies a change. Local edits get the current user and time stamped on.
    /// Returns false (and does nothing) if the change doesn't apply, e.g. its card no longer exists.
    /// </summary>
    public bool Apply(Change change)
    {
        if (change.Author.IsEmpty || change.At == default)
        {
            change = change with
            {
                Author = change.Author.IsEmpty ? CurrentUser : change.Author,
                At = change.At == default ? _clock.GetUtcNow() : change.At,
            };
        }

        if (!ApplyCore(change)) return false;

        _history.Add(change);
        if (_history.Count > HistoryLimit + HistoryLimit / 5)
            _history.RemoveRange(0, _history.Count - HistoryLimit);

        Changed?.Invoke(change);
        return true;
    }

    private bool ApplyCore(Change c)
    {
        var by = c.Author;
        var at = c.At;

        switch (c)
        {
            // ---------------- Users ----------------
            case AddUser x:
            {
                if (_users.ContainsKey(x.User)) return false;
                _users[x.User] = new User { Id = x.User, DisplayName = x.DisplayName, Color = x.Color, CreatedAt = at };
                return MarkIndex();
            }
            case RenameUser x:
            {
                if (!_users.TryGetValue(x.User, out var u) || u.DisplayName == x.DisplayName) return false;
                u.DisplayName = x.DisplayName;
                return MarkIndex();
            }
            case SetUserColor x:
            {
                if (!_users.TryGetValue(x.User, out var u) || u.Color == x.Color) return false;
                u.Color = x.Color;
                return MarkIndex();
            }

            // ---------------- Board columns ----------------
            case AddColumn x:
            {
                if (FindColumn(x.Column) is not null) return false;
                var cols = Board.Columns;
                cols.Insert(ClampInsert(x.Index, cols.Count), new BoardColumn { Id = x.Column, Name = x.Name });
                return MarkIndex();
            }
            case RenameColumn x:
            {
                var col = FindColumn(x.Column);
                if (col is null || col.Name == x.Name) return false;
                col.Name = x.Name;
                return MarkIndex();
            }
            case MoveColumn x:
            {
                var cols = Board.Columns;
                int from = cols.FindIndex(k => k.Id == x.Column);
                if (from < 0) return false;
                var col = cols[from];
                cols.RemoveAt(from);
                int to = ClampInsert(x.Index, cols.Count);
                cols.Insert(to, col);
                return from != to && MarkIndex();
            }
            case RemoveColumn x:
            {
                var cols = Board.Columns;
                int idx = cols.FindIndex(k => k.Id == x.Column);
                if (idx < 0 || cols.Count == 1) return false; // the board always keeps one column
                var removed = cols[idx];
                cols.RemoveAt(idx);

                var target = x.MoveCardsTo is { } t ? FindColumn(t) : null;
                target ??= cols[0];
                foreach (var cardId in removed.Cards)
                {
                    target.Cards.Add(cardId);
                    _cardColumn[cardId] = target;
                }
                return MarkIndex();
            }

            // ---------------- Cards ----------------
            case CreateCard x:
            {
                if (_cards.ContainsKey(x.Card) || Board.Columns.Count == 0) return false;
                // If the column was removed (e.g. by another user), fall back to the first one.
                var col = FindColumn(x.Column) ?? Board.Columns[0];
                _cards[x.Card] = new Card { Id = x.Card, Number = NextCardNumber(), Title = x.Title, Meta = ItemMeta.Create(by, at) };
                col.Cards.Insert(ClampInsert(x.Index, col.Cards.Count), x.Card);
                _cardColumn[x.Card] = col;
                return MarkIndex();
            }
            case DeleteCard x:
            {
                if (!_cards.Remove(x.Card)) return false;
                if (_cardColumn.Remove(x.Card, out var col)) col.Cards.Remove(x.Card);
                // Nodes that stood for this task stay on the chart, just unlinked.
                foreach (var flow in _flowcharts.Values)
                    foreach (var node in flow.Nodes.Values)
                        if (node.Card == x.Card)
                        {
                            node.Card = null;
                            Pending.Flowcharts.Add(flow.Id);
                        }
                return MarkIndex();
            }
            case MoveCard x:
            {
                if (!_cards.TryGetValue(x.Card, out var card)) return false;
                var target = FindColumn(x.Column);
                if (target is null) return false;
                var source = _cardColumn[x.Card];
                int oldIndex = source.Cards.IndexOf(x.Card);
                source.Cards.RemoveAt(oldIndex);
                int newIndex = ClampInsert(x.Index, target.Cards.Count);
                target.Cards.Insert(newIndex, x.Card);
                _cardColumn[x.Card] = target;
                if (ReferenceEquals(source, target) && oldIndex == newIndex) return false;
                card.Meta.Touch(by, at);
                return MarkIndex();
            }
            case SetCardTitle x:
                return EditCard(x.Card, by, at, card =>
                {
                    if (card.Title == x.Title) return false;
                    card.Title = x.Title;
                    return true;
                });
            case SetCardDescription x:
                return EditCard(x.Card, by, at, card =>
                {
                    if (card.Description == x.Description) return false;
                    card.Description = x.Description;
                    return true;
                });
            case SetCardPriority x:
                return EditCard(x.Card, by, at, card =>
                {
                    if (card.Priority == x.Priority) return false;
                    card.Priority = x.Priority;
                    return true;
                });
            case SetCardDueDate x:
                return EditCard(x.Card, by, at, card =>
                {
                    if (card.DueDate == x.DueDate) return false;
                    card.DueDate = x.DueDate;
                    return true;
                });
            case SetCardTags x:
                return EditCard(x.Card, by, at, card =>
                {
                    card.Tags.Clear();
                    foreach (var raw in x.Tags)
                    {
                        var tag = raw.Trim();
                        if (tag.Length > 0 && !card.Tags.Contains(tag)) card.Tags.Add(tag);
                    }
                    return true;
                });
            case AssignUser x:
                return _users.ContainsKey(x.User) && EditCard(x.Card, by, at, card =>
                {
                    if (card.Assignees.Contains(x.User)) return false;
                    card.Assignees.Add(x.User);
                    return true;
                });
            case UnassignUser x:
                return EditCard(x.Card, by, at, card => card.Assignees.Remove(x.User));
            case AttachToCard x:
                return AttachmentExists(x.Attachment) && EditCard(x.Card, by, at, card =>
                {
                    if (card.Attachments.Contains(x.Attachment)) return false;
                    card.Attachments.Add(x.Attachment);
                    // The first image attached becomes the flowchart node background.
                    if (x.Attachment.Kind == AttachmentKind.Image && card.CoverImage is null)
                        card.CoverImage = ImageId.From(x.Attachment.TargetId);
                    return true;
                });
            case DetachFromCard x:
                return EditCard(x.Card, by, at, card => DetachFrom(card, x.Attachment));
            case SetCardCover x:
            {
                if (x.Image is { } img && !_images.ContainsKey(img)) return false;
                return EditCard(x.Card, by, at, card =>
                {
                    if (card.CoverImage == x.Image) return false;
                    card.CoverImage = x.Image;
                    if (x.Image is { } i && !card.Attachments.Contains(Attachment.Of(i)))
                        card.Attachments.Add(Attachment.Of(i));
                    return true;
                });
            }

            // ---------------- Notes ----------------
            case CreateNote x:
            {
                if (_notes.ContainsKey(x.Note)) return false;
                _notes[x.Note] = new Note
                {
                    Id = x.Note,
                    Title = x.Title,
                    FileName = UniqueNoteFileName(x.Title, x.Note),
                    Meta = ItemMeta.Create(by, at),
                };
                Pending.Notes.Add(x.Note);
                return MarkIndex();
            }
            case RenameNote x:
            {
                if (!_notes.TryGetValue(x.Note, out var note) || note.Title == x.Title) return false;
                note.Title = x.Title;
                var newFile = UniqueNoteFileName(x.Title, x.Note);
                if (!string.Equals(newFile, note.FileName, StringComparison.Ordinal))
                {
                    Pending.RemovedNoteFiles.Add(note.FileName);
                    note.FileName = newFile;
                    Pending.Notes.Add(x.Note);
                }
                note.Meta.Touch(by, at);
                return MarkIndex();
            }
            case SetNoteText x:
            {
                if (!_notes.TryGetValue(x.Note, out var note) || note.Text == x.Text) return false;
                note.Text = x.Text;
                note.Meta.Touch(by, at);
                Pending.Notes.Add(x.Note);
                return MarkIndex();
            }
            case DeleteNote x:
            {
                if (!_notes.Remove(x.Note, out var note)) return false;
                Pending.Notes.Remove(x.Note);
                Pending.RemovedNoteFiles.Add(note.FileName);
                DetachEverywhere(Attachment.Of(x.Note), by, at);
                return MarkIndex();
            }

            // ---------------- Sheets ----------------
            case CreateSheet x:
            {
                if (_sheets.ContainsKey(x.Sheet)) return false;
                _sheets[x.Sheet] = new Sheet
                {
                    Id = x.Sheet,
                    Title = x.Title,
                    RowCount = Math.Clamp(x.Rows, 1, MaxSheetRows),
                    ColumnCount = Math.Clamp(x.Columns, 1, MaxSheetColumns),
                    Meta = ItemMeta.Create(by, at),
                };
                Pending.Sheets.Add(x.Sheet);
                return MarkIndex();
            }
            case RenameSheet x:
            {
                if (!_sheets.TryGetValue(x.Sheet, out var sheet) || sheet.Title == x.Title) return false;
                sheet.Title = x.Title;
                sheet.Meta.Touch(by, at);
                return MarkIndex();
            }
            case SetSheetCell x:
            {
                if (!_sheets.TryGetValue(x.Sheet, out var sheet)) return false;
                if (x.Row < 0 || x.Column < 0 || x.Row >= MaxSheetRows || x.Column >= MaxSheetColumns) return false;
                var key = new CellRef(x.Row, x.Column);
                if (string.IsNullOrEmpty(x.Text))
                {
                    if (!sheet.Cells.Remove(key)) return false;
                }
                else
                {
                    if (sheet.Cells.TryGetValue(key, out var old) && old == x.Text) return false;
                    sheet.Cells[key] = x.Text;
                }
                return EditSheet(sheet, by, at);
            }
            case ResizeSheet x:
            {
                if (!_sheets.TryGetValue(x.Sheet, out var sheet)) return false;
                int rows = Math.Clamp(x.Rows, 1, MaxSheetRows);
                int cols = Math.Clamp(x.Columns, 1, MaxSheetColumns);
                if (rows == sheet.RowCount && cols == sheet.ColumnCount) return false;
                sheet.RowCount = rows;
                sheet.ColumnCount = cols;
                return EditSheet(sheet, by, at);
            }
            case SetSheetColumnWidth x:
            {
                if (!_sheets.TryGetValue(x.Sheet, out var sheet) || x.Column < 0 || x.Column >= MaxSheetColumns) return false;
                if (!float.IsFinite(x.Width)) return false;
                float width = Math.Clamp(x.Width, 24f, 2000f);
                if (sheet.ColumnWidths.TryGetValue(x.Column, out var old) && old == width) return false;
                sheet.ColumnWidths[x.Column] = width;
                return EditSheet(sheet, by, at);
            }
            case SetSheetStyle x:
            {
                if (!_sheets.TryGetValue(x.Sheet, out var sheet) || !ValidRange(x.Row, x.Column, x.Rows, x.Columns)) return false;
                string? color = string.IsNullOrWhiteSpace(x.Color) ? null : x.Color.Trim();
                bool changed = false;
                for (int r = x.Row; r < x.Row + x.Rows; r++)
                    for (int col = x.Column; col < x.Column + x.Columns; col++)
                    {
                        var key = new CellRef(r, col);
                        var old = sheet.Styles.TryGetValue(key, out var s) ? s : new CellStyle(null, null, null);
                        var next = old.With(x.Part, color);
                        if (next == old) continue;
                        if (next.IsEmpty) sheet.Styles.Remove(key);
                        else sheet.Styles[key] = next;
                        changed = true;
                    }
                return changed && EditSheet(sheet, by, at);
            }
            case ClearSheetRange x:
            {
                if (!_sheets.TryGetValue(x.Sheet, out var sheet) || !ValidRange(x.Row, x.Column, x.Rows, x.Columns)) return false;
                bool changed = false;
                for (int r = x.Row; r < x.Row + x.Rows; r++)
                    for (int col = x.Column; col < x.Column + x.Columns; col++)
                        changed |= sheet.Cells.Remove(new CellRef(r, col));
                return changed && EditSheet(sheet, by, at);
            }
            case InsertSheetRows x:
            {
                if (!_sheets.TryGetValue(x.Sheet, out var sheet) || x.Count <= 0 || x.Index < 0 || x.Index > sheet.RowCount) return false;
                int count = Math.Min(x.Count, MaxSheetRows - sheet.RowCount);
                if (count <= 0) return false;
                ShiftCells(sheet, rows: true, x.Index, count);
                sheet.RowCount += count;
                return EditSheet(sheet, by, at);
            }
            case DeleteSheetRows x:
            {
                if (!_sheets.TryGetValue(x.Sheet, out var sheet) || x.Count <= 0 || x.Index < 0 || x.Index >= sheet.RowCount) return false;
                int count = Math.Min(x.Count, sheet.RowCount - x.Index);
                if (count >= sheet.RowCount) count = sheet.RowCount - 1;   // always keep one row
                if (count <= 0) return false;
                ShiftCells(sheet, rows: true, x.Index, -count);
                sheet.RowCount -= count;
                return EditSheet(sheet, by, at);
            }
            case InsertSheetColumns x:
            {
                if (!_sheets.TryGetValue(x.Sheet, out var sheet) || x.Count <= 0 || x.Index < 0 || x.Index > sheet.ColumnCount) return false;
                int count = Math.Min(x.Count, MaxSheetColumns - sheet.ColumnCount);
                if (count <= 0) return false;
                ShiftCells(sheet, rows: false, x.Index, count);
                sheet.ColumnCount += count;
                return EditSheet(sheet, by, at);
            }
            case DeleteSheetColumns x:
            {
                if (!_sheets.TryGetValue(x.Sheet, out var sheet) || x.Count <= 0 || x.Index < 0 || x.Index >= sheet.ColumnCount) return false;
                int count = Math.Min(x.Count, sheet.ColumnCount - x.Index);
                if (count >= sheet.ColumnCount) count = sheet.ColumnCount - 1;   // always keep one column
                if (count <= 0) return false;
                ShiftCells(sheet, rows: false, x.Index, -count);
                sheet.ColumnCount -= count;
                return EditSheet(sheet, by, at);
            }
            case DeleteSheet x:
            {
                if (!_sheets.Remove(x.Sheet)) return false;
                Pending.Sheets.Remove(x.Sheet);
                Pending.RemovedSheets.Add(x.Sheet);
                DetachEverywhere(Attachment.Of(x.Sheet), by, at);
                return MarkIndex();
            }

            // ---------------- Images ----------------
            case AddImage x:
            {
                if (_images.ContainsKey(x.Image)) return false;
                _images[x.Image] = new ImageAsset
                {
                    Id = x.Image,
                    FileName = x.FileName,
                    OriginalName = x.OriginalName,
                    Meta = ItemMeta.Create(by, at),
                };
                return MarkIndex();
            }
            case RemoveImage x:
            {
                if (!_images.Remove(x.Image, out var image)) return false;
                Pending.RemovedImageFiles.Add(image.FileName);
                DetachEverywhere(Attachment.Of(x.Image), by, at);
                return MarkIndex();
            }

            // ---------------- Flowcharts ----------------
            case CreateFlowchart x:
            {
                if (_flowcharts.ContainsKey(x.Flowchart)) return false;
                _flowcharts[x.Flowchart] = new Flowchart { Id = x.Flowchart, Name = x.Name, Meta = ItemMeta.Create(by, at) };
                Pending.Flowcharts.Add(x.Flowchart);
                return MarkIndex();
            }
            case RenameFlowchart x:
            {
                if (!_flowcharts.TryGetValue(x.Flowchart, out var flow) || flow.Name == x.Name) return false;
                flow.Name = x.Name;
                flow.Meta.Touch(by, at);
                return MarkIndex();
            }
            case DeleteFlowchart x:
            {
                if (!_flowcharts.Remove(x.Flowchart)) return false;
                Pending.Flowcharts.Remove(x.Flowchart);
                Pending.RemovedFlowcharts.Add(x.Flowchart);
                return MarkIndex();
            }
            case AddFlowNode x:
            {
                if (!_flowcharts.TryGetValue(x.Flowchart, out var flow) || x.Node.IsEmpty || flow.Nodes.ContainsKey(x.Node)) return false;
                if (!float.IsFinite(x.X) || !float.IsFinite(x.Y) || !float.IsFinite(x.Width) || !float.IsFinite(x.Height)) return false;
                flow.Nodes[x.Node] = new FlowNode
                {
                    Id = x.Node,
                    Shape = x.Shape,
                    Text = x.Text,
                    Color = string.IsNullOrWhiteSpace(x.Color) ? null : x.Color,
                    X = x.X,
                    Y = x.Y,
                    Width = Math.Clamp(x.Width, MinNodeSize, MaxNodeSize),
                    Height = Math.Clamp(x.Height, MinNodeSize, MaxNodeSize),
                };
                return EditFlowchart(flow, by, at);
            }
            case MoveFlowNode x:
            {
                if (!_flowcharts.TryGetValue(x.Flowchart, out var flow) || !flow.Nodes.TryGetValue(x.Node, out var node)) return false;
                if (!float.IsFinite(x.X) || !float.IsFinite(x.Y) || (node.X == x.X && node.Y == x.Y)) return false;
                node.X = x.X;
                node.Y = x.Y;
                return EditFlowchart(flow, by, at);
            }
            case ResizeFlowNode x:
            {
                if (!_flowcharts.TryGetValue(x.Flowchart, out var flow) || !flow.Nodes.TryGetValue(x.Node, out var node)) return false;
                if (!float.IsFinite(x.Width) || !float.IsFinite(x.Height)) return false;
                float w = Math.Clamp(x.Width, MinNodeSize, MaxNodeSize);
                float h = Math.Clamp(x.Height, MinNodeSize, MaxNodeSize);
                if (node.Width == w && node.Height == h) return false;
                node.Width = w;
                node.Height = h;
                return EditFlowchart(flow, by, at);
            }
            case SetFlowNodeText x:
            {
                if (!_flowcharts.TryGetValue(x.Flowchart, out var flow) || !flow.Nodes.TryGetValue(x.Node, out var node) || node.Text == x.Text) return false;
                node.Text = x.Text;
                return EditFlowchart(flow, by, at);
            }
            case SetFlowNodeColor x:
            {
                if (!_flowcharts.TryGetValue(x.Flowchart, out var flow) || !flow.Nodes.TryGetValue(x.Node, out var node)) return false;
                string? color = string.IsNullOrWhiteSpace(x.Color) ? null : x.Color;
                if (node.Color == color) return false;
                node.Color = color;
                return EditFlowchart(flow, by, at);
            }
            case SetFlowNodeShape x:
            {
                if (!_flowcharts.TryGetValue(x.Flowchart, out var flow) || !flow.Nodes.TryGetValue(x.Node, out var node) || node.Shape == x.Shape) return false;
                node.Shape = x.Shape;
                return EditFlowchart(flow, by, at);
            }
            case RemoveFlowNode x:
            {
                if (!_flowcharts.TryGetValue(x.Flowchart, out var flow) || !flow.Nodes.Remove(x.Node)) return false;
                flow.Edges.RemoveAll(e => e.From == x.Node || e.To == x.Node);
                return EditFlowchart(flow, by, at);
            }
            case ConnectNodes x:
            {
                if (!_flowcharts.TryGetValue(x.Flowchart, out var flow)) return false;
                if (x.From == x.To || !flow.Nodes.ContainsKey(x.From) || !flow.Nodes.ContainsKey(x.To)) return false;
                foreach (var e in flow.Edges)
                    if (e.Id == x.Edge || (e.From == x.From && e.To == x.To && e.FromSide == x.FromSide && e.ToSide == x.ToSide)) return false;
                flow.Edges.Add(new FlowEdge { Id = x.Edge, From = x.From, FromSide = x.FromSide, To = x.To, ToSide = x.ToSide, Label = x.Label });
                return EditFlowchart(flow, by, at);
            }
            case DisconnectNodes x:
            {
                if (!_flowcharts.TryGetValue(x.Flowchart, out var flow)) return false;
                if (flow.Edges.RemoveAll(e => e.Id == x.Edge) == 0) return false;
                return EditFlowchart(flow, by, at);
            }
            case SetEdgeLabel x:
            {
                if (!_flowcharts.TryGetValue(x.Flowchart, out var flow)) return false;
                var edge = flow.Edges.Find(e => e.Id == x.Edge);
                if (edge is null || edge.Label == x.Label) return false;
                edge.Label = x.Label;
                return EditFlowchart(flow, by, at);
            }

            default:
                return false;
        }
    }

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------

    private bool MarkIndex()
    {
        Pending.IndexDirty = true;
        return true;
    }

    private static int ClampInsert(int index, int count) => index < 0 ? 0 : index > count ? count : index;

    private bool EditCard(CardId id, UserId by, DateTimeOffset at, Func<Card, bool> edit)
    {
        if (!_cards.TryGetValue(id, out var card) || !edit(card)) return false;
        card.Meta.Touch(by, at);
        return MarkIndex();
    }

    /// <summary>
    /// Moves cells (text, colors and, for columns, widths) at or after <paramref name="from"/> by
    /// <paramref name="delta"/> rows or columns. A negative delta deletes the |delta| rows/columns at <paramref name="from"/>.
    /// </summary>
    private static void ShiftCells(Sheet sheet, bool rows, int from, int delta)
    {
        static Dictionary<CellRef, T> Shift<T>(Dictionary<CellRef, T> source, bool rows, int from, int delta)
        {
            var result = new Dictionary<CellRef, T>(source.Count);
            foreach (var (cell, value) in source)
            {
                int index = rows ? cell.Row : cell.Column;
                if (index < from) { result[cell] = value; continue; }
                if (delta < 0 && index < from - delta) continue;          // deleted
                int moved = index + delta;
                result[rows ? cell with { Row = moved } : cell with { Column = moved }] = value;
            }
            return result;
        }

        var cells = Shift(sheet.Cells, rows, from, delta);
        sheet.Cells.Clear();
        foreach (var (k, v) in cells) sheet.Cells[k] = v;
        var styles = Shift(sheet.Styles, rows, from, delta);
        sheet.Styles.Clear();
        foreach (var (k, v) in styles) sheet.Styles[k] = v;

        if (!rows)
        {
            var widths = new Dictionary<int, float>(sheet.ColumnWidths.Count);
            foreach (var (col, w) in sheet.ColumnWidths)
            {
                if (col < from) widths[col] = w;
                else if (delta < 0 && col < from - delta) continue;
                else widths[col + delta] = w;
            }
            sheet.ColumnWidths.Clear();
            foreach (var (k, v) in widths) sheet.ColumnWidths[k] = v;
        }
    }

    private static bool ValidRange(int row, int column, int rows, int columns)
        => row >= 0 && column >= 0 && rows > 0 && columns > 0
           && (long)row + rows <= MaxSheetRows && (long)column + columns <= MaxSheetColumns
           && (long)rows * columns <= 4_000_000;

    private bool EditSheet(Sheet sheet, UserId by, DateTimeOffset at)
    {
        sheet.Meta.Touch(by, at);
        Pending.Sheets.Add(sheet.Id);
        return MarkIndex();
    }

    private bool EditFlowchart(Flowchart flow, UserId by, DateTimeOffset at)
    {
        flow.Meta.Touch(by, at);
        Pending.Flowcharts.Add(flow.Id);
        return MarkIndex();
    }

    private static bool DetachFrom(Card card, Attachment a)
    {
        if (!card.Attachments.Remove(a)) return false;
        if (a.Kind == AttachmentKind.Image && card.CoverImage == ImageId.From(a.TargetId))
        {
            // Fall back to the next attached image, if any.
            card.CoverImage = null;
            foreach (var other in card.Attachments)
            {
                if (other.Kind != AttachmentKind.Image) continue;
                card.CoverImage = ImageId.From(other.TargetId);
                break;
            }
        }
        return true;
    }

    private void DetachEverywhere(Attachment a, UserId by, DateTimeOffset at)
    {
        foreach (var card in _cards.Values)
            if (DetachFrom(card, a)) card.Meta.Touch(by, at);
    }

    public const float MinNodeSize = 40f, MaxNodeSize = 4000f;

    /// <summary>
    /// Makes sure every card is in exactly one column and the board only references real cards.
    /// Protects against hand-edited or partially synced files.
    /// </summary>
    public const string KeyPrefix = "TASK";

    /// <summary>The card's short key, e.g. "TASK-14".</summary>
    public static string KeyOf(Card card) => $"{KeyPrefix}-{card.Number}";

    private int NextCardNumber()
    {
        int max = 0;
        foreach (var c in _cards.Values) if (c.Number > max) max = c.Number;
        return max + 1;
    }

    private void RepairBoard()
    {
        _cardColumn.Clear();
        bool repaired = false;

        // Cards saved before keys existed get numbers in board order.
        foreach (var col in Board.Columns)
            foreach (var id in col.Cards)
                if (_cards.TryGetValue(id, out var unnumbered) && unnumbered.Number == 0)
                {
                    unnumbered.Number = NextCardNumber();
                    repaired = true;
                }

        // A loaded board with cards but no columns gets one so the cards stay visible.
        // (A brand-new workspace adds its own default columns.)
        if (Board.Columns.Count == 0 && _cards.Count > 0)
        {
            Board.Columns.Add(new BoardColumn { Id = ColumnId.New(), Name = "To Do" });
            repaired = true;
        }

        foreach (var col in Board.Columns)
        {
            int removed = col.Cards.RemoveAll(id => !_cards.ContainsKey(id) || _cardColumn.ContainsKey(id));
            repaired |= removed > 0;
            foreach (var id in col.Cards) _cardColumn[id] = col;
        }

        foreach (var id in _cards.Keys)
        {
            if (_cardColumn.ContainsKey(id)) continue;
            Board.Columns[0].Cards.Add(id);
            _cardColumn[id] = Board.Columns[0];
            repaired = true;
        }

        if (repaired) Pending.IndexDirty = true;
    }

    private string UniqueNoteFileName(string title, NoteId self)
    {
        var taken = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var n in _notes.Values)
            if (n.Id != self) taken.Add(n.FileName);

        var stem = FileNames.Sanitize(title);
        var candidate = stem + ".md";
        for (int i = 2; taken.Contains(candidate); i++)
            candidate = $"{stem} ({i}).md";
        return candidate;
    }
}

/// <summary>Turns titles into file names that are valid on Windows, macOS and Linux.</summary>
public static class FileNames
{
    private const int MaxStemLength = 120;
    private static readonly HashSet<string> Reserved = new(StringComparer.OrdinalIgnoreCase)
    {
        "CON", "PRN", "AUX", "NUL",
        "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9",
        "LPT1", "LPT2", "LPT3", "LPT4", "LPT5", "LPT6", "LPT7", "LPT8", "LPT9",
    };

    public static string Sanitize(string title)
    {
        Span<char> buffer = stackalloc char[Math.Min(title.Length, MaxStemLength)];
        int len = 0;
        foreach (char ch in title)
        {
            if (len == buffer.Length) break;
            buffer[len++] = ch < 32 || ch is '<' or '>' or ':' or '"' or '/' or '\\' or '|' or '?' or '*' ? '_' : ch;
        }

        var stem = new string(buffer[..len]).Trim().TrimEnd('.');
        if (stem.Length == 0) stem = "Untitled";
        if (Reserved.Contains(stem)) stem += "_";
        return stem;
    }
}
