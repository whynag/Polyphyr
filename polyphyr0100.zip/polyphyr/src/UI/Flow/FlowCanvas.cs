using System;
using System.Collections.Generic;
using Godot;
using Polyphyr.Core;

namespace Polyphyr.UI.Flow;

/// <summary>
/// The flowchart canvas: shapes you can move, resize, recolor, label and connect from any of
/// their four sides. Custom-drawn and pannable/zoomable.
///
/// Mouse: drag a shape to move it; drag one of its four dots to draw an arrow to another shape;
/// drag the corner handle of the selected shape to resize; double-click a shape or arrow to edit
/// its text; drag empty space (or with the middle button) to pan; Ctrl+wheel to zoom.
/// Right-click for shape, arrow and canvas menus. Delete removes the selection.
/// </summary>
public partial class FlowCanvas : Control
{
    /// <summary>Shapes snap to the dot grid: positions and sizes are whole multiples of this.</summary>
    public const float Grid = 16f;
    private const float Snap = Grid;
    private const float PortRadius = 5f;
    private const float PortHit = 10f;
    private const float HandleSize = 9f;
    private const float MinZoom = 0.35f, MaxZoom = 2.5f;

    private static Color CanvasBg => AppTheme.Canvas;
    private static Color GridDot => AppTheme.GridDot;
    private static Color EdgeColor => AppTheme.Pick("828287", "8e8e93");

    /// <summary>Raised when the selected shape changes (the toolbar enables its color button).</summary>
    public event Action? SelectionChanged;

    private Workspace? _ws;
    private FlowchartId _flowId;

    private Vector2 _pan = new(60, 60);
    private Vector2 _panGoal = new(60, 60);
    private float _zoom = 1f;

    private NodeId? _selNode;
    private EdgeId? _selEdge;
    private NodeId? _hoverNode;
    private (NodeId Node, FlowSide Side)? _hoverPort;

    private enum Drag { None, Pan, Move, Resize, Connect }
    private Drag _drag;
    private Vector2 _dragStartMouse;
    private Vector2 _dragStartPan;
    private NodeId _dragNode;
    private Rect2 _dragRect;              // preview rect (world) while moving or resizing
    private Vector2 _grabOffset;          // mouse → node origin (world); eases to the node's center while held
    private Vector2 _lastMouse;           // screen
    private float _holdTime;              // seconds the node has been held, drives the little shake
    private FlowSide _connectSide;
    private Vector2 _connectMouse;        // world

    private LineEdit _edit = null!;
    private NodeId? _editNode;
    private EdgeId? _editEdge;

    private PopupMenu _nodeMenu = null!, _edgeMenu = null!, _canvasMenu = null!;
    private PopupMenu _shapeMenu = null!;
    private Vector2 _menuWorld;

    public Flowchart? Chart => _ws is not null && _ws.Flowcharts.TryGetValue(_flowId, out var f) ? f : null;
    public FlowNode? SelectedNode => _selNode is { } id && Chart is { } c && c.Nodes.TryGetValue(id, out var n) ? n : null;
    public FlowchartId ChartId => _flowId;

    public override void _Ready()
    {
        FocusMode = FocusModeEnum.All;
        ClipContents = true;
        MouseFilter = MouseFilterEnum.Stop;

        _edit = new LineEdit { Visible = false, Alignment = HorizontalAlignment.Center };
        _edit.AddThemeStyleboxOverride("normal", AppTheme.Box(AppTheme.InputBg, 6, 8, 4, AppTheme.Accent, 1));
        _edit.AddThemeStyleboxOverride("focus", AppTheme.Empty());
        _edit.TextSubmitted += _ => CommitEdit();
        _edit.FocusExited += CommitEdit;
        _edit.GuiInput += e =>
        {
            if (e is InputEventKey { Pressed: true, Keycode: Key.Escape })
            {
                CancelEdit();
                _edit.AcceptEvent();
            }
        };
        AddChild(_edit);

        _shapeMenu = new PopupMenu();
        foreach (FlowShape shape in Enum.GetValues(typeof(FlowShape)))
            _shapeMenu.AddRadioCheckItem(ShapeName(shape), (int)shape);
        _shapeMenu.IdPressed += id =>
        {
            if (_selNode is { } node) _ws?.Apply(new SetFlowNodeShape(_flowId, node, (FlowShape)(int)id));
        };

        _nodeMenu = new PopupMenu();
        _nodeMenu.AddChild(_shapeMenu);
        _nodeMenu.AddItem("Edit text", 0);
        _nodeMenu.AddItem("Color…", 1);
        _nodeMenu.AddSubmenuNodeItem("Shape", _shapeMenu);
        _nodeMenu.AddItem("Duplicate", 3);
        _nodeMenu.AddSeparator();
        _nodeMenu.AddItem("Delete", 2);
        _nodeMenu.IdPressed += OnNodeMenu;
        AddChild(_nodeMenu);

        _edgeMenu = new PopupMenu();
        _edgeMenu.AddItem("Edit label", 0);
        _edgeMenu.AddSeparator();
        _edgeMenu.AddItem("Delete arrow", 1);
        _edgeMenu.IdPressed += OnEdgeMenu;
        AddChild(_edgeMenu);

        _canvasMenu = new PopupMenu();
        foreach (FlowShape shape in Enum.GetValues(typeof(FlowShape)))
            _canvasMenu.AddItem("Add " + ShapeName(shape).ToLowerInvariant(), (int)shape);
        _canvasMenu.AddSeparator();
        _canvasMenu.AddItem("Reset view", 100);
        _canvasMenu.IdPressed += id =>
        {
            if (id == 100) { ResetView(); return; }
            AddNode((FlowShape)(int)id, _menuWorld, centered: true);
        };
        AddChild(_canvasMenu);

        SetProcess(false);
    }

    /// <summary>Raised when the color item is chosen in a shape's menu.</summary>
    public event Action? ColorRequested;

    public static string ShapeName(FlowShape shape) => shape switch
    {
        FlowShape.Terminal => "Start / End",
        FlowShape.Process => "Process",
        FlowShape.Decision => "Decision",
        _ => "Delay",
    };

    public void Load(Workspace ws, FlowchartId id)
    {
        CommitEdit();
        _ws = ws;
        _flowId = id;
        _selNode = null;
        _selEdge = null;
        _drag = Drag.None;
        QueueRedraw();
        SelectionChanged?.Invoke();
    }

    /// <summary>Call after the flowchart changed.</summary>
    public void Refresh()
    {
        if (Chart is { } chart)
        {
            if (_selNode is { } n && !chart.Nodes.ContainsKey(n)) _selNode = null;
            if (_selEdge is { } e && !chart.Edges.Exists(x => x.Id == e)) _selEdge = null;
        }
        QueueRedraw();
        SelectionChanged?.Invoke();
    }

    public void ResetView()
    {
        _zoom = 1f;
        _pan = _panGoal = new Vector2(60, 60);
        QueueRedraw();
    }

    // ------------------------------------------------------------------
    // Adding
    // ------------------------------------------------------------------

    public static Vector2 DefaultSize(FlowShape shape) => shape switch
    {
        FlowShape.Terminal => new Vector2(160, 64),
        FlowShape.Decision => new Vector2(160, 112),
        FlowShape.Delay => new Vector2(176, 64),
        _ => new Vector2(176, 80),
    };

    /// <summary>Adds a shape in the middle of the view (nudged so it doesn't land exactly on another).</summary>
    public void AddNodeAtCenter(FlowShape shape)
    {
        var center = ToWorld(Size / 2);
        var size = DefaultSize(shape);
        var pos = center - size / 2;
        if (Chart is { } chart)
            for (int i = 0; i < 20 && Overlaps(chart, new Rect2(pos, size)); i++) pos += new Vector2(Grid * 2, Grid * 2);
        AddNode(shape, pos, centered: false);
    }

    private static bool Overlaps(Flowchart chart, Rect2 rect)
    {
        foreach (var n in chart.Nodes.Values)
            if (new Rect2(n.X, n.Y, n.Width, n.Height).Intersects(rect.Grow(-10))) return true;
        return false;
    }

    private void AddNode(FlowShape shape, Vector2 world, bool centered)
    {
        if (_ws is null) return;
        var size = DefaultSize(shape);
        var pos = centered ? world - size / 2 : world;
        pos = SnapPoint(pos);
        var id = _ws.NewFlowNode(_flowId, shape, pos.X, pos.Y, shape == FlowShape.Terminal ? "Start" : ShapeName(shape), size.X, size.Y);
        if (id.IsEmpty) return;
        Select(id, null);
        BeginEditNode(id);
    }

    // ------------------------------------------------------------------
    // Coordinates
    // ------------------------------------------------------------------

    private Vector2 ToScreen(Vector2 world) => world * _zoom + _pan;
    private Vector2 ToWorld(Vector2 screen) => (screen - _pan) / _zoom;
    private static Vector2 SnapPoint(Vector2 p) => new(Mathf.Round(p.X / Snap) * Snap, Mathf.Round(p.Y / Snap) * Snap);

    private Rect2 WorldRect(FlowNode n)
    {
        if ((_drag is Drag.Move or Drag.Resize) && n.Id == _dragNode) return _dragRect;
        return new Rect2(n.X, n.Y, n.Width, n.Height);
    }

    private Rect2 ScreenRect(FlowNode n)
    {
        var w = WorldRect(n);
        return new Rect2(ToScreen(w.Position), w.Size * _zoom);
    }

    private static Vector2 Port(Rect2 r, FlowSide side) => side switch
    {
        FlowSide.Top => new Vector2(r.Position.X + r.Size.X / 2, r.Position.Y),
        FlowSide.Right => new Vector2(r.End.X, r.Position.Y + r.Size.Y / 2),
        FlowSide.Bottom => new Vector2(r.Position.X + r.Size.X / 2, r.End.Y),
        _ => new Vector2(r.Position.X, r.Position.Y + r.Size.Y / 2),
    };

    private static Vector2 Normal(FlowSide side) => side switch
    {
        FlowSide.Top => Vector2.Up,
        FlowSide.Right => Vector2.Right,
        FlowSide.Bottom => Vector2.Down,
        _ => Vector2.Left,
    };

    private static readonly FlowSide[] Sides = { FlowSide.Top, FlowSide.Right, FlowSide.Bottom, FlowSide.Left };

    // ------------------------------------------------------------------
    // Hit testing (screen coordinates)
    // ------------------------------------------------------------------

    private IEnumerable<FlowNode> TopDown(Flowchart chart)
    {
        // The selected node is drawn last, so it's on top for clicks too.
        if (_selNode is { } sel && chart.Nodes.TryGetValue(sel, out var s)) yield return s;
        var all = new List<FlowNode>(chart.Nodes.Values);
        for (int i = all.Count - 1; i >= 0; i--)
            if (all[i].Id != _selNode) yield return all[i];
    }

    private FlowNode? NodeAt(Vector2 pos, Flowchart chart)
    {
        foreach (var n in TopDown(chart))
            if (ScreenRect(n).Grow(2).HasPoint(pos)) return n;
        return null;
    }

    private (NodeId, FlowSide)? PortAt(Vector2 pos, Flowchart chart, NodeId? only = null)
    {
        foreach (var n in TopDown(chart))
        {
            if (only is { } o && n.Id != o) continue;
            var r = ScreenRect(n);
            foreach (var side in Sides)
                if (Port(r, side).DistanceTo(pos) <= PortHit) return (n.Id, side);
        }
        return null;
    }

    /// <summary>The side of a node nearest the point (for dropping an arrow anywhere on a shape).</summary>
    private FlowSide NearestSide(FlowNode n, Vector2 pos)
    {
        var r = ScreenRect(n);
        FlowSide best = FlowSide.Top;
        float bestDist = float.MaxValue;
        foreach (var side in Sides)
        {
            float d = Port(r, side).DistanceSquaredTo(pos);
            if (d < bestDist) { bestDist = d; best = side; }
        }
        return best;
    }

    private Rect2 HandleRect(Rect2 screen) => new(screen.End - new Vector2(HandleSize, HandleSize) * 0.5f, new Vector2(HandleSize, HandleSize));

    private EdgeId? EdgeAt(Vector2 pos, Flowchart chart)
    {
        foreach (var e in chart.Edges)
        {
            if (!TryEdgePoints(chart, e, out var pts)) continue;
            for (int i = 0; i < pts.Length - 1; i++)
                if (DistanceToSegment(pos, pts[i], pts[i + 1]) <= 6f) return e.Id;
        }
        return null;
    }

    private static float DistanceToSegment(Vector2 p, Vector2 a, Vector2 b)
    {
        var ab = b - a;
        float t = ab.LengthSquared() < 0.0001f ? 0 : Mathf.Clamp((p - a).Dot(ab) / ab.LengthSquared(), 0, 1);
        return p.DistanceTo(a + ab * t);
    }

    // ------------------------------------------------------------------
    // Edge geometry
    // ------------------------------------------------------------------

    private bool TryEdgePoints(Flowchart chart, FlowEdge e, out Vector2[] points)
    {
        points = Array.Empty<Vector2>();
        if (!chart.Nodes.TryGetValue(e.From, out var a) || !chart.Nodes.TryGetValue(e.To, out var b)) return false;
        var p0 = Port(ScreenRect(a), e.FromSide);
        var p3 = Port(ScreenRect(b), e.ToSide);
        points = Curve(p0, Normal(e.FromSide), p3, Normal(e.ToSide));
        return true;
    }

    /// <summary>A smooth curve leaving <paramref name="p0"/> along <paramref name="n0"/> and arriving at <paramref name="p3"/> against <paramref name="n3"/>.</summary>
    private Vector2[] Curve(Vector2 p0, Vector2 n0, Vector2 p3, Vector2 n3)
    {
        float k = Mathf.Clamp(p0.DistanceTo(p3) * 0.45f, 30f * _zoom, 160f * _zoom);
        var p1 = p0 + n0 * k;
        var p2 = p3 + n3 * k;
        const int steps = 28;
        var pts = new Vector2[steps + 1];
        for (int i = 0; i <= steps; i++)
        {
            float t = i / (float)steps, u = 1 - t;
            pts[i] = u * u * u * p0 + 3 * u * u * t * p1 + 3 * u * t * t * p2 + t * t * t * p3;
        }
        return pts;
    }

    // ------------------------------------------------------------------
    // Drawing
    // ------------------------------------------------------------------

    public static Color DefaultFill(FlowShape shape) => shape switch
    {
        FlowShape.Terminal => AppTheme.Pick("1d3a2a", "d6efdf"),
        FlowShape.Decision => AppTheme.Pick("3a3017", "f6ebc7"),
        FlowShape.Delay => AppTheme.Pick("2d2140", "e6ddf6"),
        _ => AppTheme.Pick("1b2433", "dbe5f5"),
    };

    public static Color FillOf(FlowNode n)
        => n.Color is { } hex && Color.HtmlIsValid(hex) ? Color.FromHtml(hex) : DefaultFill(n.Shape);

    public override void _Draw()
    {
        DrawRect(new Rect2(Vector2.Zero, Size), CanvasBg);
        DrawGrid();
        if (Chart is not { } chart) return;

        // Arrows under the shapes.
        foreach (var e in chart.Edges)
        {
            if (!TryEdgePoints(chart, e, out var pts)) continue;
            bool selected = _selEdge == e.Id;
            var color = selected ? AppTheme.Accent : EdgeColor;
            DrawPolyline(pts, color, selected ? 2.5f : 1.8f, true);
            DrawArrowHead(pts[^1], -Normal(e.ToSide), color);
        }

        // Arrow being drawn
        if (_drag == Drag.Connect && chart.Nodes.TryGetValue(_dragNode, out var from))
        {
            var p0 = Port(ScreenRect(from), _connectSide);
            var end = ToScreen(_connectMouse);
            var endNormal = -(end - p0).Normalized();
            if (_hoverPort is { } hp && hp.Node != _dragNode && chart.Nodes.TryGetValue(hp.Node, out var target))
            {
                end = Port(ScreenRect(target), hp.Side);
                endNormal = Normal(hp.Side);
            }
            var pts = Curve(p0, Normal(_connectSide), end, endNormal);
            DrawPolyline(pts, AppTheme.Accent, 2f, true);
            DrawArrowHead(end, -endNormal, AppTheme.Accent);
        }

        // Shapes
        foreach (var n in chart.Nodes.Values)
            if (n.Id != _selNode) DrawNode(n, false);
        if (SelectedNode is { } sel)
        {
            if (_drag == Drag.Move && sel.Id == _dragNode) DrawHeld(sel);
            else DrawNode(sel, true);
        }

        // Labels on top
        foreach (var e in chart.Edges)
        {
            if (e.Label.Length == 0 || (_editEdge == e.Id) || !TryEdgePoints(chart, e, out var pts)) continue;
            DrawLabel(pts[pts.Length / 2], e.Label, _selEdge == e.Id);
        }

        // Ports on the hovered / selected / source node
        var portNodes = new HashSet<NodeId>();
        if (_hoverNode is { } h) portNodes.Add(h);
        if (_selNode is { } s) portNodes.Add(s);
        if (_drag == Drag.Connect) portNodes.Add(_dragNode);
        if (_drag == Drag.Connect && _hoverPort is { } hov) portNodes.Add(hov.Node);
        if (_drag is Drag.Move or Drag.Resize or Drag.Pan) portNodes.Clear();
        foreach (var id in portNodes)
        {
            if (!chart.Nodes.TryGetValue(id, out var n)) continue;
            var r = ScreenRect(n);
            foreach (var side in Sides)
            {
                bool hot = _hoverPort is { } p && p.Node == id && p.Side == side;
                var c = Port(r, side);
                DrawCircle(c, hot ? PortRadius + 2 : PortRadius, hot ? AppTheme.Accent : AppTheme.Text);
                DrawArc(c, hot ? PortRadius + 2 : PortRadius, 0, Mathf.Tau, 20, CanvasBg, 1.5f, true);
            }
        }
    }

    /// <summary>A node being carried: where it will land, a soft shadow, and the node itself, lifted and shaking slightly.</summary>
    private void DrawHeld(FlowNode n)
    {
        var landing = new Rect2(ToScreen(DropPosition()), _dragRect.Size * _zoom);
        DrawStyleBox(AppTheme.Box(new Color(AppTheme.Accent, 0.06f), 8, 0, 0, new Color(AppTheme.Accent, 0.45f), 1), landing);

        var r = ScreenRect(n);
        var center = r.GetCenter();
        float settle = Mathf.Min(1f, _holdTime * 6f);
        float angle = Mathf.Sin(_holdTime * 14f) * 0.028f * settle;          // about ±1.6°
        float lift = 1f + 0.035f * settle;
        DrawStyleBox(AppTheme.Box(new Color(0, 0, 0, AppTheme.IsLight ? 0.12f : 0.4f), 12), new Rect2(r.Position + new Vector2(0, 8 * settle), r.Size).Grow(3));

        var xf = new Transform2D(angle, new Vector2(lift, lift), 0, center) * new Transform2D(0, -center);
        DrawSetTransformMatrix(xf);
        DrawNode(n, true);
        DrawSetTransformMatrix(Transform2D.Identity);
    }

    private void DrawGrid()
    {
        float step = Grid * _zoom;
        while (step < 12f) step *= 2;   // thin the dots out when zoomed far out
        var start = new Vector2(Mathf.PosMod(_pan.X, step), Mathf.PosMod(_pan.Y, step));
        for (float x = start.X; x < Size.X; x += step)
            for (float y = start.Y; y < Size.Y; y += step)
                DrawRect(new Rect2(x - 1, y - 1, 2, 2), GridDot);
    }

    private void DrawArrowHead(Vector2 tip, Vector2 dir, Color color)
    {
        if (dir.LengthSquared() < 0.0001f) return;
        dir = dir.Normalized();
        float size = 9f * Mathf.Clamp(_zoom, 0.6f, 1.4f);
        var side = new Vector2(-dir.Y, dir.X) * size * 0.55f;
        var back = tip - dir * size;
        DrawColoredPolygon(new[] { tip, back + side, back - side }, color);
    }

    private void DrawLabel(Vector2 at, string text, bool selected)
    {
        var font = AppFonts.Medium;
        int size = Math.Max(8, (int)Mathf.Round(12 * _zoom));
        var textSize = font.GetStringSize(text, HorizontalAlignment.Left, -1, size);
        var box = new Rect2(at - textSize / 2 - new Vector2(6, 3), textSize + new Vector2(12, 6));
        DrawStyleBox(AppTheme.Box(CanvasBg, 5, 0, 0, selected ? AppTheme.Accent : AppTheme.Border, 1), box);
        DrawString(font, new Vector2(box.Position.X + 6, box.Position.Y + 3 + font.GetAscent(size)), text,
            HorizontalAlignment.Left, -1, size, AppTheme.Text);
    }

    private void DrawNode(FlowNode n, bool selected)
    {
        var r = ScreenRect(n);
        var fill = FillOf(n);
        var border = selected ? AppTheme.Accent : AppTheme.IsLight ? fill.Darkened(0.25f) : fill.Lightened(0.35f);
        float bw = selected ? 2f : 1.5f;

        switch (n.Shape)
        {
            case FlowShape.Terminal:
                DrawStyleBox(AppTheme.Box(fill, (int)Mathf.Min(r.Size.X, r.Size.Y) / 2, 0, 0, border, (int)Mathf.Ceil(bw)), r);
                break;
            case FlowShape.Process:
                DrawStyleBox(AppTheme.Box(fill, (int)Mathf.Max(2, 4 * _zoom), 0, 0, border, (int)Mathf.Ceil(bw)), r);
                break;
            case FlowShape.Decision:
            {
                var pts = new[] { Port(r, FlowSide.Top), Port(r, FlowSide.Right), Port(r, FlowSide.Bottom), Port(r, FlowSide.Left) };
                DrawColoredPolygon(pts, fill);
                DrawPolyline(new[] { pts[0], pts[1], pts[2], pts[3], pts[0] }, border, bw, true);
                break;
            }
            case FlowShape.Delay:
            {
                var pts = DelayOutline(r);
                DrawColoredPolygon(pts, fill);
                var closed = new Vector2[pts.Length + 1];
                Array.Copy(pts, closed, pts.Length);
                closed[^1] = pts[0];
                DrawPolyline(closed, border, bw, true);
                break;
            }
        }

        // Text, centered and wrapped inside the shape.
        if (n.Id != _editNode && n.Text.Length > 0)
        {
            var font = AppFonts.Medium;
            int size = Math.Max(6, (int)Mathf.Round(14 * _zoom));
            float inset = n.Shape == FlowShape.Decision ? r.Size.X * 0.22f : n.Shape == FlowShape.Terminal ? r.Size.Y * 0.3f : 10f * _zoom;
            float width = Mathf.Max(10, r.Size.X - inset * 2);
            var flags = TextServer.LineBreakFlag.WordBound | TextServer.LineBreakFlag.Adaptive | TextServer.LineBreakFlag.Mandatory;
            int maxLines = Math.Max(1, (int)((r.Size.Y - 8 * _zoom) / font.GetHeight(size)));
            var textSize = font.GetMultilineStringSize(n.Text, HorizontalAlignment.Center, width, size, maxLines, flags);
            float top = r.Position.Y + (r.Size.Y - textSize.Y) / 2 + font.GetAscent(size);
            DrawMultilineString(font, new Vector2(r.Position.X + inset, top), n.Text, HorizontalAlignment.Center, width, size,
                maxLines, TextColorFor(fill), flags);
        }

        if (selected)
        {
            var hr = HandleRect(r);
            DrawRect(hr, AppTheme.Accent);
            DrawRect(hr, CanvasBg, false, 1f);
        }
    }

    /// <summary>Flat on the left, a half-circle on the right.</summary>
    private static Vector2[] DelayOutline(Rect2 r)
    {
        float radius = Mathf.Min(r.Size.Y / 2, r.Size.X);
        var center = new Vector2(r.End.X - radius, r.Position.Y + r.Size.Y / 2);
        var pts = new List<Vector2> { r.Position, new(center.X, r.Position.Y) };
        const int steps = 18;
        for (int i = 1; i < steps; i++)
        {
            float a = -Mathf.Pi / 2 + Mathf.Pi * i / steps;
            pts.Add(center + new Vector2(Mathf.Cos(a) * radius, Mathf.Sin(a) * (r.Size.Y / 2)));
        }
        pts.Add(new Vector2(center.X, r.End.Y));
        pts.Add(new Vector2(r.Position.X, r.End.Y));
        return pts.ToArray();
    }

    private static Color TextColorFor(Color fill)
        => fill.Luminance > 0.55f ? new Color("121214") : new Color("f0f0f0");

    // ------------------------------------------------------------------
    // Input
    // ------------------------------------------------------------------

    public override int _GetCursorShape(Vector2 atPosition)
    {
        if (_drag == Drag.Pan) return (int)CursorShape.Drag;
        if (_drag == Drag.Resize) return (int)CursorShape.Fdiagsize;
        if (Chart is { } chart)
        {
            if (SelectedNode is { } sel && HandleRect(ScreenRect(sel)).Grow(3).HasPoint(atPosition)) return (int)CursorShape.Fdiagsize;
            if (_hoverPort is not null) return (int)CursorShape.Cross;
            if (NodeAt(atPosition, chart) is not null) return (int)CursorShape.Move;
        }
        return (int)CursorShape.Arrow;
    }

    public override void _GuiInput(InputEvent @event)
    {
        if (Chart is not { } chart) return;
        switch (@event)
        {
            case InputEventMouseButton { Pressed: true } mb when mb.ButtonIndex is MouseButton.WheelUp or MouseButton.WheelDown or MouseButton.WheelLeft or MouseButton.WheelRight:
                OnWheel(mb);
                AcceptEvent();
                break;
            case InputEventMouseButton { ButtonIndex: MouseButton.Middle } mb:
                if (mb.Pressed) StartPan(mb.Position);
                else EndDrag(mb.Position, chart);
                AcceptEvent();
                break;
            case InputEventMouseButton { ButtonIndex: MouseButton.Left } mb:
                if (mb.Pressed) OnLeftPress(mb, chart);
                else EndDrag(mb.Position, chart);
                AcceptEvent();
                break;
            case InputEventMouseButton { ButtonIndex: MouseButton.Right, Pressed: true } mb:
                OnRightPress(mb.Position, chart);
                AcceptEvent();
                break;
            case InputEventMouseMotion mm:
                OnMotion(mm.Position, chart);
                break;
            case InputEventKey { Pressed: true } key:
                OnKey(key);
                break;
        }
    }

    private void OnWheel(InputEventMouseButton mb)
    {
        float factor = mb.Factor > 0 ? mb.Factor : 1f;
        bool up = mb.ButtonIndex is MouseButton.WheelUp or MouseButton.WheelLeft;
        if (mb.CtrlPressed || mb.MetaPressed)
        {
            // Zoom around the mouse.
            float old = _zoom;
            _zoom = Mathf.Clamp(_zoom * (up ? 1.12f : 1f / 1.12f), MinZoom, MaxZoom);
            var world = (mb.Position - _pan) / old;
            _pan = _panGoal = mb.Position - world * _zoom;
            PlaceEditor();
            QueueRedraw();
            return;
        }
        bool horizontal = mb.ShiftPressed || mb.ButtonIndex is MouseButton.WheelLeft or MouseButton.WheelRight;
        var delta = (horizontal ? Vector2.Right : Vector2.Down) * (up ? 1f : -1f) * 90f * factor;
        _panGoal += delta;
        SetProcess(true);
    }

    public override void _Process(double delta)
    {
        float dt = (float)delta;
        // Smooth panning toward the goal.
        float t = 1f - MathF.Exp(-ScrollGlide.Sharpness * dt);
        _pan = _pan.Lerp(_panGoal, t);
        bool panning = _pan.DistanceTo(_panGoal) >= 0.5f;
        if (!panning) _pan = _panGoal;

        if (_drag == Drag.Move)
        {
            // Ease the grab point to the node's center, so a node picked up by its edge glides under the cursor.
            _holdTime += dt;
            _grabOffset = _grabOffset.Lerp(_dragRect.Size / 2, 1f - MathF.Exp(-18f * dt));
            _dragRect.Position = ToWorld(_lastMouse) - _grabOffset;
        }

        if (!panning && _drag != Drag.Move) SetProcess(false);
        PlaceEditor();
        QueueRedraw();
    }

    /// <summary>Where a held node lands if dropped now: centered on the cursor, snapped to the grid.</summary>
    private Vector2 DropPosition() => SnapPoint(ToWorld(_lastMouse) - _dragRect.Size / 2);

    public override void _Notification(int what)
    {
        // Losing focus mid-drag (e.g. alt-tab) can swallow the mouse release: drop the drag instead of
        // leaving it stuck.
        if ((long)what is NotificationWMWindowFocusOut or NotificationApplicationFocusOut && _drag != Drag.None)
        {
            if (_drag == Drag.Move && Chart is { } chart) EndDrag(_lastMouse, chart);
            else _drag = Drag.None;
            QueueRedraw();
        }
    }

    private void StartPan(Vector2 pos)
    {
        CommitEdit();
        _drag = Drag.Pan;
        _dragStartMouse = pos;
        _dragStartPan = _pan;
        _panGoal = _pan;
    }

    private void OnLeftPress(InputEventMouseButton mb, Flowchart chart)
    {
        GrabFocus();
        var pos = mb.Position;
        CommitEdit();

        // 1. A connection dot: start an arrow.
        if (PortAt(pos, chart) is { } port && (port.Item1 == _hoverNode || port.Item1 == _selNode))
        {
            _drag = Drag.Connect;
            _dragNode = port.Item1;
            _connectSide = port.Item2;
            _connectMouse = ToWorld(pos);
            QueueRedraw();
            return;
        }

        // 2. The resize handle of the selected shape.
        if (SelectedNode is { } sel && HandleRect(ScreenRect(sel)).Grow(3).HasPoint(pos))
        {
            _drag = Drag.Resize;
            _dragNode = sel.Id;
            _dragRect = new Rect2(sel.X, sel.Y, sel.Width, sel.Height);
            _dragStartMouse = pos;
            return;
        }

        // 3. A shape: select and move it (double-click edits its text).
        if (NodeAt(pos, chart) is { } node)
        {
            Select(node.Id, null);
            if (mb.DoubleClick)
            {
                BeginEditNode(node.Id);
                return;
            }
            // Picked up: the node lifts, shakes gently, and slides so the cursor is at its middle.
            _drag = Drag.Move;
            _dragNode = node.Id;
            _dragRect = new Rect2(node.X, node.Y, node.Width, node.Height);
            _grabOffset = ToWorld(pos) - _dragRect.Position;
            _lastMouse = pos;
            _holdTime = 0;
            SetProcess(true);
            return;
        }

        // 4. An arrow: select it (double-click edits its label).
        if (EdgeAt(pos, chart) is { } edge)
        {
            Select(null, edge);
            if (mb.DoubleClick) BeginEditEdge(edge);
            return;
        }

        // 5. Empty canvas: deselect and pan.
        Select(null, null);
        StartPan(pos);
    }

    private void OnMotion(Vector2 pos, Flowchart chart)
    {
        switch (_drag)
        {
            case Drag.Pan:
                _pan = _panGoal = _dragStartPan + (pos - _dragStartMouse);
                PlaceEditor();
                QueueRedraw();
                return;
            case Drag.Move:
                _lastMouse = pos;
                _dragRect.Position = ToWorld(pos) - _grabOffset;
                QueueRedraw();
                return;
            case Drag.Resize:
            {
                var world = ToWorld(pos);
                var size = SnapPoint(world - _dragRect.Position);
                _dragRect.Size = new Vector2(Mathf.Max(Workspace.MinNodeSize, size.X), Mathf.Max(Workspace.MinNodeSize, size.Y));
                QueueRedraw();
                return;
            }
            case Drag.Connect:
            {
                _connectMouse = ToWorld(pos);
                // Snap to a dot, or to the nearest side of whatever shape is under the mouse.
                var hit = PortAt(pos, chart);
                if (hit is null && NodeAt(pos, chart) is { } over && over.Id != _dragNode)
                    hit = (over.Id, NearestSide(over, pos));
                _hoverPort = hit is { } h && h.Item1 != _dragNode ? (h.Item1, h.Item2) : null;
                _hoverNode = _hoverPort?.Node;
                QueueRedraw();
                return;
            }
        }

        // Hover: which shape and which dot.
        var node = NodeAt(pos, chart);
        var nodeId = node?.Id;
        (NodeId, FlowSide)? port = null;
        // Dots sit on the edge, so look for them on the hovered or selected shape even just outside it.
        foreach (var candidate in new[] { nodeId, _hoverNode, _selNode })
            if (candidate is { } c && PortAt(pos, chart, c) is { } p) { port = p; nodeId = c; break; }
        var newPort = port is { } pp ? (pp.Item1, pp.Item2) : ((NodeId, FlowSide)?)null;
        if (nodeId != _hoverNode || !Nullable.Equals(newPort, _hoverPort))
        {
            _hoverNode = nodeId;
            _hoverPort = newPort;
            QueueRedraw();
        }
    }

    private void EndDrag(Vector2 pos, Flowchart chart)
    {
        var drag = _drag;
        _drag = Drag.None;
        switch (drag)
        {
            case Drag.Move when chart.Nodes.TryGetValue(_dragNode, out var n):
            {
                // Dropped with its middle under the cursor, snapped to the grid.
                _lastMouse = pos;
                var drop = DropPosition();
                if (drop != new Vector2(n.X, n.Y))
                    _ws?.Apply(new MoveFlowNode(_flowId, n.Id, drop.X, drop.Y));
                break;
            }
            case Drag.Resize when chart.Nodes.TryGetValue(_dragNode, out var n):
                if (_dragRect.Size != new Vector2(n.Width, n.Height))
                    _ws?.Apply(new ResizeFlowNode(_flowId, n.Id, _dragRect.Size.X, _dragRect.Size.Y));
                break;
            case Drag.Connect:
                if (_hoverPort is { } target && target.Node != _dragNode && _ws is not null)
                {
                    var id = _ws.Connect(_flowId, _dragNode, _connectSide, target.Node, target.Side);
                    if (!id.IsEmpty) Select(null, id);
                }
                _hoverPort = null;
                break;
        }
        OnMotion(pos, chart);
        QueueRedraw();
    }

    private void OnKey(InputEventKey key)
    {
        switch (key.Keycode)
        {
            case Key.Delete or Key.Backspace:
                DeleteSelection();
                AcceptEvent();
                break;
            case Key.Escape:
                Select(null, null);
                AcceptEvent();
                break;
            case Key.Enter or Key.KpEnter or Key.F2:
                if (_selNode is { } n) BeginEditNode(n);
                else if (_selEdge is { } e) BeginEditEdge(e);
                AcceptEvent();
                break;
            case Key.D when key.CtrlPressed || key.MetaPressed:
                Duplicate();
                AcceptEvent();
                break;
        }
    }

    private void Select(NodeId? node, EdgeId? edge)
    {
        _selNode = node;
        _selEdge = edge;
        QueueRedraw();
        SelectionChanged?.Invoke();
    }

    public void DeleteSelection()
    {
        if (_ws is null) return;
        if (_selNode is { } n) _ws.Apply(new RemoveFlowNode(_flowId, n));
        else if (_selEdge is { } e) _ws.Apply(new DisconnectNodes(_flowId, e));
        Select(null, null);
    }

    private void Duplicate()
    {
        if (_ws is null || SelectedNode is not { } n) return;
        var id = NodeId.New();
        if (_ws.Apply(new AddFlowNode(_flowId, id, n.Shape, n.Text, n.X + Grid * 2, n.Y + Grid * 2, n.Width, n.Height, n.Color)))
            Select(id, null);
    }

    // ------------------------------------------------------------------
    // Menus
    // ------------------------------------------------------------------

    private void OnRightPress(Vector2 pos, Flowchart chart)
    {
        GrabFocus();
        CommitEdit();
        var at = TextFieldMenu.PopupPosition(this);
        if (NodeAt(pos, chart) is { } node)
        {
            Select(node.Id, null);
            for (int i = 0; i < _shapeMenu.ItemCount; i++)
                _shapeMenu.SetItemChecked(i, _shapeMenu.GetItemId(i) == (int)node.Shape);
            PopupAt(_nodeMenu, at);
        }
        else if (EdgeAt(pos, chart) is { } edge)
        {
            Select(null, edge);
            PopupAt(_edgeMenu, at);
        }
        else
        {
            Select(null, null);
            _menuWorld = ToWorld(pos);
            PopupAt(_canvasMenu, at);
        }
    }

    private static void PopupAt(PopupMenu menu, Vector2I at)
    {
        menu.ResetSize();
        menu.Position = at;
        menu.Popup();
    }

    private void OnNodeMenu(long id)
    {
        if (_selNode is not { } node) return;
        switch ((int)id)
        {
            case 0: BeginEditNode(node); break;
            case 1: ColorRequested?.Invoke(); break;
            case 2: DeleteSelection(); break;
            case 3: Duplicate(); break;
        }
    }

    private void OnEdgeMenu(long id)
    {
        if (_selEdge is not { } edge) return;
        if (id == 0) BeginEditEdge(edge);
        else DeleteSelection();
    }

    // ------------------------------------------------------------------
    // Text editing
    // ------------------------------------------------------------------

    private void BeginEditNode(NodeId id)
    {
        if (Chart is not { } chart || !chart.Nodes.TryGetValue(id, out var n)) return;
        _editEdge = null;
        _editNode = id;
        _edit.Text = n.Text;
        _edit.Visible = true;
        PlaceEditor();
        _edit.GrabFocus();
        _edit.SelectAll();
        QueueRedraw();
    }

    private void BeginEditEdge(EdgeId id)
    {
        if (Chart is not { } chart || chart.Edges.Find(e => e.Id == id) is not { } edge) return;
        _editNode = null;
        _editEdge = id;
        _edit.Text = edge.Label;
        _edit.Visible = true;
        PlaceEditor();
        _edit.GrabFocus();
        _edit.SelectAll();
        QueueRedraw();
    }

    private void PlaceEditor()
    {
        if (!_edit.Visible || Chart is not { } chart) return;
        if (_editNode is { } nid && chart.Nodes.TryGetValue(nid, out var n))
        {
            var r = ScreenRect(n);
            float w = Mathf.Max(120f, r.Size.X - 16f);
            _edit.Size = new Vector2(w, 32);
            _edit.Position = r.GetCenter() - _edit.Size / 2;
        }
        else if (_editEdge is { } eid && chart.Edges.Find(e => e.Id == eid) is { } edge && TryEdgePoints(chart, edge, out var pts))
        {
            _edit.Size = new Vector2(160, 30);
            _edit.Position = pts[pts.Length / 2] - _edit.Size / 2;
        }
    }

    private void CommitEdit()
    {
        if (!_edit.Visible) return;
        _edit.Visible = false;
        string text = _edit.Text.Trim();
        if (_ws is not null)
        {
            if (_editNode is { } n) _ws.Apply(new SetFlowNodeText(_flowId, n, text));
            else if (_editEdge is { } e) _ws.Apply(new SetEdgeLabel(_flowId, e, text));
        }
        _editNode = null;
        _editEdge = null;
        if (IsVisibleInTree()) GrabFocus();
        QueueRedraw();
    }

    private void CancelEdit()
    {
        _editNode = null;
        _editEdge = null;
        _edit.Visible = false;
        GrabFocus();
        QueueRedraw();
    }
}
