using System;
using System.Linq;
using Godot;
using Polyphyr.Core;
using Polyphyr.UI.Sheets;

namespace Polyphyr.UI.Flow;

/// <summary>
/// The Flowchart tab: a toolbar for adding shapes and recoloring the selected one, over the canvas.
/// Uses the workspace's first flowchart (creating one if there is none).
/// </summary>
public partial class FlowchartTab : VBoxContainer
{
    private Workspace? _ws;
    private FlowCanvas _canvas = null!;
    private ColorToolButton _colorButton = null!;
    private Button _deleteButton = null!;
    private ColorMenu _colorMenu = null!;

    public override void _Ready()
    {
        AddThemeConstantOverride("separation", 0);

        var toolbarPad = new MarginContainer();
        toolbarPad.AddThemeConstantOverride("margin_left", 4);
        toolbarPad.AddThemeConstantOverride("margin_top", 12);
        toolbarPad.AddThemeConstantOverride("margin_bottom", 10);
        AddChild(toolbarPad);
        var toolbar = new HBoxContainer();
        toolbar.AddThemeConstantOverride("separation", 6);
        toolbarPad.AddChild(toolbar);

        foreach (FlowShape shape in Enum.GetValues(typeof(FlowShape)))
        {
            var add = new ShapeButton { Shape = shape, Text = FlowCanvas.ShapeName(shape), TooltipText = $"Add a {FlowCanvas.ShapeName(shape).ToLowerInvariant()} shape" };
            var s = shape;
            add.Pressed += () => _canvas.AddNodeAtCenter(s);
            toolbar.AddChild(add);
        }

        toolbar.AddChild(new VSeparator());
        _colorButton = new ColorToolButton { Text = "Color", TooltipText = "Recolor the selected shape" };
        _colorButton.Pressed += OpenColorMenu;
        toolbar.AddChild(_colorButton);
        _deleteButton = new Button { Text = "Delete", FocusMode = FocusModeEnum.None, TooltipText = "Delete the selected shape or arrow (Delete)" };
        _deleteButton.Pressed += () => _canvas.DeleteSelection();
        toolbar.AddChild(_deleteButton);

        toolbar.AddChild(new Control { SizeFlagsHorizontal = SizeFlags.ExpandFill });
        var hint = new Label
        {
            Text = "Drag a dot to connect  ·  double-click to edit text  ·  Ctrl+scroll to zoom  ·  right-click for more",
            VerticalAlignment = VerticalAlignment.Center,
        };
        hint.AddThemeColorOverride("font_color", AppTheme.TextFaint);
        hint.AddThemeFontSizeOverride("font_size", 12);
        toolbar.AddChild(hint);

        _canvas = new FlowCanvas { SizeFlagsVertical = SizeFlags.ExpandFill, SizeFlagsHorizontal = SizeFlags.ExpandFill };
        AddChild(_canvas);
        _canvas.SelectionChanged += UpdateToolbar;
        _canvas.ColorRequested += OpenColorMenu;

        _colorMenu = new ColorMenu();
        AddChild(_colorMenu);
        UpdateToolbar();
    }

    public void Bind(Workspace ws)
    {
        if (_ws is not null) _ws.Changed -= OnChanged;
        _ws = ws;
        _ws.Changed += OnChanged;
        var chart = ws.Flowcharts.Values.FirstOrDefault();
        var id = chart?.Id ?? ws.NewFlowchart("Main");
        _canvas.Load(ws, id);
    }

    private void OnChanged(Change change)
    {
        if (change is AddFlowNode or MoveFlowNode or ResizeFlowNode or SetFlowNodeText or SetFlowNodeColor
            or SetFlowNodeShape or RemoveFlowNode or ConnectNodes or DisconnectNodes or SetEdgeLabel or DeleteFlowchart)
            _canvas.Refresh();
    }

    private void UpdateToolbar()
    {
        var node = _canvas.SelectedNode;
        _colorButton.Disabled = node is null;
        _colorButton.Swatch = node is null ? null : FlowCanvas.FillOf(node);
    }

    private void OpenColorMenu()
    {
        if (_ws is null || _canvas.SelectedNode is not { } node) return;
        var ws = _ws;
        var chart = _canvas.ChartId;
        var nodeId = node.Id;
        var at = GetViewport().GuiEmbedSubwindows
            ? (Vector2I)(_colorButton.GetGlobalRect().Position + new Vector2(0, _colorButton.Size.Y + 4))
            : (Vector2I)(_colorButton.GetScreenPosition() + new Vector2(0, _colorButton.Size.Y + 4));
        _colorMenu.Open(at, "Shape color", FlowCanvas.FillOf(node), hex =>
        {
            ws.Apply(new SetFlowNodeColor(chart, nodeId, hex));
            _canvas.GrabFocus();
        });
    }
}

/// <summary>Toolbar button with a small drawing of the shape it adds.</summary>
public partial class ShapeButton : Button
{
    public FlowShape Shape { get; set; }

    public ShapeButton()
    {
        FocusMode = FocusModeEnum.None;
        CustomMinimumSize = new Vector2(0, 30);
        AddThemeFontSizeOverride("font_size", 13);
    }

    public override void _Ready()
    {
        // Room on the left for the little shape.
        foreach (var state in new[] { "normal", "hover", "pressed", "hover_pressed" })
        {
            if (GetThemeStylebox(state) is StyleBoxFlat box)
            {
                var copy = (StyleBoxFlat)box.Duplicate();
                copy.ContentMarginLeft = 34;
                AddThemeStyleboxOverride(state, copy);
            }
        }
    }

    public override void _Draw()
    {
        var color = FlowCanvas.DefaultFill(Shape).Lightened(0.45f);
        var r = new Rect2(10, (Size.Y - 12) / 2, 18, 12);
        switch (Shape)
        {
            case FlowShape.Terminal:
                DrawStyleBox(AppTheme.Box(new Color(0, 0, 0, 0), 6, 0, 0, color, 1), r);
                break;
            case FlowShape.Process:
                DrawRect(r, color, false, 1.2f);
                break;
            case FlowShape.Decision:
            {
                var c = r.GetCenter();
                var pts = new[] { new Vector2(c.X, r.Position.Y - 1), new Vector2(r.End.X, c.Y), new Vector2(c.X, r.End.Y + 1), new Vector2(r.Position.X, c.Y), new Vector2(c.X, r.Position.Y - 1) };
                DrawPolyline(pts, color, 1.2f, true);
                break;
            }
            default:
            {
                float rad = r.Size.Y / 2;
                var center = new Vector2(r.End.X - rad, r.Position.Y + rad);
                DrawLine(r.Position, new Vector2(center.X, r.Position.Y), color, 1.2f, true);
                DrawLine(new Vector2(r.Position.X, r.End.Y), new Vector2(center.X, r.End.Y), color, 1.2f, true);
                DrawLine(r.Position, new Vector2(r.Position.X, r.End.Y), color, 1.2f, true);
                DrawArc(center, rad, -Mathf.Pi / 2, Mathf.Pi / 2, 12, color, 1.2f, true);
                break;
            }
        }
    }
}
