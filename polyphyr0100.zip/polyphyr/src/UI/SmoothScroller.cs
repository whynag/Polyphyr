using System;
using Godot;

namespace Polyphyr.UI;

/// <summary>
/// The easing shared by every smooth scroll in the app: each wheel notch moves a goal, and the
/// visible position glides toward it (fast at first, settling gently).
/// </summary>
public struct ScrollGlide
{
    /// <summary>Higher = snappier. ~16 settles a notch in roughly 0.2 s.</summary>
    public const float Sharpness = 16f;

    public float Goal;
    public bool Active;

    /// <summary>Adds a wheel step. Starts from the current position when not already gliding.</summary>
    public void Push(float current, float delta, float max)
    {
        if (!Active) Goal = current;
        Goal = Mathf.Clamp(Goal + delta, 0f, Mathf.Max(0f, max));
        Active = true;
    }

    /// <summary>Moves <paramref name="current"/> toward the goal. Stops gliding once it arrives.</summary>
    public float Step(float current, float dt)
    {
        if (!Active) return current;
        float next = Mathf.Lerp(current, Goal, 1f - MathF.Exp(-Sharpness * dt));
        if (MathF.Abs(Goal - next) < 0.5f)
        {
            next = Goal;
            Active = false;
        }
        return next;
    }

    public void Stop() => Active = false;
}

/// <summary>
/// Makes a <see cref="ScrollContainer"/> scroll smoothly with the mouse wheel.
/// Wheel events over the container are taken before the container sees them, and the vertical
/// scroll position glides to the new spot. Dragging the scrollbar or any other scroll change
/// (e.g. restoring a position after a rebuild) cancels the glide immediately.
/// </summary>
public partial class SmoothScroller : Node
{
    /// <summary>Pixels per wheel notch.</summary>
    public const float Step = 110f;

    private ScrollContainer _target = null!;
    private ScrollGlide _glide;
    private float _lastSet = -1f;
    private float _pos;   // un-rounded position while gliding (the bar itself snaps to whole pixels)

    public static SmoothScroller Attach(ScrollContainer target)
    {
        var scroller = new SmoothScroller { _target = target, Name = "SmoothScroller" };
        target.AddChild(scroller, false, InternalMode.Back);
        return scroller;
    }

    public override void _Ready() => SetProcess(false);

    public override void _Input(InputEvent @event)
    {
        if (@event is not InputEventMouseButton { Pressed: true } mb) return;
        if (mb.ButtonIndex is not (MouseButton.WheelUp or MouseButton.WheelDown)) return;
        if (mb.ShiftPressed || mb.CtrlPressed) return;
        if (!_target.IsVisibleInTree() || _target.VerticalScrollMode == ScrollContainer.ScrollMode.Disabled) return;

        // Only when the pointer is really over this container (not a popup or another pane on top).
        var viewport = _target.GetViewport();
        var hovered = viewport.GuiGetHoveredControl();
        if (hovered is null || (hovered != _target && !_target.IsAncestorOf(hovered))) return;
        if (HasInnerScroller(hovered)) return;

        var bar = _target.GetVScrollBar();
        float max = (float)(bar.MaxValue - bar.Page);
        if (max <= 0f) return;

        float current = (float)bar.Value;
        if (_glide.Active && !Mathf.IsEqualApprox(current, _lastSet)) _glide.Stop();   // changed elsewhere
        if (!_glide.Active) _pos = current;
        float factor = mb.Factor > 0 ? mb.Factor : 1f;
        _glide.Push(_pos, (mb.ButtonIndex == MouseButton.WheelUp ? -1f : 1f) * Step * factor, max);
        _lastSet = current;
        SetProcess(true);
        viewport.SetInputAsHandled();
    }

    public override void _Process(double delta)
    {
        if (!GodotObject.IsInstanceValid(_target) || !_glide.Active) { SetProcess(false); return; }
        var bar = _target.GetVScrollBar();
        float current = (float)bar.Value;
        // Someone else moved it (scrollbar drag, rebuild): let them win.
        if (!Mathf.IsEqualApprox(current, _lastSet)) { _glide.Stop(); SetProcess(false); return; }

        float max = Mathf.Max(0f, (float)(bar.MaxValue - bar.Page));
        _glide.Goal = Mathf.Min(_glide.Goal, max);
        _pos = _glide.Step(_pos, (float)delta);
        bar.Value = Mathf.Round(_pos);
        _lastSet = (float)bar.Value;
        if (!_glide.Active) SetProcess(false);
    }

    /// <summary>True when a different scroll container sits between the hovered control and ours.</summary>
    private bool HasInnerScroller(Control hovered)
    {
        for (Node? n = hovered; n is not null && n != _target; n = n.GetParent())
            if (n is ScrollContainer or TextEdit or ItemList or Tree) return true;
        return false;
    }
}
