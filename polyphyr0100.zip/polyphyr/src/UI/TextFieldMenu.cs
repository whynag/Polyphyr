using Godot;

namespace Polyphyr.UI;

/// <summary>
/// Replaces Godot's built-in right-click menu on every single-line text box with a simpler one:
/// Cut, Copy, Paste, Select All, Undo, Redo. (No "Text Writing Direction" or "Insert Control Character".)
/// </summary>
public static class TextFieldMenu
{
    private const string MetaKey = "_text_field_menu";

    private static bool _installed;

    public static void Install(SceneTree tree)
    {
        // Once per run: the main scene is reloaded when switching light/dark mode.
        if (_installed) return;
        _installed = true;
        tree.NodeAdded += node =>
        {
            if (node is LineEdit edit)
                Callable.From(() => Attach(edit)).CallDeferred();
        };
    }

    public static void Attach(LineEdit edit)
    {
        if (!GodotObject.IsInstanceValid(edit) || edit.HasMeta(MetaKey)) return;
        edit.SetMeta(MetaKey, true);
        edit.ContextMenuEnabled = false;

        PopupMenu? menu = null;
        edit.GuiInput += e =>
        {
            if (e is not InputEventMouseButton { Pressed: true, ButtonIndex: MouseButton.Right }) return;
            menu ??= Build(edit);
            Refresh(edit, menu);
            menu.Position = PopupPosition(edit);
            menu.Popup();
            edit.AcceptEvent();
        };
    }

    /// <summary>Where a popup should appear for the current mouse position (window or screen coordinates).</summary>
    public static Vector2I PopupPosition(Control anchor)
        => anchor.GetViewport().GuiEmbedSubwindows
            ? (Vector2I)anchor.GetGlobalMousePosition()
            : DisplayServer.MouseGetPosition();

    private static PopupMenu Build(LineEdit edit)
    {
        var menu = new PopupMenu();
        menu.AddItem("Cut", (int)LineEdit.MenuItems.Cut);
        menu.AddItem("Copy", (int)LineEdit.MenuItems.Copy);
        menu.AddItem("Paste", (int)LineEdit.MenuItems.Paste);
        menu.AddSeparator();
        menu.AddItem("Select All", (int)LineEdit.MenuItems.SelectAll);
        menu.AddSeparator();
        menu.AddItem("Undo", (int)LineEdit.MenuItems.Undo);
        menu.AddItem("Redo", (int)LineEdit.MenuItems.Redo);
        menu.IdPressed += id =>
        {
            edit.MenuOption((int)id);
            edit.GrabFocus();
        };
        edit.AddChild(menu, false, Node.InternalMode.Front);
        return menu;
    }

    private static void Refresh(LineEdit edit, PopupMenu menu)
    {
        bool selected = edit.HasSelection();
        void Set(LineEdit.MenuItems item, bool disabled)
        {
            int index = menu.GetItemIndex((int)item);
            if (index >= 0) menu.SetItemDisabled(index, disabled);
        }
        Set(LineEdit.MenuItems.Cut, !selected || !edit.Editable);
        Set(LineEdit.MenuItems.Copy, !selected);
        Set(LineEdit.MenuItems.Paste, !edit.Editable);
        Set(LineEdit.MenuItems.Undo, !edit.HasUndo());
        Set(LineEdit.MenuItems.Redo, !edit.HasRedo());
    }
}
