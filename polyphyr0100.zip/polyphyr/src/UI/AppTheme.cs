using Godot;

namespace Polyphyr.UI;

/// <summary>The app's fonts: Inter for interface and writing, IBM Plex Mono for code.</summary>
public static class AppFonts
{
    private const string Inter = "res://fonts/Inter/static/Inter_18pt-";
    private const string Plex = "res://fonts/IBM_Plex_Mono/IBMPlexMono-";

    public static readonly Font Regular = GD.Load<Font>(Inter + "Regular.ttf");
    public static readonly Font Medium = GD.Load<Font>(Inter + "Medium.ttf");
    public static readonly Font SemiBold = GD.Load<Font>(Inter + "SemiBold.ttf");
    public static readonly Font Italic = GD.Load<Font>(Inter + "Italic.ttf");
    public static readonly Font SemiBoldItalic = GD.Load<Font>(Inter + "SemiBoldItalic.ttf");
    public static readonly Font Mono = GD.Load<Font>(Plex + "Regular.ttf");
    public static readonly Font MonoMedium = GD.Load<Font>(Plex + "Medium.ttf");
}

/// <summary>Color palette and the Godot theme built from it.</summary>
public static class AppTheme
{
    // Dark: near-black base with cool gray steps. Light: white surfaces with soft gray steps.
    // One blue accent either way. Set by ApplyMode before the UI is built.
    public static bool IsLight { get; private set; }

    public static Color Bg, Surface, Raised, Hover, Active, Border;
    public static Color Text, TextDim, TextFaint, Accent, AccentSoft, Danger;
    /// <summary>Deepest background: flowchart canvas, sheet grid.</summary>
    public static Color Canvas;
    /// <summary>Board columns (and their hover).</summary>
    public static Color Subtle, SubtleHover;
    public static Color GridLine, GridDot;
    /// <summary>Text boxes drawn over content (cell / shape editors).</summary>
    public static Color InputBg;
    /// <summary>Primary buttons ("Create") and lit toggles.</summary>
    public static Color PrimaryBg, PrimaryBorder, PrimaryIcon;
    /// <summary>Base color for hover overlays (white on dark, black on light); used with a low alpha.</summary>
    public static Color Overlay;
    public static Color Grabber, GrabberHover, GrabberPressed;
    /// <summary>Empty heatmap squares and the empty status bar.</summary>
    public static Color EmptyCell, Track;

    static AppTheme() => ApplyMode(false);

    public static void ApplyMode(bool light)
    {
        IsLight = light;
        if (light)
        {
            Bg = new("f6f6f5"); Surface = new("ffffff"); Raised = new("f0f0f0"); Hover = new("e8e8e7");
            Active = new("dededd"); Border = new("e0e0df");
            Text = new("1e1e20"); TextDim = new("5e5e63"); TextFaint = new("8f8f94");
            Accent = new("3d63dd"); AccentSoft = new(0.24f, 0.39f, 0.87f, 0.22f); Danger = new("d2414d");
            Canvas = new("fafafa"); Subtle = new("eeeeed"); SubtleHover = new("e8e8e7");
            GridLine = new("e4e4e3"); GridDot = new("d8d8d7"); InputBg = new("ffffff");
            PrimaryBg = new("dbe4fb"); PrimaryBorder = new("a9bcef"); PrimaryIcon = new("3d63dd");
            Overlay = new(0, 0, 0); Grabber = new("cdcdcc"); GrabberHover = new("b8b8b7"); GrabberPressed = new("a0a09f");
            EmptyCell = new("e5e5e4"); Track = new("e8e8e7");
        }
        else
        {
            Bg = new("0c0c0d"); Surface = new("121214"); Raised = new("18181b"); Hover = new("1f1f23");
            Active = new("28282c"); Border = new("242428");
            Text = new("e6e6e7"); TextDim = new("98989d"); TextFaint = new("646468");
            Accent = new("7090ff"); AccentSoft = new(0.44f, 0.56f, 1f, 0.28f); Danger = new("e5646e");
            Canvas = new("0d0d0e"); Subtle = new("101012"); SubtleHover = new("151517");
            GridLine = new("1e1e21"); GridDot = new("1f1f22"); InputBg = new("18181b");
            PrimaryBg = new("2b3a5c"); PrimaryBorder = new("3d5280"); PrimaryIcon = new("b9c8ee");
            Overlay = new(1, 1, 1); Grabber = new("2c2c30"); GrabberHover = new("39393e"); GrabberPressed = new("47474c");
            EmptyCell = new("1c1c1f"); Track = new("131315");
        }
    }

    /// <summary>Picks the dark-mode or light-mode version of a color.</summary>
    public static Color Pick(string dark, string light) => new(IsLight ? light : dark);

    public const int FontSize = 14;
    public const int Radius = 6;

    public static StyleBoxFlat Box(Color bg, int radius = Radius, float padX = 0, float padY = 0, Color? border = null, int borderWidth = 0)
    {
        var sb = new StyleBoxFlat
        {
            BgColor = bg,
            ContentMarginLeft = padX,
            ContentMarginRight = padX,
            ContentMarginTop = padY,
            ContentMarginBottom = padY,
            AntiAliasing = true,
        };
        sb.SetCornerRadiusAll(radius);
        if (border is { } b && borderWidth > 0)
        {
            sb.BorderColor = b;
            sb.SetBorderWidthAll(borderWidth);
        }
        return sb;
    }

    public static StyleBoxEmpty Empty(float padX = 0, float padY = 0) => new()
    {
        ContentMarginLeft = padX,
        ContentMarginRight = padX,
        ContentMarginTop = padY,
        ContentMarginBottom = padY,
    };

    /// <summary>A soft, anti-aliased capsule, used for the split handle.</summary>
    public static ImageTexture Pill(int width, int height, Color color)
    {
        var img = Image.CreateEmpty(width, height, false, Image.Format.Rgba8);
        float r = Mathf.Min(width, height) * 0.5f;
        bool vertical = height >= width;
        for (int y = 0; y < height; y++)
        for (int x = 0; x < width; x++)
        {
            float px = x + 0.5f, py = y + 0.5f;
            float dx, dy;
            if (vertical)
            {
                dx = px - width * 0.5f;
                dy = py - Mathf.Clamp(py, r, height - r);
            }
            else
            {
                dx = px - Mathf.Clamp(px, r, width - r);
                dy = py - height * 0.5f;
            }
            float coverage = Mathf.Clamp(r - Mathf.Sqrt(dx * dx + dy * dy) + 0.5f, 0f, 1f);
            img.SetPixel(x, y, new Color(color, color.A * coverage));
        }
        return ImageTexture.CreateFromImage(img);
    }

    /// <summary>
    /// Checkbox icon: a transparent rounded square with an outline, or a muted fill with a
    /// check mark. Drawn with anti-aliasing so it reads clearly on the dark background.
    /// </summary>
    /// <summary>A thin anti-aliased "×" for window close buttons, in the given color.</summary>
    public static ImageTexture CloseIcon(Color color, int size = 16)
    {
        var img = Image.CreateEmpty(size, size, false, Image.Format.Rgba8);
        float inset = 4f, max = size - 4f;
        var a0 = new Vector2(inset, inset); var a1 = new Vector2(max, max);
        var b0 = new Vector2(max, inset); var b1 = new Vector2(inset, max);
        static float Dist(Vector2 p, Vector2 a, Vector2 b)
        {
            var ab = b - a;
            float t = Mathf.Clamp((p - a).Dot(ab) / ab.LengthSquared(), 0, 1);
            return p.DistanceTo(a + ab * t);
        }
        for (int y = 0; y < size; y++)
            for (int x = 0; x < size; x++)
            {
                var p = new Vector2(x + 0.5f, y + 0.5f);
                float d = Mathf.Min(Dist(p, a0, a1), Dist(p, b0, b1));
                float alpha = Mathf.Clamp(1.4f - d, 0f, 1f);
                img.SetPixel(x, y, new Color(color, color.A * alpha));
            }
        return ImageTexture.CreateFromImage(img);
    }

    public static ImageTexture CheckIcon(bool isChecked, int size = 18)
    {
        var outline = Pick("707075", "a8a8ab");
        var fill = Pick("3a4563", "dbe4fb");
        var fillEdge = Pick("56658f", "a9bcef");
        var mark = Pick("d3d9e8", "3d63dd");
        const float radius = 4f;
        const float stroke = 1.5f;

        var img = Image.CreateEmpty(size, size, false, Image.Format.Rgba8);
        float half = size * 0.5f - 1f;
        var center = new Vector2(size * 0.5f, size * 0.5f);
        Vector2[] check =
        {
            new(size * 0.27f, size * 0.52f),
            new(size * 0.44f, size * 0.68f),
            new(size * 0.74f, size * 0.34f),
        };

        for (int y = 0; y < size; y++)
        for (int x = 0; x < size; x++)
        {
            var p = new Vector2(x + 0.5f, y + 0.5f);
            // Signed distance to a rounded square.
            var q = (p - center).Abs() - new Vector2(half - radius, half - radius);
            float sd = new Vector2(Mathf.Max(q.X, 0), Mathf.Max(q.Y, 0)).Length() + Mathf.Min(Mathf.Max(q.X, q.Y), 0) - radius;

            Color c = new(0, 0, 0, 0);
            if (isChecked)
            {
                float body = Mathf.Clamp(0.5f - sd, 0f, 1f);
                float edge = Mathf.Clamp(0.5f - (Mathf.Abs(sd + stroke * 0.5f) - stroke * 0.5f), 0f, 1f);
                c = Blend(c, new Color(fill, body));
                c = Blend(c, new Color(fillEdge, edge * body));
                float d = Mathf.Min(SegmentDistance(p, check[0], check[1]), SegmentDistance(p, check[1], check[2]));
                c = Blend(c, new Color(mark, Mathf.Clamp(1.0f - d + 0.5f, 0f, 1f)));
            }
            else
            {
                float edge = Mathf.Clamp(0.5f - (Mathf.Abs(sd + stroke * 0.5f) - stroke * 0.5f), 0f, 1f);
                c = new Color(outline, edge);
            }
            img.SetPixel(x, y, c);
        }
        return ImageTexture.CreateFromImage(img);
    }

    private static float SegmentDistance(Vector2 p, Vector2 a, Vector2 b)
    {
        var ab = b - a;
        float t = Mathf.Clamp((p - a).Dot(ab) / ab.LengthSquared(), 0f, 1f);
        return (p - (a + ab * t)).Length();
    }

    /// <summary>"Over" compositing of src onto dst (straight alpha).</summary>
    private static Color Blend(Color dst, Color src)
    {
        float a = src.A + dst.A * (1f - src.A);
        if (a <= 0f) return new Color(0, 0, 0, 0);
        return new Color(
            (src.R * src.A + dst.R * dst.A * (1f - src.A)) / a,
            (src.G * src.A + dst.G * dst.A * (1f - src.A)) / a,
            (src.B * src.A + dst.B * dst.A * (1f - src.A)) / a,
            a);
    }

    public static Theme Build()
    {
        var t = new Theme
        {
            DefaultFont = AppFonts.Regular,
            DefaultFontSize = FontSize,
        };

        // ---- Text ----
        t.SetColor("font_color", "Label", Text);

        // ---- Buttons ----
        t.SetStylebox("normal", "Button", Box(Raised, Radius, 12, 6, Border, 1));
        // Hover looks like normal here; HoverFade lays a fading highlight on top instead of snapping.
        t.SetStylebox("hover", "Button", Box(Raised, Radius, 12, 6, Border, 1));
        t.SetStylebox("pressed", "Button", Box(Active, Radius, 12, 6, Border, 1));
        t.SetStylebox("disabled", "Button", Box(Surface, Radius, 12, 6, Border, 1));
        var focus = Box(Colors.Transparent, Radius, 12, 6, AccentSoft, 1);
        focus.DrawCenter = false;
        t.SetStylebox("focus", "Button", focus);
        t.SetFont("font", "Button", AppFonts.Medium);
        t.SetColor("font_color", "Button", Text);
        t.SetColor("font_hover_color", "Button", Text);
        t.SetColor("font_pressed_color", "Button", Text);
        t.SetColor("font_focus_color", "Button", Text);
        t.SetColor("font_hover_pressed_color", "Button", Text);
        t.SetColor("font_disabled_color", "Button", TextFaint);

        // ---- Text inputs ----
        t.SetStylebox("normal", "LineEdit", Box(Raised, Radius, 10, 6, Border, 1));
        t.SetStylebox("focus", "LineEdit", Box(Colors.Transparent, Radius, 10, 6, Accent, 1));
        t.SetStylebox("read_only", "LineEdit", Box(Surface, Radius, 10, 6, Border, 1));
        t.SetColor("font_color", "LineEdit", Text);
        t.SetColor("font_placeholder_color", "LineEdit", TextFaint);
        t.SetColor("font_uneditable_color", "LineEdit", TextDim);
        t.SetColor("caret_color", "LineEdit", Text);
        t.SetColor("selection_color", "LineEdit", AccentSoft);
        t.SetColor("font_selected_color", "LineEdit", Text);
        t.SetColor("clear_button_color", "LineEdit", TextFaint);
        t.SetColor("clear_button_color_pressed", "LineEdit", Text);

        // ---- Lists ----
        t.SetStylebox("panel", "ItemList", Empty());
        t.SetStylebox("focus", "ItemList", Empty());
        t.SetStylebox("cursor", "ItemList", Empty());
        t.SetStylebox("cursor_unfocused", "ItemList", Empty());
        t.SetStylebox("hovered", "ItemList", Box(Raised));
        t.SetStylebox("selected", "ItemList", Box(Active));
        t.SetStylebox("selected_focus", "ItemList", Box(Active));
        t.SetStylebox("hovered_selected", "ItemList", Box(Active));
        t.SetStylebox("hovered_selected_focus", "ItemList", Box(Active));
        t.SetColor("font_color", "ItemList", TextDim);
        t.SetColor("font_hovered_color", "ItemList", Text);
        t.SetColor("font_selected_color", "ItemList", Text);
        t.SetColor("font_hovered_selected_color", "ItemList", Text);
        t.SetColor("guide_color", "ItemList", Colors.Transparent);
        t.SetConstant("v_separation", "ItemList", 8);
        t.SetConstant("h_separation", "ItemList", 10);

        // ---- Tabs: plain text with an accent underline on the active tab ----
        foreach (var type in new[] { "TabContainer", "TabBar" })
        {
            var selected = Box(Colors.Transparent, 0, 14, 9);
            selected.BorderColor = Accent;
            selected.BorderWidthBottom = 2;
            var idle = Box(Colors.Transparent, 0, 14, 9);
            idle.BorderColor = Colors.Transparent;
            idle.BorderWidthBottom = 2;
            t.SetStylebox("tab_selected", type, selected);
            t.SetStylebox("tab_unselected", type, idle);
            t.SetStylebox("tab_hovered", type, idle);
            t.SetStylebox("tab_disabled", type, idle);
            t.SetStylebox("tab_focus", type, Empty());
            t.SetColor("font_selected_color", type, Text);
            t.SetColor("font_unselected_color", type, TextFaint);
            t.SetColor("font_hovered_color", type, TextDim);
            t.SetColor("font_disabled_color", type, TextFaint);
            t.SetFont("font", type, AppFonts.Medium);
            t.SetConstant("side_margin", type, 0);
        }
        var tabBar = Box(Colors.Transparent, 0);
        tabBar.BorderColor = Border;
        tabBar.BorderWidthBottom = 1;
        t.SetStylebox("tabbar_background", "TabContainer", tabBar);
        t.SetStylebox("panel", "TabContainer", Empty(0, 0));

        // ---- Panels ----
        t.SetStylebox("panel", "PanelContainer", Box(Surface, 10));
        t.SetStylebox("panel", "Panel", Box(Surface, 10));

        // ---- Popups, menus, tooltips ----
        t.SetStylebox("panel", "PopupMenu", Box(Raised, 8, 6, 6, Border, 1));
        t.SetStylebox("hover", "PopupMenu", Box(Hover, 5));
        t.SetColor("font_color", "PopupMenu", Text);
        t.SetColor("font_hover_color", "PopupMenu", Text);
        t.SetColor("font_disabled_color", "PopupMenu", TextFaint);
        t.SetConstant("v_separation", "PopupMenu", 8);
        t.SetConstant("item_start_padding", "PopupMenu", 10);
        t.SetConstant("item_end_padding", "PopupMenu", 16);
        t.SetStylebox("panel", "PopupPanel", Box(Raised, 8, 6, 6, Border, 1));
        t.SetStylebox("panel", "TooltipPanel", Box(Raised, 6, 8, 5, Border, 1));
        t.SetColor("font_color", "TooltipLabel", Text);

        // ---- Dialogs ----
        var border = Box(Surface, 10, 0, 0, Border, 1);
        border.ExpandMarginTop = 38;
        border.ExpandMarginLeft = 1;
        border.ExpandMarginRight = 1;
        border.ExpandMarginBottom = 1;
        t.SetStylebox("embedded_border", "Window", border);
        t.SetStylebox("embedded_unfocused_border", "Window", border);
        t.SetColor("title_color", "Window", TextDim);
        t.SetFont("title_font", "Window", AppFonts.Medium);
        t.SetConstant("title_height", "Window", 38);
        t.SetIcon("close", "Window", CloseIcon(TextDim));
        t.SetIcon("close_pressed", "Window", CloseIcon(Text));
        // Close button: inset from the right edge and centered in the title bar.
        t.SetConstant("close_h_offset", "Window", 34);
        t.SetConstant("close_v_offset", "Window", 27);
        t.SetStylebox("panel", "AcceptDialog", Box(Surface, 10, 26, 20));
        t.SetConstant("buttons_separation", "AcceptDialog", 12);
        t.SetConstant("buttons_min_width", "AcceptDialog", 96);
        t.SetConstant("buttons_min_height", "AcceptDialog", 34);

        // ---- Scrollbars: thin, no track ----
        foreach (var type in new[] { "VScrollBar", "HScrollBar" })
        {
            t.SetStylebox("scroll", type, Empty(3, 3));
            t.SetStylebox("scroll_focus", type, Empty(3, 3));
            t.SetStylebox("grabber", type, Box(Grabber, 4));
            t.SetStylebox("grabber_highlight", type, Box(GrabberHover, 4));
            t.SetStylebox("grabber_pressed", type, Box(GrabberPressed, 4));
        }

        // ---- Split containers: no built-in handle; NotesTab draws its own fading one ----
        var blankIcon = ImageTexture.CreateFromImage(Image.CreateEmpty(1, 1, false, Image.Format.Rgba8));
        foreach (var type in new[] { "HSplitContainer", "VSplitContainer", "SplitContainer" })
        {
            t.SetIcon("grabber", type, blankIcon);
            t.SetIcon("h_grabber", type, blankIcon);
            t.SetIcon("v_grabber", type, blankIcon);
            t.SetConstant("separation", type, 12);
            t.SetConstant("minimum_grab_thickness", type, 12);
        }

        // ---- Checkboxes ----
        t.SetColor("font_color", "CheckBox", TextDim);
        t.SetColor("font_hover_color", "CheckBox", Text);
        t.SetColor("font_pressed_color", "CheckBox", Text);
        t.SetColor("font_hover_pressed_color", "CheckBox", Text);
        t.SetColor("font_focus_color", "CheckBox", Text);
        t.SetStylebox("normal", "CheckBox", Empty(2, 4));
        t.SetStylebox("hover", "CheckBox", Empty(2, 4));
        t.SetStylebox("pressed", "CheckBox", Empty(2, 4));
        t.SetStylebox("hover_pressed", "CheckBox", Empty(2, 4));
        t.SetStylebox("focus", "CheckBox", Empty(2, 4));
        t.SetConstant("h_separation", "CheckBox", 8);
        var uncheckedIcon = CheckIcon(false);
        var checkedIcon = CheckIcon(true);
        t.SetIcon("unchecked", "CheckBox", uncheckedIcon);
        t.SetIcon("checked", "CheckBox", checkedIcon);
        t.SetIcon("unchecked_disabled", "CheckBox", uncheckedIcon);
        t.SetIcon("checked_disabled", "CheckBox", checkedIcon);

        return t;
    }
}
