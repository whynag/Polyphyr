// The first-launch name popup was removed (the name is edited from Home). This file can be deleted.
