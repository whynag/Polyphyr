using System;
using System.Collections.Generic;
using Godot;

namespace Polyphyr.UI.Board;

/// <summary>
/// Dropdown for picking a document, sheet or image:
///   New  +
///   ──────
///   [search]
///   existing items…
/// </summary>
public partial class AttachPicker : PopupPanel
{
    public readonly record struct Item(string Title, Action Pick);

    private const float RowH = 30f, MaxListH = 260f;

    private Button _new = null!;
    private Button _clear = null!;
    private LineEdit _search = null!;
    private ScrollContainer _scroll = null!;
    private VBoxContainer _list = null!;
    private Label _empty = null!;

    private IReadOnlyList<Item> _items = Array.Empty<Item>();
    private Action? _onNew;
    private Action? _onClear;
    private string _noun = "items";

    public override void _Ready()
    {
        var pad = new MarginContainer();
        foreach (var side in new[] { "margin_left", "margin_right", "margin_top", "margin_bottom" })
            pad.AddThemeConstantOverride(side, 4);
        AddChild(pad);

        var box = new VBoxContainer { CustomMinimumSize = new Vector2(260, 0) };
        box.AddThemeConstantOverride("separation", 4);
        pad.AddChild(box);

        _new = Row("New");
        var plus = new Label { Text = "+", MouseFilter = Control.MouseFilterEnum.Ignore, VerticalAlignment = VerticalAlignment.Center };
        plus.AddThemeColorOverride("font_color", AppTheme.TextDim);
        plus.AddThemeFontSizeOverride("font_size", 16);
        _new.AddChild(plus);
        plus.SetAnchorsAndOffsetsPreset(Control.LayoutPreset.RightWide);
        plus.OffsetLeft = -26;
        _new.Pressed += () => Choose(_onNew);
        box.AddChild(_new);

        _clear = Row("None");
        _clear.AddThemeColorOverride("font_color", AppTheme.TextFaint);
        _clear.Pressed += () => Choose(_onClear);
        box.AddChild(_clear);

        box.AddChild(new ColorRect { Color = AppTheme.Border, CustomMinimumSize = new Vector2(0, 1), MouseFilter = Control.MouseFilterEnum.Ignore });

        _search = new LineEdit { ClearButtonEnabled = true, CustomMinimumSize = new Vector2(0, 30) };
        _search.TextChanged += _ => Fill();
        _search.TextSubmitted += _ =>
        {
            // Enter picks the first match.
            foreach (var item in Matches()) { Choose(item.Pick); return; }
        };
        box.AddChild(_search);

        _scroll = new ScrollContainer { HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled };
        box.AddChild(_scroll);
        SmoothScroller.Attach(_scroll);
        _list = new VBoxContainer { SizeFlagsHorizontal = Control.SizeFlags.ExpandFill };
        _list.AddThemeConstantOverride("separation", 0);
        _scroll.AddChild(_list);

        _empty = new Label { HorizontalAlignment = HorizontalAlignment.Center, CustomMinimumSize = new Vector2(0, RowH) };
        _empty.AddThemeColorOverride("font_color", AppTheme.TextFaint);
        _empty.AddThemeFontSizeOverride("font_size", 13);
        box.AddChild(_empty);
    }

    /// <param name="noun">Plural for the search box and empty text, e.g. "documents".</param>
    /// <param name="newLabel">Top row, e.g. "New document" or "From file…".</param>
    /// <param name="onClear">If set, a "None" row is shown to remove the current choice.</param>
    public void Open(Vector2I at, string noun, string newLabel, Action onNew, IReadOnlyList<Item> items, Action? onClear = null)
    {
        _noun = noun;
        _items = items;
        _onNew = onNew;
        _onClear = onClear;
        _new.Text = newLabel;
        _clear.Visible = onClear is not null;
        _search.PlaceholderText = $"Search {noun}";
        _search.Text = "";
        Fill();
        Popup(new Rect2I(at, Vector2I.Zero));
        Callable.From(() => _search.GrabFocus()).CallDeferred();
    }

    private IEnumerable<Item> Matches()
    {
        string q = _search.Text.Trim();
        foreach (var item in _items)
            if (q.Length == 0 || item.Title.Contains(q, StringComparison.CurrentCultureIgnoreCase))
                yield return item;
    }

    private void Fill()
    {
        foreach (var child in _list.GetChildren())
        {
            _list.RemoveChild(child);
            child.QueueFree();
        }
        int count = 0;
        foreach (var item in Matches())
        {
            var row = Row(string.IsNullOrWhiteSpace(item.Title) ? "Untitled" : item.Title);
            var pick = item.Pick;
            row.Pressed += () => Choose(pick);
            _list.AddChild(row);
            count++;
        }
        _scroll.Visible = count > 0;
        _scroll.CustomMinimumSize = new Vector2(0, Mathf.Min(count * RowH, MaxListH));
        _empty.Visible = count == 0;
        _empty.Text = _items.Count == 0 ? $"No {_noun} yet" : "No matches";
        Callable.From(() => { if (Visible) ResetSize(); }).CallDeferred();
    }

    private void Choose(Action? action)
    {
        Hide();
        action?.Invoke();
    }

    private static Button Row(string text)
    {
        var b = new Button
        {
            Text = text,
            Flat = true,
            FocusMode = Control.FocusModeEnum.None,
            Alignment = HorizontalAlignment.Left,
            TextOverrunBehavior = TextServer.OverrunBehavior.TrimEllipsis,
            CustomMinimumSize = new Vector2(0, RowH),
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
            MouseDefaultCursorShape = Control.CursorShape.PointingHand,
        };
        b.AddThemeFontSizeOverride("font_size", 13);
        b.AddThemeColorOverride("font_color", AppTheme.Text);
        b.AddThemeColorOverride("font_hover_color", AppTheme.Text);
        var style = AppTheme.Empty(10, 0);
        b.AddThemeStyleboxOverride("normal", style);
        b.AddThemeStyleboxOverride("hover", style);
        b.AddThemeStyleboxOverride("pressed", style);
        return b;
    }
}
