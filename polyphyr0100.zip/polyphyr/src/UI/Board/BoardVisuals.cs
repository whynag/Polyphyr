using System;
using Godot;
using Polyphyr.Core;

namespace Polyphyr.UI.Board;

/// <summary>Names, colors and ordering shared by the list and column views.</summary>
public static class BoardVisuals
{
    /// <summary>The three priorities offered in menus, highest first.</summary>
    public static readonly Priority[] PriorityOrder = { Priority.High, Priority.Medium, Priority.Low };

    /// <summary>Folds the older extra levels into the three used now (Urgent → High, Lowest → Low).</summary>
    public static Priority Normalize(Priority p) => p switch
    {
        Priority.Urgent => Priority.High,
        Priority.Lowest => Priority.Low,
        _ => p,
    };

    public static string PriorityName(Priority p) => Normalize(p) switch
    {
        Priority.High => "High",
        Priority.Medium => "Medium",
        Priority.Low => "Low",
        _ => "None",
    };

    // Muted red / amber / blue.
    public static Color PriorityColor(Priority p) => Normalize(p) switch
    {
        Priority.High => new Color("c8646d"),
        Priority.Medium => new Color("c49a52"),
        Priority.Low => new Color("7092cf"),
        _ => AppTheme.TextFaint,
    };

    public enum StatusTone { Neutral, Active, Done }

    /// <summary>Picks a pill style from the column name: "Done"-like is green, "Idea"/"Backlog" is gray, the rest blue.</summary>
    public static StatusTone ToneOf(BoardColumn column)
    {
        string n = column.Name.ToLowerInvariant();
        if (n.Contains("done") || n.Contains("complete") || n.Contains("closed") || n.Contains("shipped")) return StatusTone.Done;
        if (n.Contains("idea") || n.Contains("backlog") || n.Contains("later") || n == "none") return StatusTone.Neutral;
        return StatusTone.Active;
    }

    public static (Color Background, Color Border, Color Text) StatusColors(StatusTone tone) => tone switch
    {
        StatusTone.Done => (AppTheme.Pick("233528", "e3f3e5"), AppTheme.Pick("3a5a40", "a8d5ae"), AppTheme.Pick("a3c99d", "2f7a3b")),
        StatusTone.Active => (AppTheme.Pick("1f2c42", "e3ebfb"), AppTheme.Pick("34507c", "a9bcef"), AppTheme.Pick("a9bfe4", "3456b8")),
        _ => (new Color(0, 0, 0, 0), AppTheme.Pick("4e4e53", "c8c8c7"), AppTheme.TextDim),
    };

    public static bool IsDone(BoardColumn column) => ToneOf(column) == StatusTone.Done;

    // Soft green for completed tasks: visible, but not loud.
    public static readonly Color DoneRowBackground = new(0.40f, 0.66f, 0.45f, 0.075f);
    public static Color DoneCardBackground => AppTheme.Pick("17211a", "eef7ef");
    public static Color DoneCardBorder => AppTheme.Pick("27392c", "cfe6d2");
}

/// <summary>Priority glyph: an up chevron for High, a minus for Medium, a down chevron for Low.</summary>
public partial class PriorityIcon : Control
{
    public Priority Priority { get; set; }

    public PriorityIcon()
    {
        CustomMinimumSize = new Vector2(16, 16);
        MouseFilter = MouseFilterEnum.Ignore;
    }

    public override void _Draw()
    {
        if (Priority == Priority.None) return;
        var c = BoardVisuals.PriorityColor(Priority);
        var o = new Vector2((Size.X - 12) * 0.5f, (Size.Y - 12) * 0.5f);
        const float w = 1.6f;

        switch (BoardVisuals.Normalize(Priority))
        {
            case Priority.High:
                DrawPolyline(new[] { o + new Vector2(1.5f, 8.5f), o + new Vector2(6, 4), o + new Vector2(10.5f, 8.5f) }, c, w, true);
                break;
            case Priority.Medium:
                DrawLine(o + new Vector2(2, 6.25f), o + new Vector2(10, 6.25f), c, w + 0.2f, true);
                break;
            case Priority.Low:
                DrawPolyline(new[] { o + new Vector2(1.5f, 4), o + new Vector2(6, 8.5f), o + new Vector2(10.5f, 4) }, c, w, true);
                break;
        }
    }
}

/// <summary>Small line icons: task (blue check box), note, image, sheet.</summary>
public partial class KindIcon : Control
{
    public enum KindType { Task, Note, Image, Sheet, ImageAdd }

    public KindType Kind { get; set; }
    /// <summary>Line color; defaults to the dim text color.</summary>
    public Color? Tint { get; set; }

    private static readonly StyleBoxFlat TaskBox = AppTheme.Box(new Color("4a66a8"), 3);

    public KindIcon()
    {
        CustomMinimumSize = new Vector2(16, 16);
        MouseFilter = MouseFilterEnum.Ignore;
    }

    public static KindType FromAttachment(AttachmentKind k) => k switch
    {
        AttachmentKind.Note => KindType.Note,
        AttachmentKind.Image => KindType.Image,
        _ => KindType.Sheet,
    };

    public override void _Draw()
    {
        var o = new Vector2((Size.X - 14) * 0.5f, (Size.Y - 14) * 0.5f);
        var line = Tint ?? AppTheme.TextDim;
        const float w = 1.2f;
        var box = new Rect2(o + new Vector2(1, 1), new Vector2(12, 12));

        switch (Kind)
        {
            case KindType.Task:
                TaskBox.Draw(GetCanvasItem(), box);
                DrawPolyline(new[] { o + new Vector2(4, 7), o + new Vector2(6.2f, 9.3f), o + new Vector2(10.2f, 4.6f) },
                    new Color("e8edf8"), 1.5f, true);
                break;
            case KindType.Note:
                DrawRect(new Rect2(o + new Vector2(2, 1), new Vector2(10, 12)), line, false, w);
                for (int i = 0; i < 3; i++)
                    DrawLine(o + new Vector2(4.5f, 4.5f + i * 2.6f), o + new Vector2(9.5f, 4.5f + i * 2.6f), line, w);
                break;
            case KindType.Image:
                DrawRect(box, line, false, w);
                DrawPolyline(new[] { o + new Vector2(2, 11), o + new Vector2(5.5f, 7), o + new Vector2(8, 9.5f), o + new Vector2(9.5f, 8), o + new Vector2(12, 11) }, line, w, true);
                DrawCircle(o + new Vector2(9.5f, 4.5f), 1.3f, line);
                break;
            case KindType.ImageAdd:
                // Image frame with a small "+" badge in the corner.
                DrawRect(new Rect2(o + new Vector2(1, 3), new Vector2(10, 10)), line, false, w);
                DrawPolyline(new[] { o + new Vector2(2, 12), o + new Vector2(5, 8.5f), o + new Vector2(7, 10.5f), o + new Vector2(8.5f, 9.5f), o + new Vector2(10.5f, 12) }, line, w, true);
                DrawLine(o + new Vector2(12, 0), o + new Vector2(12, 5), line, 1.4f);
                DrawLine(o + new Vector2(9.5f, 2.5f), o + new Vector2(14.5f, 2.5f), line, 1.4f);
                break;
            case KindType.Sheet:
                DrawRect(box, line, false, w);
                DrawLine(o + new Vector2(1, 5), o + new Vector2(13, 5), line, w);
                DrawLine(o + new Vector2(1, 9), o + new Vector2(13, 9), line, w);
                DrawLine(o + new Vector2(5.5f, 1), o + new Vector2(5.5f, 13), line, w);
                break;
        }
    }
}

/// <summary>Expand/collapse chevron. Click to toggle.</summary>
public partial class Chevron : Control
{
    public bool Expanded { get; set; }
    public event Action? Toggled;

    public Chevron()
    {
        CustomMinimumSize = new Vector2(18, 18);
        MouseFilter = MouseFilterEnum.Stop;
        MouseDefaultCursorShape = CursorShape.PointingHand;
        TooltipText = "Show attachments";
    }

    public override void _GuiInput(InputEvent @event)
    {
        if (@event is not InputEventMouseButton { Pressed: true, ButtonIndex: MouseButton.Left }) return;
        Toggled?.Invoke();
        AcceptEvent();
    }

    public override void _Draw()
    {
        var c = AppTheme.TextDim;
        var m = Size * 0.5f;
        var points = Expanded
            ? new[] { m + new Vector2(-4, -2), m + new Vector2(0, 2), m + new Vector2(4, -2) }
            : new[] { m + new Vector2(-2, -4), m + new Vector2(2, 0), m + new Vector2(-2, 4) };
        DrawPolyline(points, c, 1.5f, true);
    }
}

/// <summary>A task key like TASK-14, drawn as an underlined link; struck through when done.</summary>
public partial class KeyLabel : Label
{
    public bool Strike { get; set; }

    public KeyLabel()
    {
        MouseFilter = MouseFilterEnum.Stop;
        MouseDefaultCursorShape = CursorShape.PointingHand;
        VerticalAlignment = VerticalAlignment.Center;
        AddThemeColorOverride("font_color", new Color("8ea6e0"));
    }

    public override void _Draw()
    {
        var font = GetThemeFont("font");
        int size = GetThemeFontSize("font_size");
        float width = font.GetStringSize(Text, HorizontalAlignment.Left, -1, size).X;
        float lineH = font.GetHeight(size);
        float top = (Size.Y - lineH) * 0.5f;
        float baseline = top + font.GetAscent(size);
        var color = new Color("8ea6e0");
        DrawLine(new Vector2(0, baseline + 2), new Vector2(width, baseline + 2), new Color(color, 0.6f), 1f);
        if (Strike)
        {
            float y = baseline - font.GetAscent(size) * 0.32f;
            DrawLine(new Vector2(0, y), new Vector2(width, y), color, 1.2f);
        }
    }
}
