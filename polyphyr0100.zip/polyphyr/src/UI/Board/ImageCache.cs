using System.Collections.Generic;
using Godot;
using Polyphyr.Core;
using Polyphyr.Core.Storage;

namespace Polyphyr.UI.Board;

/// <summary>
/// Loads attached images once and keeps a downscaled copy for card thumbnails and covers,
/// so redrawing the board never re-reads files from disk.
/// </summary>
public sealed class ImageCache
{
    private const int ThumbWidth = 600;
    private readonly Dictionary<ImageId, Texture2D?> _thumbs = new();

    public IWorkspaceStore? Store { get; set; }
    public Workspace? Workspace { get; set; }

    public void Clear() => _thumbs.Clear();

    public Texture2D? Thumbnail(ImageId id)
    {
        if (_thumbs.TryGetValue(id, out var cached)) return cached;
        var texture = Load(id, ThumbWidth);
        _thumbs[id] = texture;
        return texture;
    }

    /// <summary>Full-size image for the preview popup (not cached).</summary>
    public Texture2D? Full(ImageId id) => Load(id, 4096);

    private Texture2D? Load(ImageId id, int maxWidth)
    {
        if (Store is null || Workspace is null || !Workspace.Images.TryGetValue(id, out var asset)) return null;
        var path = Store.GetImagePath(asset);
        if (!System.IO.File.Exists(path)) return null;

        var image = Image.LoadFromFile(path);
        if (image is null || image.IsEmpty()) return null;
        if (image.GetWidth() > maxWidth)
        {
            int height = Mathf.Max(1, image.GetHeight() * maxWidth / image.GetWidth());
            image.Resize(maxWidth, height, Image.Interpolation.Lanczos);
        }
        return ImageTexture.CreateFromImage(image);
    }
}
