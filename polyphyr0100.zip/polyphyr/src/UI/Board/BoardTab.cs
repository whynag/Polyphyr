using System;
using System.Collections.Generic;
using System.Linq;
using Godot;
using Polyphyr.Core;
using Polyphyr.Core.Storage;

namespace Polyphyr.UI.Board;

/// <summary>
/// Jira-style board: columns of cards that can be dragged around, each card with a dropdown of
/// attached notes, images and sheets. Rebuilt (once per frame at most) when the workspace changes.
/// </summary>
public partial class BoardTab : VBoxContainer
{
    public event Action<NoteId>? OpenNoteRequested;
    public event Action<SheetId>? OpenSheetRequested;

    public Workspace? Ws { get; private set; }
    /// <summary>Per-computer settings (pins on Home).</summary>
    public AppSettings? Settings { get; set; }
    public IWorkspaceStore? Store { get; private set; }
    public ImageCache Images { get; } = new();

    private readonly HashSet<CardId> _expanded = new();
    private readonly Dictionary<CardId, CardView> _cardViews = new();
    private readonly List<BoardColumnView> _columnViews = new();
    private BoardColumnView? _activeDrop;
    private bool _rebuildQueued;
    private CardId? _renameCardAfterRebuild;
    private ColumnId? _renameColumnAfterRebuild;

    private LineEdit _filter = null!;
    private ScrollContainer _hscroll = null!;
    private HBoxContainer _columnsBox = null!;
    private TaskListView _listView = null!;
    private FadingSplit _split = null!;
    private bool _renameInBoard;
    private HBoxContainer _selectionBar = null!;
    private Label _selectionLabel = null!;

    private readonly HashSet<CardId> _selected = new();
    private readonly Dictionary<CardId, Control> _titleControls = new();
    private readonly Dictionary<CardId, Control> _boardTitles = new();


    // Menus and popups
    private const int CardRename = 0, CardAttach = 1, CardDelete = 3, CardPin = 4;
    private const int PriorityBase = 10;
    private const int AttachNewNote = 0, AttachImage = 1, AttachNewSheet = 2;
    private const int AttOpen = 0, AttRemove = 1, AttView = 2, AttCover = 3;
    private const int ColRename = 0, ColDelete = 1;

    private PopupMenu _cardMenu = null!;
    private PopupMenu _priorityMenu = null!;
    private PopupMenu _attachMenu = null!;
    private AttachPicker _picker = null!;
    private PopupMenu _attachmentMenu = null!;
    private PopupMenu _columnMenu = null!;
    private FileDialog _imageDialog = null!;
    private PopupPanel _preview = null!;
    private TextureRect _previewImage = null!;
    private PopupPanel _renamePopup = null!;
    private LineEdit _renameEdit = null!;
    private ConfirmationDialog _confirm = null!;
    private PopupPanel _statusPopup = null!;
    private VBoxContainer _statusList = null!;
    private Button _statusCustom = null!;
    private ColorRect _statusCustomDivider = null!;
    private const string CustomName = "Custom";
    private bool _imageForDraft;

    /// <summary>The list's "+ Create" row: what's been typed and chosen so far.</summary>
    internal sealed class TaskDraft
    {
        public bool Open;
        public string Title = "";
        public Priority Priority;
        public bool WithNote;
        public bool WithSheet;
        public NoteId? ExistingNote;
        public SheetId? ExistingSheet;
        public string? ImagePath;

        public void Reset()
        {
            Title = "";
            Priority = Priority.None;
            WithNote = false;
            WithSheet = false;
            ExistingNote = null;
            ExistingSheet = null;
            ImagePath = null;
        }
    }

    internal TaskDraft Draft { get; } = new();

    /// <summary>The fixed statuses, in board order. Others the user types are added after these.</summary>
    private static readonly (string Name, string[] Aliases)[] DefaultStatuses =
    {
        ("None", new[] { "none", "no status" }),
        ("Idea", new[] { "idea", "ideas", "backlog" }),
        ("To-Do", new[] { "to-do", "to do", "todo" }),
        ("In Progress", new[] { "in progress", "in-progress", "doing" }),
        ("Completed", new[] { "completed", "complete", "done" }),
    };
    private PopupMenu _priorityPicker = null!;
    private PopupPanel _duePopup = null!;
    private LineEdit _dueEdit = null!;
    private LineEdit _dueMonths = null!;
    private bool _statusForSelection;

    private const int ColumnGap = 10;
    /// <summary>Five standard statuses (None, Idea, To-Do, In Progress, Completed) plus one custom one.</summary>
    public const int MaxStatuses = 6;

    private CardId? _menuCard;
    private ColumnId? _menuColumn;
    private Attachment? _menuAttachment;
    private Action<string>? _renameCommit;
    private bool _renameCancelled;
    private Action? _confirmAction;

    public override void _Ready()
    {
        AddThemeConstantOverride("separation", 12);

        // Breathing room under the main tab bar.
        AddChild(new Control { CustomMinimumSize = new Vector2(0, 6) });

        // ---- Toolbar: filter and selection actions ----
        var toolbar = new HBoxContainer();
        toolbar.AddThemeConstantOverride("separation", 10);
        AddChild(toolbar);

        _filter = new LineEdit { PlaceholderText = "Filter tasks", CustomMinimumSize = new Vector2(260, 0), ClearButtonEnabled = true };
        _filter.TextChanged += _ => ApplyFilter();
        toolbar.AddChild(_filter);

        toolbar.AddChild(new Control { SizeFlagsHorizontal = SizeFlags.ExpandFill });

        _selectionBar = new HBoxContainer { Visible = false };
        _selectionBar.AddThemeConstantOverride("separation", 8);
        _selectionLabel = new Label { VerticalAlignment = VerticalAlignment.Center };
        _selectionLabel.AddThemeColorOverride("font_color", AppTheme.TextDim);
        _selectionBar.AddChild(_selectionLabel);
        var moveSelected = new Button { Text = "Change status", FocusMode = FocusModeEnum.None };
        moveSelected.Pressed += () =>
        {
            _statusForSelection = true;
            ShowStatusMenuFor(null);
        };
        _selectionBar.AddChild(moveSelected);
        var deleteSelected = new Button { Text = "Delete", FocusMode = FocusModeEnum.None };
        deleteSelected.AddThemeColorOverride("font_hover_color", AppTheme.Danger);
        deleteSelected.Pressed += DeleteSelected;
        _selectionBar.AddChild(deleteSelected);
        var clear = new Button { Text = "Clear", Flat = true, FocusMode = FocusModeEnum.None };
        clear.Pressed += () => SetAllSelected(_selected.ToList(), false);
        _selectionBar.AddChild(clear);
        toolbar.AddChild(_selectionBar);

        // ---- Board (left) and list (right), side by side ----
        _split = new FadingSplit { SizeFlagsVertical = SizeFlags.ExpandFill };
        AddChild(_split);

        // The whole board scrolls; columns are only as tall as their cards.
        _hscroll = new ScrollContainer
        {
            SizeFlagsVertical = SizeFlags.ExpandFill,
            SizeFlagsHorizontal = SizeFlags.ExpandFill,
            CustomMinimumSize = new Vector2(320, 0),
        };
        // Space between the board's scrollbar and the divider.
        var boardPane = new MarginContainer
        {
            SizeFlagsVertical = SizeFlags.ExpandFill,
            SizeFlagsHorizontal = SizeFlags.ExpandFill,
        };
        boardPane.AddThemeConstantOverride("margin_right", 6);
        boardPane.AddChild(_hscroll);
        _split.AddChild(boardPane);

        _listView = new TaskListView
        {
            SizeFlagsVertical = SizeFlags.ExpandFill,
            SizeFlagsHorizontal = SizeFlags.ExpandFill,
        };
        _split.AddChild(_listView);
        _columnsBox = new HBoxContainer { SizeFlagsVertical = SizeFlags.ExpandFill };
        _columnsBox.AddThemeConstantOverride("separation", ColumnGap);
        // Space between the last column and the scrollbar.
        var columnsPad = new MarginContainer { SizeFlagsVertical = SizeFlags.ExpandFill };
        columnsPad.AddThemeConstantOverride("margin_right", 6);
        columnsPad.AddChild(_columnsBox);
        _hscroll.AddChild(columnsPad);
        SmoothScroller.Attach(_hscroll);

        BuildPopups();
    }

    public void Bind(Workspace ws, IWorkspaceStore store)
    {
        if (Ws is not null) Ws.Changed -= OnChanged;
        Ws = ws;
        Store = store;
        Images.Workspace = ws;
        Images.Store = store;
        Images.Clear();
        _expanded.Clear();
        _selected.Clear();
        EnsureDefaultStatuses(ws);
        if (ws.Board.Columns.FirstOrDefault(c => !DefaultStatuses.Any(d => d.Name == c.Name)) is { } extra && extra.Name != CustomName)
            ws.Apply(new RenameColumn(extra.Id, CustomName));
        ws.Changed += OnChanged;
        Rebuild();
    }

    /// <summary>Makes sure None, Idea, To-Do, In Progress and Completed exist, in that order, renaming close matches (e.g. "Done").</summary>
    private static void EnsureDefaultStatuses(Workspace ws)
    {
        var claimed = new HashSet<ColumnId>();
        for (int i = 0; i < DefaultStatuses.Length; i++)
        {
            var (name, aliases) = DefaultStatuses[i];
            var column = ws.Board.Columns.FirstOrDefault(c =>
                !claimed.Contains(c.Id) && aliases.Contains(c.Name.Trim().ToLowerInvariant()));

            ColumnId id;
            if (column is null)
            {
                id = ws.NewColumn(name, i);
            }
            else
            {
                id = column.Id;
                if (column.Name != name) ws.Apply(new RenameColumn(id, name));
                ws.Apply(new MoveColumn(id, i));
            }
            claimed.Add(id);
        }
    }

    /// <summary>The first status that isn't one of the four standard ones, if any.</summary>
    private BoardColumn? CustomStatus()
        => Ws?.Board.Columns.FirstOrDefault(c => !DefaultStatuses.Any(d => d.Name == c.Name));

    /// <summary>The column new tasks go into: To-Do if it exists, otherwise the first.</summary>
    private BoardColumn? DefaultColumn()
        => Ws?.Board.Columns.FirstOrDefault(c => c.Name == "To-Do") ?? Ws?.Board.Columns.FirstOrDefault();

    internal void RequestRebuild() => QueueRebuild();

    // ------------------------------------------------------------------
    // Building
    // ------------------------------------------------------------------

    private void OnChanged(Change change)
    {
        // Edits that don't show on the board don't trigger a rebuild.
        if (change is SetNoteText or SetSheetCell or SetSheetStyle or ClearSheetRange or InsertSheetRows or DeleteSheetRows
            or InsertSheetColumns or DeleteSheetColumns or ResizeSheet or SetSheetColumnWidth
            or AddFlowNode or MoveFlowNode or ResizeFlowNode or SetFlowNodeText or SetFlowNodeColor or SetFlowNodeShape
            or RemoveFlowNode or ConnectNodes or DisconnectNodes or SetEdgeLabel
            or CreateFlowchart or RenameFlowchart or DeleteFlowchart) return;
        if (change is RemoveImage) Images.Clear();
        QueueRebuild();
    }

    private void QueueRebuild()
    {
        if (_rebuildQueued) return;
        _rebuildQueued = true;
        Callable.From(Rebuild).CallDeferred();
    }

    private void Rebuild()
    {
        _rebuildQueued = false;
        if (Ws is null || _columnsBox is null) return;

        // Drop selections of cards that no longer exist.
        _selected.RemoveWhere(id => !Ws.Cards.ContainsKey(id));
        UpdateSelectionBar();
        _titleControls.Clear();
        _boardTitles.Clear();

        // List (right)
        int listScroll = _listView.ScrollV;
        _listView.Build(this);

        // Board (left)
        int hscroll = _hscroll.ScrollHorizontal;
        int vscroll = _hscroll.ScrollVertical;

        foreach (var child in _columnsBox.GetChildren())
        {
            _columnsBox.RemoveChild(child);
            child.QueueFree();
        }
        _cardViews.Clear();
        _columnViews.Clear();
        _activeDrop = null;

        foreach (var column in Ws.Board.Columns)
        {
            var view = BoardColumnView.Create(this, column);
            _columnsBox.AddChild(view);
            _columnViews.Add(view);
        }

        // Keep the board wide enough to show every column without scrolling sideways.
        int columns = Ws.Board.Columns.Count;
        _hscroll.CustomMinimumSize = new Vector2(columns * BoardColumnView.Width + Math.Max(0, columns - 1) * ColumnGap + 6 + 12, 0);

        RestoreAfterLayout(hscroll, vscroll, listScroll);
    }

    /// <summary>Waits a frame for layout, then restores scroll positions and starts any pending rename.</summary>
    private async void RestoreAfterLayout(int hscroll, int vscroll, int listScroll)
    {
        await ToSignal(GetTree(), SceneTree.SignalName.ProcessFrame);
        if (!IsInstanceValid(this)) return;
        _hscroll.ScrollHorizontal = hscroll;
        _hscroll.ScrollVertical = vscroll;
        _listView.ScrollV = listScroll;

        if (_renameCardAfterRebuild is { } card)
        {
            _renameCardAfterRebuild = null;
            BeginRenameCard(card, _renameInBoard);
            _renameInBoard = false;
        }
        if (_renameColumnAfterRebuild is { } column)
        {
            _renameColumnAfterRebuild = null;
            BeginRenameColumn(column);
        }
    }

    internal void Register(CardView view) => _cardViews[view.CardId] = view;

    /// <summary>The control showing a card's title; the rename box opens over it.</summary>
    internal void RegisterTitle(CardId id, Control title) => _titleControls[id] = title;

    /// <summary>The card's title on the board side, for renaming in place there.</summary>
    internal void RegisterBoardTitle(CardId id, Control title) => _boardTitles[id] = title;

    private static int PriorityRank(Priority p) => BoardVisuals.Normalize(p) switch
    {
        Priority.High => 3,
        Priority.Medium => 2,
        Priority.Low => 1,
        _ => 0,
    };

    /// <summary>A column's cards, highest priority first (keeping their order within the same priority).</summary>
    internal IEnumerable<CardId> OrderedCards(BoardColumn column)
    {
        var ws = Ws;
        if (ws is null) return column.Cards;
        return column.Cards
            .Where(ws.Cards.ContainsKey)
            .OrderByDescending(id => PriorityRank(ws.Cards[id].Priority))
            .ToList();
    }

    internal bool Matches(Card card)
    {
        string f = _filter?.Text.Trim() ?? "";
        return f.Length == 0
               || card.Title.Contains(f, StringComparison.CurrentCultureIgnoreCase)
               || Workspace.KeyOf(card).Contains(f, StringComparison.OrdinalIgnoreCase);
    }

    private void ApplyFilter()
    {
        if (Ws is null) return;
        QueueRebuild();
    }

    // ------------------------------------------------------------------
    // Selection
    // ------------------------------------------------------------------

    internal bool IsSelected(CardId id) => _selected.Contains(id);

    internal void SetSelected(CardId id, bool selected)
    {
        bool changed = selected ? _selected.Add(id) : _selected.Remove(id);
        if (!changed) return;
        UpdateSelectionBar();
        _listView.RefreshSelection();
    }

    internal void SetAllSelected(IEnumerable<CardId> ids, bool selected)
    {
        foreach (var id in ids)
            if (selected) _selected.Add(id);
            else _selected.Remove(id);
        UpdateSelectionBar();
        _listView.RefreshSelection();
    }

    private void UpdateSelectionBar()
    {
        if (_selectionBar is null) return;
        _selectionBar.Visible = _selected.Count > 0;
        _selectionLabel.Text = _selected.Count == 1 ? "1 selected" : $"{_selected.Count} selected";
    }

    private void DeleteSelected()
    {
        if (Ws is null || _selected.Count == 0) return;
        var ids = _selected.ToList();
        string what = ids.Count == 1 ? "this task" : $"{ids.Count} tasks";
        Confirm("Delete tasks", $"Delete {what}?\nAttached documents, images and sheets are kept.", () =>
        {
            foreach (var id in ids) Ws.Apply(new DeleteCard(id));
            _selected.Clear();
            UpdateSelectionBar();
        });
    }

    internal bool IsExpanded(CardId id) => _expanded.Contains(id);

    internal void ToggleExpanded(CardId id)
    {
        if (!_expanded.Remove(id)) _expanded.Add(id);
        QueueRebuild();
    }

    internal void RequestOpenNote(NoteId id) => OpenNoteRequested?.Invoke(id);
    internal void RequestOpenSheet(SheetId id) => OpenSheetRequested?.Invoke(id);

    // ------------------------------------------------------------------
    // Cards and columns
    // ------------------------------------------------------------------

    internal void CreateCard(ColumnId column)
    {
        if (Ws is null) return;
        var id = Ws.NewCard(column, "New card");
        if (id.IsEmpty) return;
        _renameCardAfterRebuild = id;
        _renameInBoard = true;
    }

    /// <summary>Adds the task described by the create row, with its priority and attachments.</summary>
    internal void CreateFromDraft()
    {
        if (Ws is null) return;
        string title = Draft.Title.Trim();
        if (title.Length == 0) return;
        var column = DefaultColumn();
        if (column is null) return;

        var id = Ws.NewCard(column.Id, title);
        if (id.IsEmpty) return;
        if (Draft.Priority != Priority.None) Ws.Apply(new SetCardPriority(id, Draft.Priority));

        bool attached = false;
        if (Draft.WithNote)
        {
            Ws.Apply(new AttachToCard(id, Attachment.Of(Ws.NewNote(UntitledDoc))));
            attached = true;
        }
        else if (Draft.ExistingNote is { } existingNote && Ws.Notes.ContainsKey(existingNote))
        {
            Ws.Apply(new AttachToCard(id, Attachment.Of(existingNote)));
            attached = true;
        }
        if (Draft.WithSheet)
        {
            Ws.Apply(new AttachToCard(id, Attachment.Of(Ws.NewSheet(UntitledSheet))));
            attached = true;
        }
        else if (Draft.ExistingSheet is { } existingSheet && Ws.Sheets.ContainsKey(existingSheet))
        {
            Ws.Apply(new AttachToCard(id, Attachment.Of(existingSheet)));
            attached = true;
        }
        if (Draft.ImagePath is { } path && Store is not null)
        {
            try
            {
                var image = Store.ImportImage(Ws, path);
                Ws.Apply(new AttachToCard(id, Attachment.Of(image.Id)));
                attached = true;
            }
            catch (Exception e)
            {
                GD.PrintErr($"Could not attach image '{path}': {e.Message}");
            }
        }
        if (attached) _expanded.Add(id);

        Draft.Reset();
        Draft.Open = true;   // stay open for the next task
        QueueRebuild();
    }

    internal void CloseDraft()
    {
        Draft.Reset();
        Draft.Open = false;
        QueueRebuild();
    }

    internal void PickDraftImage()
    {
        _imageForDraft = true;
        _imageDialog.PopupCentered(new Vector2I(900, 600));
    }

    private void AddColumn()
    {
        if (Ws is null) return;
        _renameColumnAfterRebuild = Ws.NewColumn("New column");
    }

    internal void MoveCard(CardId card, ColumnId column, int index)
    {
        _activeDrop = null;
        Ws?.Apply(new Polyphyr.Core.MoveCard(card, column, index));
    }

    internal void SetActiveDropColumn(BoardColumnView column)
    {
        if (_activeDrop == column) return;
        _activeDrop?.HideDropLine();
        _activeDrop = column;
    }

    public static Godot.Collections.Dictionary DragData(CardId id)
        => new() { { "polyphyr_card", id.Value.ToString("D") } };

    public static bool TryGetDraggedCard(Variant data, out CardId id)
    {
        id = default;
        if (data.VariantType != Variant.Type.Dictionary) return false;
        var dict = data.AsGodotDictionary();
        if (!dict.TryGetValue("polyphyr_card", out var value)) return false;
        if (!Guid.TryParse(value.AsString(), out var guid)) return false;
        id = new CardId(guid);
        return true;
    }

    // ------------------------------------------------------------------
    // Rename box (cards and columns)
    // ------------------------------------------------------------------

    /// <summary>Opens the rename box over the card's title in the list, or on the board when <paramref name="inBoard"/>.</summary>
    internal void BeginRenameCard(CardId id, bool inBoard = false)
    {
        if (Ws is null || !Ws.Cards.TryGetValue(id, out var card)) return;
        var preferred = inBoard ? _boardTitles : _titleControls;
        var fallback = inBoard ? _titleControls : _boardTitles;
        if (!preferred.TryGetValue(id, out var title) && !fallback.TryGetValue(id, out title)) return;
        if (!IsInstanceValid(title) || !title.IsVisibleInTree()) return;
        var rect = title.GetGlobalRect();
        float width = inBoard && _cardViews.TryGetValue(id, out var view) ? view.Size.X - 8 : rect.Size.X + 16;
        BeginRename(new Rect2(rect.Position - new Vector2(8, 6), new Vector2(width, rect.Size.Y)), card.Title,
            text => Ws.Apply(new SetCardTitle(id, text)));
    }

    internal void BeginRenameColumn(ColumnId id)
    {
        var column = Ws?.FindColumn(id);
        var view = _columnViews.FirstOrDefault(v => v.ColumnId == id);
        if (column is null || view is null) return;
        var rect = view.NameGlobalRect;
        BeginRename(new Rect2(rect.Position - new Vector2(8, 6), new Vector2(BoardColumnView.Width - 20, rect.Size.Y)), column.Name,
            name => Ws!.Apply(new RenameColumn(id, name)));
    }

    private void BeginRename(Rect2 globalRect, string current, Action<string> commit)
    {
        _renameCommit = commit;
        _renameCancelled = false;
        _renameEdit.Text = current;
        _renamePopup.Popup(new Rect2I(ToPopup(globalRect.Position), new Vector2I(Mathf.Max(200, (int)globalRect.Size.X), 0)));
        _renameEdit.GrabFocus();
        _renameEdit.SelectAll();
    }

    private Vector2I ToPopup(Vector2 global)
        => GetViewport().GuiEmbedSubwindows ? (Vector2I)global : GetWindow().Position + (Vector2I)global;

    private void PopupAtMouse(PopupMenu menu)
    {
        menu.ResetSize();
        menu.Position = TextFieldMenu.PopupPosition(this);
        menu.Popup();
    }

    // ------------------------------------------------------------------
    // Menus
    // ------------------------------------------------------------------

    private void BuildPopups()
    {
        // Card menu
        _cardMenu = new PopupMenu();
        _priorityMenu = new PopupMenu();
        FillPriorityMenu(_priorityMenu);
        _cardMenu.AddChild(_priorityMenu);
        _cardMenu.AddItem("Rename", CardRename);
        _cardMenu.AddSubmenuNodeItem("Priority", _priorityMenu);
        _cardMenu.AddItem("Attach…", CardAttach);
        _cardMenu.AddItem("Pin to Home", CardPin);
        _cardMenu.AddSeparator();
        _cardMenu.AddItem("Delete card", CardDelete);
        _cardMenu.IdPressed += OnCardMenu;
        AddChild(_cardMenu);

        // Attach menu: pick a kind, then a dropdown with "New", search, and the existing ones.
        _attachMenu = new PopupMenu();
        _attachMenu.AddItem("Document", AttachNewNote);
        _attachMenu.AddItem("Image", AttachImage);
        _attachMenu.AddItem("Sheet", AttachNewSheet);
        _attachMenu.IdPressed += kind =>
        {
            if (_menuCard is { } card) OpenAttachPicker(card, (int)kind);
        };
        AddChild(_attachMenu);
        _picker = new AttachPicker();
        AddChild(_picker);

        // Attachment (right-click on an attached item)
        _attachmentMenu = new PopupMenu();
        _attachmentMenu.IdPressed += OnAttachmentMenu;
        AddChild(_attachmentMenu);

        // Column menu
        _columnMenu = new PopupMenu();
        _columnMenu.AddItem("Delete column", ColDelete);
        _columnMenu.IdPressed += OnColumnMenu;
        AddChild(_columnMenu);

        // Image picker
        _imageDialog = new FileDialog
        {
            FileMode = FileDialog.FileModeEnum.OpenFile,
            Access = FileDialog.AccessEnum.Filesystem,
            Title = "Attach an image",
            Filters = new[] { "*.png, *.jpg, *.jpeg, *.webp, *.bmp, *.svg ; Images" },
        };
        _imageDialog.FileSelected += path =>
        {
            if (_imageForDraft)
            {
                _imageForDraft = false;
                Draft.ImagePath = path;
                QueueRebuild();
            }
            else AttachImageFile(path);
        };
        _imageDialog.Canceled += () => _imageForDraft = false;
        AddChild(_imageDialog);

        // Image preview
        _preview = new PopupPanel();
        _previewImage = new TextureRect
        {
            ExpandMode = TextureRect.ExpandModeEnum.IgnoreSize,
            StretchMode = TextureRect.StretchModeEnum.KeepAspectCentered,
        };
        _preview.AddChild(_previewImage);
        AddChild(_preview);

        // Rename box
        _renamePopup = new PopupPanel();
        _renameEdit = new LineEdit();
        _renameEdit.TextSubmitted += _ => _renamePopup.Hide();
        _renameEdit.GuiInput += e =>
        {
            if (!e.IsActionPressed("ui_cancel")) return;
            _renameCancelled = true;
            _renamePopup.Hide();
        };
        _renamePopup.AddChild(_renameEdit);
        _renamePopup.PopupHide += () =>
        {
            string text = _renameEdit.Text.Trim();
            if (!_renameCancelled && text.Length > 0) _renameCommit?.Invoke(text);
            _renameCommit = null;
            _renameCancelled = false;
        };
        AddChild(_renamePopup);

        // Status, priority and due-date pickers (opened from the list's cells)
        BuildStatusPopup();

        _priorityPicker = new PopupMenu();
        FillPriorityMenu(_priorityPicker);
        AddChild(_priorityPicker);


        BuildDuePopup();

        // Confirmation
        _confirm = new ConfirmationDialog { OkButtonText = "Delete" };
        _confirm.Confirmed += () =>
        {
            _confirmAction?.Invoke();
            _confirmAction = null;
        };
        AddChild(_confirm);
    }

    private void Confirm(string title, string message, Action action)
    {
        _confirm.Title = title;
        _confirm.DialogText = message;
        _confirmAction = action;
        _confirm.ResetSize();
        _confirm.PopupCentered(new Vector2I(420, 0));
    }

    private void FillPriorityMenu(PopupMenu menu)
    {
        foreach (var p in BoardVisuals.PriorityOrder)
            menu.AddRadioCheckItem(BoardVisuals.PriorityName(p), PriorityBase + (int)p);
        menu.AddSeparator();
        menu.AddRadioCheckItem("No priority", PriorityBase + (int)Priority.None);
        menu.IdPressed += id =>
        {
            if (_menuCard is { } card) Ws?.Apply(new SetCardPriority(card, (Priority)((int)id - PriorityBase)));
        };
    }

    private static void CheckPriority(PopupMenu menu, Priority current)
    {
        foreach (var p in Enum.GetValues<Priority>())
        {
            int index = menu.GetItemIndex(PriorityBase + (int)p);
            if (index >= 0) menu.SetItemChecked(index, BoardVisuals.Normalize(current) == p);
        }
    }

    internal void ShowPriorityPicker(CardId id)
    {
        if (Ws is null || !Ws.Cards.TryGetValue(id, out var card)) return;
        _menuCard = id;
        CheckPriority(_priorityPicker, card.Priority);
        PopupAtMouse(_priorityPicker);
    }

    internal void ShowStatusMenu(CardId id)
    {
        _statusForSelection = false;
        ShowStatusMenuFor(id);
    }

    private void BuildStatusPopup()
    {
        _statusPopup = new PopupPanel();
        var pad = new MarginContainer();
        foreach (var side in new[] { "margin_left", "margin_right", "margin_top", "margin_bottom" })
            pad.AddThemeConstantOverride(side, 4);
        _statusPopup.AddChild(pad);
        var box = new VBoxContainer { CustomMinimumSize = new Vector2(220, 0) };
        box.AddThemeConstantOverride("separation", 4);
        pad.AddChild(box);

        _statusList = new VBoxContainer();
        _statusList.AddThemeConstantOverride("separation", 2);
        box.AddChild(_statusList);

        // The one extra status is always just "Custom".
        _statusCustom = new Button
        {
            Text = "     " + CustomName,
            Alignment = HorizontalAlignment.Left,
            FocusMode = FocusModeEnum.None,
            SizeFlagsHorizontal = SizeFlags.ExpandFill,
        };
        _statusCustom.AddThemeColorOverride("font_color", AppTheme.TextDim);
        _statusCustom.AddThemeStyleboxOverride("normal", AppTheme.Box(new Color(0, 0, 0, 0), 5, 10, 6));
        _statusCustom.AddThemeStyleboxOverride("hover", AppTheme.Box(AppTheme.Hover, 5, 10, 6));
        _statusCustom.AddThemeStyleboxOverride("pressed", AppTheme.Box(AppTheme.Hover, 5, 10, 6));
        _statusCustom.Pressed += () =>
        {
            if (Ws is null) return;
            var custom = CustomStatus();
            if (custom is not null) ApplyStatus(custom.Id);
            else if (Ws.Board.Columns.Count < MaxStatuses) ApplyStatus(Ws.NewColumn(CustomName));
        };
        _statusCustomDivider = new ColorRect { Color = AppTheme.Border, CustomMinimumSize = new Vector2(0, 1) };
        box.AddChild(_statusCustomDivider);
        box.AddChild(_statusCustom);
        AddChild(_statusPopup);
    }

    private void ShowStatusMenuFor(CardId? id)
    {
        if (Ws is null) return;
        _menuCard = id;
        var current = id is { } c ? Ws.GetColumnOf(c) : null;

        foreach (var child in _statusList.GetChildren())
        {
            _statusList.RemoveChild(child);
            child.QueueFree();
        }
        foreach (var column in Ws.Board.Columns)
        {
            var (bg, border, text) = BoardVisuals.StatusColors(BoardVisuals.ToneOf(column));
            bool isCurrent = current == column;
            var option = new Button
            {
                Text = (isCurrent ? "✓  " : "     ") + column.Name,
                Alignment = HorizontalAlignment.Left,
                FocusMode = FocusModeEnum.None,
                SizeFlagsHorizontal = SizeFlags.ExpandFill,
            };
            option.AddThemeColorOverride("font_color", text);
            option.AddThemeColorOverride("font_hover_color", text);
            option.AddThemeStyleboxOverride("normal", AppTheme.Box(isCurrent ? bg : new Color(0, 0, 0, 0), 5, 10, 6));
            option.AddThemeStyleboxOverride("hover", AppTheme.Box(bg.A > 0 ? bg : AppTheme.Hover, 5, 10, 6, border, 1));
            option.AddThemeStyleboxOverride("pressed", AppTheme.Box(bg.A > 0 ? bg : AppTheme.Hover, 5, 10, 6, border, 1));
            var columnId = column.Id;
            option.Pressed += () => ApplyStatus(columnId);
            _statusList.AddChild(option);
        }
        // Once the Custom status exists it's in the list above.
        bool canAdd = CustomStatus() is null && Ws.Board.Columns.Count < MaxStatuses;
        _statusCustom.Visible = canAdd;
        _statusCustomDivider.Visible = canAdd;

        _statusPopup.ResetSize();
        _statusPopup.Popup(new Rect2I(TextFieldMenu.PopupPosition(this), Vector2I.Zero));
    }

    private void ApplyStatus(ColumnId target)
    {
        _statusPopup.Hide();
        if (Ws is null) return;
        var ids = _statusForSelection ? _selected.ToList() : _menuCard is { } c ? new List<CardId> { c } : new List<CardId>();
        foreach (var id in ids)
        {
            if (Ws.GetColumnOf(id)?.Id == target) continue;
            Ws.Apply(new Polyphyr.Core.MoveCard(id, target, int.MaxValue));
        }
        _statusForSelection = false;
    }

    private void BuildDuePopup()
    {
        _duePopup = new PopupPanel();
        var pad = new MarginContainer();
        foreach (var side in new[] { "margin_left", "margin_right", "margin_top", "margin_bottom" })
            pad.AddThemeConstantOverride(side, 6);
        _duePopup.AddChild(pad);
        var list = new VBoxContainer { CustomMinimumSize = new Vector2(240, 0) };
        list.AddThemeConstantOverride("separation", 6);
        pad.AddChild(list);

        // Days ▾ : in 1–6 days
        list.AddChild(DueDropdown("Days", 6, n => n == 1 ? "In 1 day" : $"In {n} days", n => DateTime.Today.AddDays(n)));
        // Weeks ▾ : in 1–3 weeks
        list.AddChild(DueDropdown("Weeks", 3, n => n == 1 ? "In 1 week" : $"In {n} weeks", n => DateTime.Today.AddDays(7 * n)));

        // Months: type any number
        var monthRow = new HBoxContainer();
        monthRow.AddThemeConstantOverride("separation", 8);
        var monthLabel = new Label { Text = "Months", VerticalAlignment = VerticalAlignment.Center, CustomMinimumSize = new Vector2(70, 0) };
        monthLabel.AddThemeColorOverride("font_color", AppTheme.TextDim);
        monthRow.AddChild(monthLabel);
        _dueMonths = new LineEdit { PlaceholderText = "e.g. 2", SizeFlagsHorizontal = SizeFlags.ExpandFill, MaxLength = 3 };
        _dueMonths.TextChanged += text =>
        {
            // Digits only.
            string digits = new string(text.Where(char.IsDigit).ToArray());
            if (digits != text)
            {
                _dueMonths.Text = digits;
                _dueMonths.CaretColumn = digits.Length;
            }
        };
        _dueMonths.TextSubmitted += text =>
        {
            if (int.TryParse(text, out int months) && months > 0)
                SetDue(DateOnly.FromDateTime(DateTime.Today.AddMonths(months)));
        };
        monthRow.AddChild(_dueMonths);
        list.AddChild(monthRow);

        list.AddChild(new ColorRect { Color = AppTheme.Border, CustomMinimumSize = new Vector2(0, 1) });

        // Exact date
        _dueEdit = new LineEdit { PlaceholderText = "Exact date (YYYY-MM-DD)", SizeFlagsHorizontal = SizeFlags.ExpandFill };
        _dueEdit.TextSubmitted += text =>
        {
            if (TryParseDate(text, out var date)) SetDue(date);
            else if (text.Trim().Length == 0) SetDue(null);
        };
        list.AddChild(_dueEdit);

        var clear = new Button { Text = "Clear due date", FocusMode = FocusModeEnum.None, Alignment = HorizontalAlignment.Left };
        clear.AddThemeColorOverride("font_hover_color", AppTheme.Danger);
        clear.Pressed += () => SetDue(null);
        list.AddChild(clear);

        AddChild(_duePopup);
    }

    /// <summary>A full-width "Label ▾" button that drops down a list of N relative dates.</summary>
    private MenuButton DueDropdown(string label, int count, Func<int, string> itemText, Func<int, DateTime> pick)
    {
        var button = new MenuButton
        {
            Text = label + "  ▾",
            Flat = false,
            FocusMode = FocusModeEnum.None,
            Alignment = HorizontalAlignment.Left,
            SizeFlagsHorizontal = SizeFlags.ExpandFill,
        };
        var menu = button.GetPopup();
        string Text(int n) => $"{itemText(n)}   ·   {DateOnly.FromDateTime(pick(n)):ddd, MMM d}";
        for (int n = 1; n <= count; n++) menu.AddItem(Text(n), n);
        // Recompute the dates each time it opens, in case the day has changed.
        menu.AboutToPopup += () =>
        {
            for (int n = 1; n <= count; n++) menu.SetItemText(menu.GetItemIndex(n), Text(n));
        };
        menu.IdPressed += n => SetDue(DateOnly.FromDateTime(pick((int)n)));
        return button;
    }

    private static bool TryParseDate(string text, out DateOnly date)
    {
        text = text.Trim();
        if (DateOnly.TryParseExact(text, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture,
                System.Globalization.DateTimeStyles.None, out date)) return true;
        return DateOnly.TryParse(text, System.Globalization.CultureInfo.CurrentCulture,
            System.Globalization.DateTimeStyles.None, out date);
    }

    private void SetDue(DateOnly? date)
    {
        if (_menuCard is { } id) Ws?.Apply(new SetCardDueDate(id, date));
        _duePopup.Hide();
    }

    internal void ShowDueEditor(CardId id, Rect2 globalRect)
    {
        if (Ws is null || !Ws.Cards.TryGetValue(id, out var card)) return;
        _menuCard = id;
        _dueEdit.Text = card.DueDate?.ToString("yyyy-MM-dd") ?? "";
        _dueMonths.Text = "";
        _duePopup.Popup(new Rect2I(ToPopup(globalRect.Position + new Vector2(0, globalRect.Size.Y)), Vector2I.Zero));
    }

    /// <summary>Opens what an attachment points at: notes in Notes, images in the preview, sheets in Sheets.</summary>
    internal void OpenAttachment(Attachment a)
    {
        switch (a.Kind)
        {
            case AttachmentKind.Note: RequestOpenNote(NoteId.From(a.TargetId)); break;
            case AttachmentKind.Image: PreviewImage(ImageId.From(a.TargetId)); break;
            case AttachmentKind.Sheet: RequestOpenSheet(SheetId.From(a.TargetId)); break;
        }
    }

    internal void ShowCardMenu(CardId id)
    {
        if (Ws is null || !Ws.Cards.TryGetValue(id, out var card)) return;
        _menuCard = id;
        CheckPriority(_priorityMenu, card.Priority);
        bool pinned = Settings?.IsPinned(AppSettings.PinKind.Task, id.Value) == true;
        _cardMenu.SetItemText(_cardMenu.GetItemIndex(CardPin), pinned ? "Unpin from Home" : "Pin to Home");
        PopupAtMouse(_cardMenu);
    }

    private void OnCardMenu(long id)
    {
        if (Ws is null || _menuCard is not { } cardId || !Ws.Cards.TryGetValue(cardId, out var card)) return;
        switch ((int)id)
        {
            case CardRename:
                BeginRenameCard(cardId);
                break;
            case CardAttach:
                ShowAttachMenu(cardId);
                break;
            case CardPin:
                Settings?.TogglePin(AppSettings.PinKind.Task, cardId.Value);
                break;
            case CardDelete:
                string name = string.IsNullOrWhiteSpace(card.Title) ? "Untitled" : card.Title;
                Confirm("Delete card", $"Delete \"{name}\"?\nAttached documents, images and sheets are kept.",
                    () => Ws.Apply(new DeleteCard(cardId)));
                break;
        }
    }

    internal void ShowAttachMenu(CardId id)
    {
        if (Ws is null || !Ws.Cards.TryGetValue(id, out _)) return;
        _menuCard = id;

        PopupAtMouse(_attachMenu);
    }

    private static string TitleOr(string title) => string.IsNullOrWhiteSpace(title) ? "Untitled" : title;

    /// <summary>The dropdown for one kind of attachment on an existing task.</summary>
    private void OpenAttachPicker(CardId cardId, int kind)
    {
        if (Ws is null || !Ws.Cards.TryGetValue(cardId, out var card)) return;
        var ws = Ws;
        var items = new List<AttachPicker.Item>();
        void AttachIt(Attachment a)
        {
            ws.Apply(new AttachToCard(cardId, a));
            _expanded.Add(cardId);
        }
        switch (kind)
        {
            case AttachNewNote:
                foreach (var note in ws.Notes.Values.OrderBy(n => n.Title, StringComparer.CurrentCultureIgnoreCase))
                {
                    var a = Attachment.Of(note.Id);
                    if (!card.Attachments.Contains(a)) items.Add(new(TitleOr(note.Title), () => AttachIt(a)));
                }
                _picker.Open(TextFieldMenu.PopupPosition(this), "documents", "New document", () => AttachNew(cardId, AttachNewNote), items);
                break;
            case AttachNewSheet:
                foreach (var sheet in ws.Sheets.Values.OrderBy(sh => sh.Title, StringComparer.CurrentCultureIgnoreCase))
                {
                    var a = Attachment.Of(sheet.Id);
                    if (!card.Attachments.Contains(a)) items.Add(new(TitleOr(sheet.Title), () => AttachIt(a)));
                }
                _picker.Open(TextFieldMenu.PopupPosition(this), "sheets", "New sheet", () => AttachNew(cardId, AttachNewSheet), items);
                break;
            case AttachImage:
                foreach (var image in ws.Images.Values.OrderBy(i => i.OriginalName, StringComparer.CurrentCultureIgnoreCase))
                {
                    var a = Attachment.Of(image.Id);
                    if (!card.Attachments.Contains(a)) items.Add(new(TitleOr(image.OriginalName), () => AttachIt(a)));
                }
                _picker.Open(TextFieldMenu.PopupPosition(this), "images", "From file…", () => AttachNew(cardId, AttachImage), items);
                break;
        }
    }

    /// <summary>The document / sheet dropdown in the create row: a new one, an existing one, or none.</summary>
    internal void ShowDraftPicker(bool sheet)
    {
        if (Ws is null) return;
        var items = new List<AttachPicker.Item>();
        void Done() => QueueRebuild();
        if (sheet)
        {
            foreach (var sh in Ws.Sheets.Values.OrderBy(x => x.Title, StringComparer.CurrentCultureIgnoreCase))
            {
                var id = sh.Id;
                items.Add(new(TitleOr(sh.Title), () => { Draft.WithSheet = false; Draft.ExistingSheet = id; Done(); }));
            }
            bool any = Draft.WithSheet || Draft.ExistingSheet is not null;
            _picker.Open(TextFieldMenu.PopupPosition(this), "sheets", "New sheet",
                () => { Draft.WithSheet = true; Draft.ExistingSheet = null; Done(); }, items,
                any ? () => { Draft.WithSheet = false; Draft.ExistingSheet = null; Done(); } : null);
        }
        else
        {
            foreach (var note in Ws.Notes.Values.OrderBy(x => x.Title, StringComparer.CurrentCultureIgnoreCase))
            {
                var id = note.Id;
                items.Add(new(TitleOr(note.Title), () => { Draft.WithNote = false; Draft.ExistingNote = id; Done(); }));
            }
            bool any = Draft.WithNote || Draft.ExistingNote is not null;
            _picker.Open(TextFieldMenu.PopupPosition(this), "documents", "New document",
                () => { Draft.WithNote = true; Draft.ExistingNote = null; Done(); }, items,
                any ? () => { Draft.WithNote = false; Draft.ExistingNote = null; Done(); } : null);
        }
    }

    /// <summary>What the create row will attach, for its tooltips.</summary>
    internal string? DraftNoteName => Draft.WithNote ? "New document"
        : Draft.ExistingNote is { } n && Ws is not null && Ws.Notes.TryGetValue(n, out var note) ? TitleOr(note.Title) : null;

    internal string? DraftSheetName => Draft.WithSheet ? "New sheet"
        : Draft.ExistingSheet is { } s && Ws is not null && Ws.Sheets.TryGetValue(s, out var sheet) ? TitleOr(sheet.Title) : null;

    public const string UntitledDoc = "Untitled doc", UntitledSheet = "Untitled sheet";

    private void AttachNew(CardId cardId, int kind) => OnAttachMenuFor(cardId, kind);

    private void OnAttachMenuFor(CardId cardId, int id)
    {
        if (Ws is null || !Ws.Cards.ContainsKey(cardId)) return;
        switch (id)
        {
            case AttachNewNote:
            {
                var note = Ws.NewNote(UntitledDoc);
                Ws.Apply(new AttachToCard(cardId, Attachment.Of(note)));
                _expanded.Add(cardId);
                break;
            }
            case AttachImage:
                _imageForDraft = false;
                _imageDialog.PopupCentered(new Vector2I(900, 600));
                break;
            case AttachNewSheet:
            {
                var sheet = Ws.NewSheet(UntitledSheet);
                Ws.Apply(new AttachToCard(cardId, Attachment.Of(sheet)));
                _expanded.Add(cardId);
                break;
            }
        }
    }

    private void AttachImageFile(string path)
    {
        if (Ws is null || Store is null || _menuCard is not { } cardId) return;
        try
        {
            var image = Store.ImportImage(Ws, path);
            Ws.Apply(new AttachToCard(cardId, Attachment.Of(image.Id)));
            _expanded.Add(cardId);
        }
        catch (Exception e)
        {
            GD.PrintErr($"Could not attach image '{path}': {e.Message}");
        }
    }

    internal void ShowAttachmentMenu(CardId cardId, Attachment attachment)
    {
        if (Ws is null || !Ws.Cards.TryGetValue(cardId, out var card)) return;
        _menuCard = cardId;
        _menuAttachment = attachment;
        _attachmentMenu.Clear();
        switch (attachment.Kind)
        {
            case AttachmentKind.Note:
            case AttachmentKind.Sheet:
                _attachmentMenu.AddItem("Open", AttOpen);
                break;
            case AttachmentKind.Image:
                _attachmentMenu.AddItem("View", AttView);
                bool isCover = card.CoverImage == ImageId.From(attachment.TargetId);
                _attachmentMenu.AddItem(isCover ? "Remove as cover" : "Set as cover", AttCover);
                break;
        }
        _attachmentMenu.AddSeparator();
        _attachmentMenu.AddItem("Remove from card", AttRemove);
        PopupAtMouse(_attachmentMenu);
    }

    private void OnAttachmentMenu(long id)
    {
        if (Ws is null || _menuCard is not { } cardId || _menuAttachment is not { } a || !Ws.Cards.TryGetValue(cardId, out var card)) return;
        switch ((int)id)
        {
            case AttOpen when a.Kind == AttachmentKind.Note:
                RequestOpenNote(NoteId.From(a.TargetId));
                break;
            case AttOpen when a.Kind == AttachmentKind.Sheet:
                RequestOpenSheet(SheetId.From(a.TargetId));
                break;
            case AttView:
                PreviewImage(ImageId.From(a.TargetId));
                break;
            case AttCover:
            {
                var image = ImageId.From(a.TargetId);
                Ws.Apply(new SetCardCover(cardId, card.CoverImage == image ? (ImageId?)null : image));
                break;
            }
            case AttRemove:
                Ws.Apply(new DetachFromCard(cardId, a));
                break;
        }
    }

    internal void ShowColumnMenu(ColumnId id)
    {
        if (Ws is null) return;
        _menuColumn = id;
        int delete = _columnMenu.GetItemIndex(ColDelete);
        _columnMenu.SetItemDisabled(delete, Ws.Board.Columns.Count <= 1);
        PopupAtMouse(_columnMenu);
    }

    private void OnColumnMenu(long id)
    {
        if (Ws is null || _menuColumn is not { } columnId) return;
        var column = Ws.FindColumn(columnId);
        if (column is null) return;
        switch ((int)id)
        {
            case ColDelete:
                var target = Ws.Board.Columns.FirstOrDefault(c => c.Id != columnId);
                if (target is null) return;
                string message = column.Cards.Count == 0
                    ? $"Delete the \"{column.Name}\" column?"
                    : $"Delete the \"{column.Name}\" column?\nIts {column.Cards.Count} card(s) move to \"{target.Name}\".";
                Confirm("Delete column", message, () => Ws.Apply(new RemoveColumn(columnId, target.Id)));
                break;
        }
    }

    internal void PreviewImage(ImageId id)
    {
        var texture = Images.Full(id);
        if (texture is null) return;
        var window = GetWindow().Size;
        var max = new Vector2(window.X * 0.8f, window.Y * 0.8f);
        var size = texture.GetSize();
        float scale = Mathf.Min(1f, Mathf.Min(max.X / size.X, max.Y / size.Y));
        _previewImage.Texture = texture;
        _previewImage.CustomMinimumSize = size * scale;
        _preview.PopupCentered(new Vector2I((int)(size.X * scale) + 12, (int)(size.Y * scale) + 12));
    }
}
