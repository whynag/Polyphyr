using System.Collections.Generic;
using Godot;
using Polyphyr.Core;

namespace Polyphyr.UI.Board;

/// <summary>
/// One status column on the board: name with the task count under it, then the cards.
/// (Tasks are created from the list, not here.)
/// The column is as tall as its cards (the whole board scrolls), sits just a shade lighter than the
/// background, and brightens very slightly on hover.
/// </summary>
public partial class BoardColumnView : PanelContainer
{
    public const float Width = 236f;

    private static Color BaseColor => AppTheme.Subtle;
    private static Color HoverColor => AppTheme.SubtleHover;

    public ColumnId ColumnId { get; private set; }

    private BoardTab _board = null!;
    private VBoxContainer _cards = null!;
    private Label _name = null!;
    private ColorRect _dropLine = null!;
    private StyleBoxFlat _style = null!;
    private float _hover;
    private readonly List<CardView> _views = new();

    public static BoardColumnView Create(BoardTab board, BoardColumn column)
    {
        var view = new BoardColumnView();
        view.Setup(board, column);
        return view;
    }

    public Rect2 NameGlobalRect => _name.GetGlobalRect();

    private void Setup(BoardTab board, BoardColumn column)
    {
        _board = board;
        ColumnId = column.Id;
        var ws = board.Ws!;

        CustomMinimumSize = new Vector2(Width, 0);
        SizeFlagsVertical = SizeFlags.ShrinkBegin;   // as tall as its cards
        MouseFilter = MouseFilterEnum.Pass;
        _style = AppTheme.Box(BaseColor, 10);
        AddThemeStyleboxOverride("panel", _style);

        var pad = new MarginContainer { MouseFilter = MouseFilterEnum.Pass };
        pad.AddThemeConstantOverride("margin_left", 10);
        pad.AddThemeConstantOverride("margin_right", 10);
        pad.AddThemeConstantOverride("margin_top", 12);
        pad.AddThemeConstantOverride("margin_bottom", 8);
        AddChild(pad);

        var box = new VBoxContainer { MouseFilter = MouseFilterEnum.Pass };
        box.AddThemeConstantOverride("separation", 10);
        pad.AddChild(box);

        // Header: status name, with the number of tasks under it.
        var header = new VBoxContainer { MouseFilter = MouseFilterEnum.Stop };
        header.AddThemeConstantOverride("separation", 0);
        box.AddChild(header);
        _name = new Label
        {
            Text = column.Name,
            SizeFlagsHorizontal = SizeFlags.ExpandFill,
            TextOverrunBehavior = TextServer.OverrunBehavior.TrimEllipsis,
            MouseFilter = MouseFilterEnum.Pass,
        };
        _name.AddThemeFontOverride("font", AppFonts.SemiBold);
        _name.AddThemeFontSizeOverride("font_size", 14);
        _name.AddThemeColorOverride("font_color", BoardVisuals.StatusColors(BoardVisuals.ToneOf(column)).Text);
        header.AddChild(_name);
        int count = column.Cards.Count;
        var countLabel = new Label { Text = count == 1 ? "1 task" : $"{count} tasks", MouseFilter = MouseFilterEnum.Pass };
        countLabel.AddThemeFontSizeOverride("font_size", 12);
        countLabel.AddThemeColorOverride("font_color", AppTheme.TextFaint);
        header.AddChild(countLabel);
        header.GuiInput += e =>
        {
            if (e is not InputEventMouseButton { Pressed: true } mb) return;
            if (mb.ButtonIndex == MouseButton.Right) board.ShowColumnMenu(ColumnId);
            else return;
            header.AcceptEvent();
        };

        // Cards (highest priority first)
        _cards = new VBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill, MouseFilter = MouseFilterEnum.Pass };
        _cards.AddThemeConstantOverride("separation", 8);
        box.AddChild(_cards);

        foreach (var cardId in board.OrderedCards(column))
        {
            if (!ws.Cards.TryGetValue(cardId, out var card)) continue;
            var view = CardView.Create(board, card);
            view.Column = this;
            view.Visible = board.Matches(card);
            _cards.AddChild(view);
            _views.Add(view);
            board.Register(view);
        }

        _dropLine = new ColorRect
        {
            Color = AppTheme.Accent,
            CustomMinimumSize = new Vector2(0, 2),
            Visible = false,
            MouseFilter = MouseFilterEnum.Ignore,
        };
        _cards.AddChild(_dropLine);

        if (_views.Count == 0)
        {
            var empty = new Label { Text = "No tasks", MouseFilter = MouseFilterEnum.Ignore };
            empty.AddThemeFontSizeOverride("font_size", 12);
            empty.AddThemeColorOverride("font_color", AppTheme.TextFaint);
            box.AddChild(empty);
        }
    }

    // Barely-there hover: checked every frame so cards inside don't interrupt it.
    public override void _Process(double delta)
    {
        bool over = IsVisibleInTree() && GetGlobalRect().HasPoint(GetGlobalMousePosition());
        float target = over ? 1f : 0f;
        if (_hover == target) return;
        float dt = (float)delta;
        _hover = target > _hover
            ? Mathf.Min(target, _hover + dt / HoverFade.FadeIn)
            : Mathf.Max(target, _hover - dt / HoverFade.FadeOut);
        _style.BgColor = BaseColor.Lerp(HoverColor, _hover);
    }

    // ------------------------------------------------------------------
    // Drag and drop
    // ------------------------------------------------------------------

    public override bool _CanDropData(Vector2 atPosition, Variant data) => CanDropAt(GetGlobalMousePosition(), data);

    public override void _DropData(Vector2 atPosition, Variant data) => DropAt(GetGlobalMousePosition(), data);

    public bool CanDropAt(Vector2 globalPos, Variant data)
    {
        if (!BoardTab.TryGetDraggedCard(data, out var dragged)) return false;
        _board.SetActiveDropColumn(this);
        PlaceDropLine(dragged, globalPos.Y);
        return true;
    }

    public void DropAt(Vector2 globalPos, Variant data)
    {
        HideDropLine();
        if (!BoardTab.TryGetDraggedCard(data, out var dragged)) return;
        _board.MoveCard(dragged, ColumnId, DropIndex(dragged, globalPos.Y));
    }

    public void HideDropLine()
    {
        if (_dropLine is not null) _dropLine.Visible = false;
    }

    private int DropIndex(CardId dragged, float globalY)
    {
        int index = 0;
        foreach (var view in _views)
        {
            if (view.CardId == dragged) continue;
            if (view.Visible)
            {
                var r = view.GetGlobalRect();
                if (globalY < r.Position.Y + r.Size.Y * 0.5f) break;
            }
            index++;
        }
        return index;
    }

    private void PlaceDropLine(CardId dragged, float globalY)
    {
        CardView? before = null;
        foreach (var view in _views)
        {
            if (view.CardId == dragged || !view.Visible) continue;
            var r = view.GetGlobalRect();
            if (globalY < r.Position.Y + r.Size.Y * 0.5f) { before = view; break; }
        }

        int target = before is null ? _cards.GetChildCount() - 1 : before.GetIndex();
        if (before is not null && _dropLine.GetIndex() < target) target--;
        if (_dropLine.GetIndex() != target) _cards.MoveChild(_dropLine, target);
        _dropLine.Visible = true;
    }

    public override void _Notification(int what)
    {
        if ((long)what == NotificationDragEnd) HideDropLine();
    }
}
