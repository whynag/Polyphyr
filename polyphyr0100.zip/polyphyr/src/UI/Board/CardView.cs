using System.Linq;
using Godot;
using Polyphyr.Core;

namespace Polyphyr.UI.Board;

/// <summary>
/// One card on the board: optional cover image, title, priority, and a dropdown that
/// lists the notes, images and sheets attached to it. Drag it to move it between columns.
/// </summary>
public partial class CardView : PanelContainer
{
    public CardId CardId { get; private set; }
    public BoardColumnView? Column { get; set; }

    private BoardTab _board = null!;
    private Label _title = null!;

    public static CardView Create(BoardTab board, Card card)
    {
        var view = new CardView();
        view.Setup(board, card);
        return view;
    }

    public Rect2 TitleGlobalRect => _title.GetGlobalRect();

    public static Color PriorityColor(Priority p) => BoardVisuals.PriorityColor(p);

    private void Setup(BoardTab board, Card card)
    {
        _board = board;
        CardId = card.Id;
        var ws = board.Ws!;

        MouseFilter = MouseFilterEnum.Stop;
        SizeFlagsHorizontal = SizeFlags.ExpandFill;

        // Completed cards get a soft green tint.
        bool done = ws.GetColumnOf(card.Id) is { } column && BoardVisuals.IsDone(column);
        AddThemeStyleboxOverride("panel", done
            ? AppTheme.Box(BoardVisuals.DoneCardBackground, 8, 0, 0, BoardVisuals.DoneCardBorder, 1)
            : AppTheme.Box(AppTheme.Raised, 8, 0, 0, AppTheme.Border, 1));

        var body = new VBoxContainer { MouseFilter = MouseFilterEnum.Pass };
        body.AddThemeConstantOverride("separation", 0);
        AddChild(body);

        // Cover image (the card's chosen image, also used as the flowchart node background).
        if (card.CoverImage is { } cover && board.Images.Thumbnail(cover) is { } coverTexture)
        {
            var coverRect = new TextureRect
            {
                Texture = coverTexture,
                ExpandMode = TextureRect.ExpandModeEnum.IgnoreSize,
                StretchMode = TextureRect.StretchModeEnum.KeepAspectCovered,
                CustomMinimumSize = new Vector2(0, 120),
                ClipContents = true,
                MouseFilter = MouseFilterEnum.Pass,
            };
            body.AddChild(coverRect);
        }

        var pad = new MarginContainer { MouseFilter = MouseFilterEnum.Pass };
        pad.AddThemeConstantOverride("margin_left", 12);
        pad.AddThemeConstantOverride("margin_right", 10);
        pad.AddThemeConstantOverride("margin_top", 10);
        pad.AddThemeConstantOverride("margin_bottom", 8);
        body.AddChild(pad);

        var inner = new VBoxContainer { MouseFilter = MouseFilterEnum.Pass };
        inner.AddThemeConstantOverride("separation", 6);
        pad.AddChild(inner);

        // Title row
        var titleRow = new HBoxContainer { MouseFilter = MouseFilterEnum.Pass };
        titleRow.AddThemeConstantOverride("separation", 8);
        inner.AddChild(titleRow);
        _title = new Label
        {
            Text = string.IsNullOrWhiteSpace(card.Title) ? "Untitled" : card.Title,
            AutowrapMode = TextServer.AutowrapMode.WordSmart,
            SizeFlagsHorizontal = SizeFlags.ExpandFill,
        };
        _title.AddThemeFontOverride("font", AppFonts.Medium);
        _title.AddThemeColorOverride("font_color", AppTheme.Text);
        titleRow.AddChild(_title);
        board.RegisterBoardTitle(card.Id, _title);

        // Priority, under the name
        if (card.Priority != Priority.None)
        {
            var priorityRow = new HBoxContainer { MouseFilter = MouseFilterEnum.Pass };
            priorityRow.AddThemeConstantOverride("separation", 6);
            priorityRow.AddChild(new PriorityIcon { Priority = card.Priority, SizeFlagsVertical = SizeFlags.ShrinkCenter });
            var priorityName = new Label { Text = BoardVisuals.PriorityName(card.Priority), VerticalAlignment = VerticalAlignment.Center };
            priorityName.AddThemeFontSizeOverride("font_size", 12);
            priorityName.AddThemeColorOverride("font_color", BoardVisuals.PriorityColor(card.Priority));
            priorityRow.AddChild(priorityName);
            inner.AddChild(priorityRow);
        }

        // Due date (attachments live in the list, not on the board)
        if (card.DueDate is { } due)
        {
            var footer = new HBoxContainer { MouseFilter = MouseFilterEnum.Pass };
            footer.AddThemeConstantOverride("separation", 6);
            inner.AddChild(footer);
            var dueLabel = new Label { Text = due.ToString("MMM d"), VerticalAlignment = VerticalAlignment.Center };
            dueLabel.AddThemeFontSizeOverride("font_size", 12);
            dueLabel.AddThemeColorOverride("font_color", AppTheme.TextFaint);
            footer.AddChild(dueLabel);
        }

        HoverFade.Attach(this, 8, 0.025f);
    }

    // ------------------------------------------------------------------
    // Mouse: right-click menu, double-click rename, drag
    // ------------------------------------------------------------------

    public override void _GuiInput(InputEvent @event)
    {
        if (@event is not InputEventMouseButton { Pressed: true } mb) return;
        if (mb.ButtonIndex == MouseButton.Right)
        {
            _board.ShowCardMenu(CardId);
            AcceptEvent();
        }
        else if (mb.ButtonIndex == MouseButton.Left && mb.DoubleClick)
        {
            _board.BeginRenameCard(CardId, inBoard: true);
            AcceptEvent();
        }
    }

    public override Variant _GetDragData(Vector2 atPosition)
    {
        // Preview: a translucent copy of the card's title box that follows the mouse.
        var holder = new Control();
        var ghost = new PanelContainer { Size = new Vector2(Size.X, 0), Position = -atPosition };
        ghost.AddThemeStyleboxOverride("panel", AppTheme.Box(AppTheme.Hover, 8, 12, 10, AppTheme.Accent, 1));
        var text = new Label
        {
            Text = _title.Text,
            AutowrapMode = TextServer.AutowrapMode.WordSmart,
            CustomMinimumSize = new Vector2(Size.X - 24, 0),
        };
        text.AddThemeFontOverride("font", AppFonts.Medium);
        ghost.AddChild(text);
        holder.AddChild(ghost);
        holder.Modulate = new Color(1, 1, 1, 0.9f);
        SetDragPreview(holder);

        Modulate = new Color(1, 1, 1, 0.35f);
        return BoardTab.DragData(CardId);
    }

    // The card stops mouse events, so drops over it are forwarded to its column.
    public override bool _CanDropData(Vector2 atPosition, Variant data)
        => Column?.CanDropAt(GetGlobalMousePosition(), data) ?? false;

    public override void _DropData(Vector2 atPosition, Variant data)
        => Column?.DropAt(GetGlobalMousePosition(), data);

    public override void _Notification(int what)
    {
        if ((long)what == NotificationDragEnd) Modulate = Colors.White;
    }
}

/// <summary>Small colored dot showing a card's priority.</summary>
public partial class PriorityDot : Control
{
    public Color DotColor { get; set; } = AppTheme.TextFaint;

    public PriorityDot()
    {
        CustomMinimumSize = new Vector2(8, 20);
        MouseFilter = MouseFilterEnum.Pass;
    }

    public override void _Draw() => DrawCircle(new Vector2(4, 10), 4f, DotColor);
}

/// <summary>Round avatar with a person's initials in their color.</summary>
public partial class Avatar : Control
{
    public User? User { get; set; }

    public Avatar()
    {
        CustomMinimumSize = new Vector2(22, 22);
        MouseFilter = MouseFilterEnum.Pass;
    }

    public override void _Draw()
    {
        if (User is null) return;
        var color = new Color(User.Color);
        DrawCircle(new Vector2(11, 11), 11f, new Color(color, 0.35f));
        DrawArc(new Vector2(11, 11), 10.5f, 0, Mathf.Tau, 32, new Color(color, 0.8f), 1f, true);

        var parts = User.DisplayName.Split(' ', System.StringSplitOptions.RemoveEmptyEntries);
        string initials = parts.Length switch
        {
            0 => "?",
            1 => parts[0].Substring(0, 1).ToUpperInvariant(),
            _ => (parts[0].Substring(0, 1) + parts[^1].Substring(0, 1)).ToUpperInvariant(),
        };
        var font = AppFonts.SemiBold;
        const int size = 10;
        float ascent = font.GetAscent(size);
        float textHeight = font.GetHeight(size);
        DrawString(font, new Vector2(0, 11 - textHeight / 2 + ascent), initials, HorizontalAlignment.Center, 22, size, AppTheme.Text);
    }
}
