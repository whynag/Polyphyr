using System.Collections.Generic;
using System.Linq;
using Godot;
using Polyphyr.Core;

namespace Polyphyr.UI.Board;

/// <summary>
/// List of tasks: select box, summary, priority, status and due date.
/// Expanding a task shows its attached notes, images and sheets as child rows.
///
/// Rows track hover themselves (so the highlight stays on while over any part of the row),
/// and every interactive cell fills the full row height.
/// </summary>
public partial class TaskListView : VBoxContainer
{
    // Compact so the list fits beside the board.
    public const float SelectW = 38, PriorityW = 108, StatusW = 136, DueW = 116;
    public const float RowHeight = 40;
    private const float ChildIndent = 26;

    private static readonly Color SelectedBg = new(0.44f, 0.56f, 1f, 0.09f);
    private static readonly Color Clear = new(0, 0, 0, 0);

    private sealed class RowEntry
    {
        public PanelContainer Row = null!;
        public StyleBoxFlat Style = null!;
        public HoverOverlay Hover = null!;
        public CardId? Card;
        public CheckBox? Check;
        public bool Done;
    }

    private BoardTab _board = null!;
    private ScrollContainer _scroll = null!;
    private VBoxContainer _rows = null!;
    private CheckBox _selectAll = null!;
    private bool _updatingSelectAll;
    private readonly List<CardId> _visibleCards = new();
    private readonly List<RowEntry> _entries = new();
    private RowEntry? _hovered;

    // Drag-select on the checkboxes: press one and drag across others.
    private bool _dragSelecting;
    private bool _dragTarget;

    public int ScrollV
    {
        get => _scroll.ScrollVertical;
        set => _scroll.ScrollVertical = value;
    }

    public override void _Ready()
    {
        AddThemeConstantOverride("separation", 0);

        // ---- Header ----
        var header = new PanelContainer { CustomMinimumSize = new Vector2(0, 36) };
        header.AddThemeStyleboxOverride("panel", RowStyle(Clear));
        AddChild(header);
        var headerRow = new HBoxContainer();
        headerRow.AddThemeConstantOverride("separation", 0);
        header.AddChild(headerRow);

        _selectAll = new CheckBox { FocusMode = FocusModeEnum.None, TooltipText = "Select all" };
        _selectAll.Toggled += on =>
        {
            if (_updatingSelectAll) return;
            _board.SetAllSelected(_visibleCards, on);
        };
        headerRow.AddChild(Cell(SelectW, _selectAll, center: true, divider: false, pad: false));
        headerRow.AddChild(Cell(0, HeaderLabel("Task"), expand: true));
        headerRow.AddChild(Cell(PriorityW, HeaderLabel("Priority")));
        headerRow.AddChild(Cell(StatusW, HeaderLabel("Status")));
        headerRow.AddChild(Cell(DueW, HeaderLabel("Due date")));

        // ---- Rows ----
        _scroll = new ScrollContainer
        {
            SizeFlagsVertical = SizeFlags.ExpandFill,
            HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled,
        };
        AddChild(_scroll);
        SmoothScroller.Attach(_scroll);
        _rows = new VBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill };
        _rows.AddThemeConstantOverride("separation", 0);
        _scroll.AddChild(_rows);
    }

    public void Build(BoardTab board)
    {
        _board = board;
        foreach (var child in _rows.GetChildren())
        {
            _rows.RemoveChild(child);
            child.QueueFree();
        }
        _visibleCards.Clear();
        _entries.Clear();
        _hovered = null;

        var ws = board.Ws;
        if (ws is null) return;

        foreach (var column in ws.Board.Columns)
        {
            // Grouped by status (column order), highest priority first within each.
            foreach (var cardId in board.OrderedCards(column))
            {
                if (!ws.Cards.TryGetValue(cardId, out var card) || !board.Matches(card)) continue;
                _visibleCards.Add(cardId);
                _rows.AddChild(TaskRow(card, column, ws));

                if (!board.IsExpanded(cardId)) continue;
                foreach (var a in card.Attachments)
                    if (ws.AttachmentExists(a)) _rows.AddChild(AttachmentRow(card, a, ws));
                _rows.AddChild(AddAttachmentRow(card));
            }
        }

        _rows.AddChild(CreateRow());
        RefreshSelection();
    }

    /// <summary>Updates checkboxes and row highlights in place (no rebuild), e.g. while drag-selecting.</summary>
    public void RefreshSelection()
    {
        foreach (var e in _entries)
        {
            if (e.Card is not { } id) continue;
            bool selected = _board.IsSelected(id);
            e.Style.BgColor = selected ? SelectedBg : e.Done ? BoardVisuals.DoneRowBackground : Clear;
            e.Check?.SetPressedNoSignal(selected);
        }
        _updatingSelectAll = true;
        _selectAll.ButtonPressed = _visibleCards.Count > 0 && _visibleCards.All(_board.IsSelected);
        _updatingSelectAll = false;
    }

    // ------------------------------------------------------------------
    // Hover: tracked per frame so children never "steal" the row's hover state
    // ------------------------------------------------------------------

    public override void _Process(double delta)
    {
        RowEntry? over = null;
        if (IsVisibleInTree() && _entries.Count > 0)
        {
            var mouse = GetGlobalMousePosition();
            if (_scroll.GetGlobalRect().HasPoint(mouse))
            {
                foreach (var e in _entries)
                {
                    if (!e.Row.GetGlobalRect().HasPoint(mouse)) continue;
                    over = e;
                    break;
                }
            }
        }
        if (over == _hovered) return;
        _hovered?.Hover.FadeTo(0f, HoverFade.FadeOut);
        over?.Hover.FadeTo(1f, HoverFade.FadeIn);
        _hovered = over;
    }

    // ------------------------------------------------------------------
    // Drag-select
    // ------------------------------------------------------------------

    private void OnSelectCellInput(InputEvent e, CardId id, Control cell)
    {
        switch (e)
        {
            case InputEventMouseButton { ButtonIndex: MouseButton.Left, Pressed: true }:
                _dragSelecting = true;
                _dragTarget = !_board.IsSelected(id);
                _board.SetSelected(id, _dragTarget);
                cell.AcceptEvent();
                break;
            case InputEventMouseButton { ButtonIndex: MouseButton.Left, Pressed: false }:
                _dragSelecting = false;
                cell.AcceptEvent();
                break;
            case InputEventMouseMotion when _dragSelecting:
                // While the button is held, motion keeps coming to the cell that was pressed.
                float y = GetGlobalMousePosition().Y;
                foreach (var entry in _entries)
                {
                    if (entry.Card is not { } other) continue;
                    var r = entry.Row.GetGlobalRect();
                    if (y < r.Position.Y || y >= r.End.Y) continue;
                    if (_board.IsSelected(other) != _dragTarget) _board.SetSelected(other, _dragTarget);
                    break;
                }
                cell.AcceptEvent();
                break;
        }
    }

    // ------------------------------------------------------------------
    // Rows
    // ------------------------------------------------------------------

    private Control TaskRow(Card card, BoardColumn column, Workspace ws)
    {
        var entry = NewRow(Clear);
        entry.Card = card.Id;
        entry.Done = BoardVisuals.IsDone(column);
        var cells = (HBoxContainer)entry.Row.GetChild(0);
        var id = card.Id;

        // Select (press and drag to select several)
        var check = new CheckBox { FocusMode = FocusModeEnum.None, MouseFilter = MouseFilterEnum.Ignore };
        HoverFade.OptOut(check);
        entry.Check = check;
        var selectCell = Cell(SelectW, check, center: true, divider: false, pad: false);
        selectCell.MouseFilter = MouseFilterEnum.Stop;
        selectCell.MouseDefaultCursorShape = CursorShape.PointingHand;
        selectCell.GuiInput += e => OnSelectCellInput(e, id, selectCell);
        cells.AddChild(selectCell);

        // Task: expand arrow + summary
        var work = new HBoxContainer { MouseFilter = MouseFilterEnum.Pass };
        work.AddThemeConstantOverride("separation", 8);
        int attachments = card.Attachments.Count(ws.AttachmentExists);
        if (attachments > 0 || _board.IsExpanded(id))
        {
            var chevron = new Chevron { Expanded = _board.IsExpanded(id), SizeFlagsVertical = SizeFlags.ShrinkCenter };
            chevron.Toggled += () => _board.ToggleExpanded(id);
            work.AddChild(chevron);
        }
        else
        {
            work.AddChild(new Control { CustomMinimumSize = new Vector2(18, 0), MouseFilter = MouseFilterEnum.Ignore });
        }

        var summary = new Label
        {
            Text = string.IsNullOrWhiteSpace(card.Title) ? "Untitled" : card.Title,
            SizeFlagsHorizontal = SizeFlags.ExpandFill,
            SizeFlagsVertical = SizeFlags.Fill,
            VerticalAlignment = VerticalAlignment.Center,
            TextOverrunBehavior = TextServer.OverrunBehavior.TrimEllipsis,
            MouseFilter = MouseFilterEnum.Pass,
            TooltipText = "Double-click to rename",
        };
        summary.AddThemeColorOverride("font_color", BoardVisuals.IsDone(column) ? AppTheme.TextDim : AppTheme.Text);
        summary.GuiInput += e =>
        {
            if (e is not InputEventMouseButton { Pressed: true, ButtonIndex: MouseButton.Left, DoubleClick: true }) return;
            _board.BeginRenameCard(id);
            summary.AcceptEvent();
        };
        work.AddChild(summary);
        if (attachments > 0)
        {
            var count = new Label { Text = attachments.ToString(), VerticalAlignment = VerticalAlignment.Center, MouseFilter = MouseFilterEnum.Ignore };
            count.AddThemeColorOverride("font_color", AppTheme.TextFaint);
            count.AddThemeFontSizeOverride("font_size", 12);
            work.AddChild(count);
        }
        _board.RegisterTitle(id, summary);
        cells.AddChild(Cell(0, work, expand: true, fill: true));

        // Priority
        var priority = CellButton(() => _board.ShowPriorityPicker(id));
        var pBox = Inline(priority);
        pBox.AddChild(new PriorityIcon { Priority = card.Priority, SizeFlagsVertical = SizeFlags.ShrinkCenter });
        pBox.AddChild(InlineLabel(BoardVisuals.PriorityName(card.Priority),
            card.Priority == Priority.None ? AppTheme.TextFaint : AppTheme.Text));
        cells.AddChild(Cell(PriorityW, priority, fill: true));

        // Status: the whole cell is the click target; the pill is just the look.
        var status = CellButton(() => _board.ShowStatusMenu(id));
        var sBox = Inline(status);
        sBox.AddChild(StatusPill(column));
        cells.AddChild(Cell(StatusW, status, fill: true));

        // Due date
        var due = CellButton(null);
        due.Pressed += () => _board.ShowDueEditor(id, due.GetGlobalRect());
        var dBox = Inline(due);
        dBox.AddChild(card.DueDate is { } d
            ? InlineLabel(d.ToString("MMM d, yyyy"), AppTheme.Text)
            : InlineLabel("None", AppTheme.TextFaint));
        cells.AddChild(Cell(DueW, due, fill: true));

        // Right-click anywhere on the row: task menu.
        entry.Row.GuiInput += e =>
        {
            if (e is not InputEventMouseButton { Pressed: true, ButtonIndex: MouseButton.Right }) return;
            _board.ShowCardMenu(id);
            entry.Row.AcceptEvent();
        };
        return entry.Row;
    }

    private Control AttachmentRow(Card card, Attachment a, Workspace ws)
    {
        var entry = NewRow(Clear);
        var cells = (HBoxContainer)entry.Row.GetChild(0);
        var cardId = card.Id;

        cells.AddChild(Cell(SelectW, null, divider: false, pad: false));

        var work = new HBoxContainer { MouseFilter = MouseFilterEnum.Pass };
        work.AddThemeConstantOverride("separation", 8);
        work.AddChild(new Control { CustomMinimumSize = new Vector2(18 + ChildIndent, 0), MouseFilter = MouseFilterEnum.Ignore });
        work.AddChild(new KindIcon { Kind = KindIcon.FromAttachment(a.Kind), SizeFlagsVertical = SizeFlags.ShrinkCenter });

        string name = a.Kind switch
        {
            AttachmentKind.Note => ws.Notes[NoteId.From(a.TargetId)].Title,
            AttachmentKind.Sheet => ws.Sheets[SheetId.From(a.TargetId)].Title,
            _ => ws.Images[ImageId.From(a.TargetId)].OriginalName,
        };
        if (a.Kind == AttachmentKind.Image && card.CoverImage == ImageId.From(a.TargetId)) name += "   · cover";

        var link = new Button
        {
            Text = string.IsNullOrWhiteSpace(name) ? "Untitled" : name,
            Flat = true,
            FocusMode = FocusModeEnum.None,
            Alignment = HorizontalAlignment.Left,
            SizeFlagsHorizontal = SizeFlags.ExpandFill,
            SizeFlagsVertical = SizeFlags.Fill,
            TextOverrunBehavior = TextServer.OverrunBehavior.TrimEllipsis,
            MouseDefaultCursorShape = CursorShape.PointingHand,
            MouseFilter = MouseFilterEnum.Pass,
        };
        HoverFade.OptOut(link);
        link.AddThemeColorOverride("font_color", AppTheme.TextDim);
        link.AddThemeColorOverride("font_hover_color", AppTheme.Text);
        link.AddThemeColorOverride("font_pressed_color", AppTheme.Text);
        foreach (var state in new[] { "normal", "hover", "pressed" })
            link.AddThemeStyleboxOverride(state, AppTheme.Empty(0, 2));
        link.Pressed += () => _board.OpenAttachment(a);
        work.AddChild(link);
        cells.AddChild(Cell(0, work, expand: true, fill: true));

        cells.AddChild(Cell(PriorityW, null));
        cells.AddChild(Cell(StatusW, null));
        cells.AddChild(Cell(DueW, null));

        entry.Row.GuiInput += e =>
        {
            if (e is not InputEventMouseButton { Pressed: true, ButtonIndex: MouseButton.Right }) return;
            _board.ShowAttachmentMenu(cardId, a);
            entry.Row.AcceptEvent();
        };
        return entry.Row;
    }

    private Control AddAttachmentRow(Card card)
    {
        var entry = NewRow(Clear, height: 34);
        var cells = (HBoxContainer)entry.Row.GetChild(0);
        var id = card.Id;
        cells.AddChild(Cell(SelectW, null, divider: false, pad: false));
        var work = new HBoxContainer { MouseFilter = MouseFilterEnum.Pass };
        work.AddChild(new Control { CustomMinimumSize = new Vector2(18 + ChildIndent, 0), MouseFilter = MouseFilterEnum.Ignore });
        var add = SmallFlat("+  Attach document, image or sheet");
        add.Pressed += () => _board.ShowAttachMenu(id);
        work.AddChild(add);
        cells.AddChild(Cell(0, work, expand: true));
        return entry.Row;
    }

    /// <summary>
    /// "+ Create" at the bottom. Opens a row with the title, a priority choice, and options to attach
    /// a new note, a new sheet or an image. Enter adds the task and keeps the row open for the next one.
    /// </summary>
    private Control CreateRow()
    {
        var draft = _board.Draft;
        var entry = NewRow(Clear, height: draft.Open ? 48 : RowHeight);
        var cells = (HBoxContainer)entry.Row.GetChild(0);
        cells.AddChild(Cell(SelectW, null, divider: false, pad: false));

        if (!draft.Open)
        {
            // Same structure as a task row's name cell, so "+ Create" lines up with the task names.
            var line = new HBoxContainer { MouseFilter = MouseFilterEnum.Pass };
            line.AddChild(new Control { CustomMinimumSize = new Vector2(18, 0), MouseFilter = MouseFilterEnum.Ignore });
            var create = SmallFlat("+  Create");
            create.AddThemeFontSizeOverride("font_size", 14);
            create.SizeFlagsVertical = SizeFlags.ShrinkCenter;
            create.Pressed += () =>
            {
                draft.Open = true;
                _board.RequestRebuild();
            };
            line.AddChild(create);
            cells.AddChild(Cell(0, line, expand: true, fill: true));
            return entry.Row;
        }

        var bar = new HBoxContainer { MouseFilter = MouseFilterEnum.Pass };
        bar.AddThemeConstantOverride("separation", 8);

        var title = new LineEdit
        {
            PlaceholderText = "What needs to be done?",
            Text = draft.Title,
            SizeFlagsHorizontal = SizeFlags.ExpandFill,
        };
        title.TextChanged += t => draft.Title = t;
        title.TextSubmitted += _ => _board.CreateFromDraft();
        title.GuiInput += e =>
        {
            if (!e.IsActionPressed("ui_cancel")) return;
            _board.CloseDraft();
            title.AcceptEvent();
        };
        bar.AddChild(title);

        // Priority choice
        var priority = new MenuButton
        {
            Text = (draft.Priority == Priority.None ? "No priority" : BoardVisuals.PriorityName(draft.Priority)) + "  ▾",
            Flat = false,
            FocusMode = FocusModeEnum.None,
        };
        var pMenu = priority.GetPopup();
        foreach (var p in BoardVisuals.PriorityOrder) pMenu.AddItem(BoardVisuals.PriorityName(p), (int)p);
        pMenu.AddSeparator();
        pMenu.AddItem("No priority", (int)Priority.None);
        pMenu.IdPressed += pid =>
        {
            draft.Priority = (Priority)(int)pid;
            priority.Text = (draft.Priority == Priority.None ? "No priority" : BoardVisuals.PriorityName(draft.Priority)) + "  ▾";
        };
        bar.AddChild(priority);

        // Attachments for the new task: icon buttons for a new note, a new sheet, and an image file.
        bar.AddChild(DraftPicker(KindIcon.KindType.Note, "document", _board.DraftNoteName, () => _board.ShowDraftPicker(sheet: false)));
        bar.AddChild(DraftPicker(KindIcon.KindType.Sheet, "sheet", _board.DraftSheetName, () => _board.ShowDraftPicker(sheet: true)));
        var image = IconButton(KindIcon.KindType.ImageAdd, draft.ImagePath is { } path
            ? "Image: " + System.IO.Path.GetFileName(path) + "\nClick to choose a different one"
            : "Attach an image file");
        if (draft.ImagePath is not null) SetIconButtonOn(image, true);
        image.Pressed += () => _board.PickDraftImage();
        bar.AddChild(image);

        var add = new Button { Text = "Create", FocusMode = FocusModeEnum.None };
        add.AddThemeStyleboxOverride("normal", AppTheme.Box(AppTheme.PrimaryBg, AppTheme.Radius, 14, 6, AppTheme.PrimaryBorder, 1));
        add.Pressed += () => _board.CreateFromDraft();
        bar.AddChild(add);

        var cancel = new Button { Text = "Cancel", Flat = true, FocusMode = FocusModeEnum.None };
        cancel.Pressed += () => _board.CloseDraft();
        bar.AddChild(cancel);

        var cell = Cell(0, bar, expand: true);
        cells.AddChild(cell);
        Callable.From(() =>
        {
            if (!IsInstanceValid(title)) return;
            title.GrabFocus();
            title.CaretColumn = title.Text.Length;
        }).CallDeferred();
        return entry.Row;
    }

    private static Color IconOff => AppTheme.TextDim;
    private static Color IconOn => AppTheme.PrimaryIcon;

    /// <summary>A square button showing only an icon (note, sheet, image).</summary>
    private static Button IconButton(KindIcon.KindType kind, string tooltip)
    {
        var b = new Button
        {
            FocusMode = FocusModeEnum.None,
            CustomMinimumSize = new Vector2(34, 32),
            TooltipText = tooltip,
            MouseDefaultCursorShape = CursorShape.PointingHand,
        };
        var icon = new KindIcon { Kind = kind, Tint = IconOff, MouseFilter = MouseFilterEnum.Ignore };
        b.AddChild(icon);
        icon.SetAnchorsAndOffsetsPreset(LayoutPreset.FullRect);
        return b;
    }

    private static void SetIconButtonOn(Button b, bool on)
    {
        var style = on
            ? AppTheme.Box(AppTheme.PrimaryBg, AppTheme.Radius, 0, 0, AppTheme.PrimaryBorder, 1)
            : AppTheme.Box(AppTheme.Raised, AppTheme.Radius, 0, 0, AppTheme.Border, 1);
        b.AddThemeStyleboxOverride("normal", style);
        b.AddThemeStyleboxOverride("hover", style);
        b.AddThemeStyleboxOverride("pressed", style);
        b.AddThemeStyleboxOverride("hover_pressed", style);
        foreach (var child in b.GetChildren())
            if (child is KindIcon icon)
            {
                icon.Tint = on ? IconOn : IconOff;
                icon.QueueRedraw();
            }
    }

    /// <summary>Icon button that opens the document / sheet dropdown; lit when one is chosen.</summary>
    private static Button DraftPicker(KindIcon.KindType kind, string noun, string? chosen, System.Action open)
    {
        var b = IconButton(kind, chosen is null ? $"Attach a {noun}" : $"{char.ToUpper(noun[0]) + noun[1..]}: {chosen}\nClick to change");
        SetIconButtonOn(b, chosen is not null);
        b.Pressed += open;
        return b;
    }

    // ------------------------------------------------------------------
    // Building blocks
    // ------------------------------------------------------------------

    private static StyleBoxFlat RowStyle(Color background)
    {
        var sb = AppTheme.Box(background, 0);
        sb.BorderColor = AppTheme.Border;
        sb.BorderWidthBottom = 1;
        return sb;
    }

    private RowEntry NewRow(Color background, float height = RowHeight)
    {
        var style = RowStyle(background);
        var row = new PanelContainer { CustomMinimumSize = new Vector2(0, height), MouseFilter = MouseFilterEnum.Stop };
        row.AddThemeStyleboxOverride("panel", style);
        var cells = new HBoxContainer { MouseFilter = MouseFilterEnum.Pass };
        cells.AddThemeConstantOverride("separation", 0);
        row.AddChild(cells);

        var hover = new HoverOverlay(0, 0.03f);
        row.AddChild(hover, false, InternalMode.Front);
        hover.SetAnchorsAndOffsetsPreset(LayoutPreset.FullRect);

        var entry = new RowEntry { Row = row, Style = style, Hover = hover };
        _entries.Add(entry);
        return entry;
    }

    /// <summary>A table cell with a fixed width (or expanding), a thin divider on its left, and padding.</summary>
    private static PanelContainer Cell(float width, Control? content, bool expand = false, bool center = false, bool divider = true, bool fill = false, bool pad = true)
    {
        var cell = new PanelContainer
        {
            CustomMinimumSize = new Vector2(width, 0),
            SizeFlagsHorizontal = expand ? SizeFlags.ExpandFill : SizeFlags.Fill,
            MouseFilter = MouseFilterEnum.Pass,
        };
        var style = AppTheme.Box(Clear, 0, fill || !pad ? 0 : 10, 0);
        if (divider)
        {
            style.BorderColor = AppTheme.Border;
            style.BorderWidthLeft = 1;
        }
        cell.AddThemeStyleboxOverride("panel", style);
        if (content is not null)
        {
            if (center) content.SizeFlagsHorizontal = SizeFlags.ShrinkCenter;
            content.SizeFlagsVertical = fill ? SizeFlags.Fill : SizeFlags.ShrinkCenter;
            if (fill && content is HBoxContainer box) box.AddThemeConstantOverride("separation", 8);
            if (fill && content is not Button)
            {
                // Pad text content, but let buttons reach the cell edges so the whole cell is clickable.
                var padding = new MarginContainer { MouseFilter = MouseFilterEnum.Pass };
                padding.AddThemeConstantOverride("margin_left", 10);
                padding.AddThemeConstantOverride("margin_right", 6);
                padding.AddChild(content);
                cell.AddChild(padding);
                return cell;
            }
            cell.AddChild(content);
        }
        return cell;
    }

    private static Label HeaderLabel(string text)
    {
        var label = new Label { Text = text, VerticalAlignment = VerticalAlignment.Center };
        label.AddThemeFontOverride("font", AppFonts.SemiBold);
        label.AddThemeFontSizeOverride("font_size", 12);
        label.AddThemeColorOverride("font_color", AppTheme.TextDim);
        return label;
    }

    /// <summary>A flat button filling its whole cell; its content goes in the HBox returned by <see cref="Inline"/>.</summary>
    private static Button CellButton(System.Action? onPressed)
    {
        var b = new Button
        {
            Flat = false,
            FocusMode = FocusModeEnum.None,
            SizeFlagsHorizontal = SizeFlags.ExpandFill,
            SizeFlagsVertical = SizeFlags.ExpandFill,
            MouseDefaultCursorShape = CursorShape.PointingHand,
            MouseFilter = MouseFilterEnum.Pass,
        };
        HoverFade.OptOut(b);
        b.AddThemeStyleboxOverride("normal", AppTheme.Box(Clear, 0));
        b.AddThemeStyleboxOverride("hover", AppTheme.Box(new Color(AppTheme.Overlay, 0.035f), 0));
        b.AddThemeStyleboxOverride("pressed", AppTheme.Box(new Color(AppTheme.Overlay, 0.07f), 0));
        b.AddThemeStyleboxOverride("focus", AppTheme.Empty());
        if (onPressed is not null) b.Pressed += onPressed;
        return b;
    }

    private static HBoxContainer Inline(Button host)
    {
        var box = new HBoxContainer { MouseFilter = MouseFilterEnum.Ignore };
        box.AddThemeConstantOverride("separation", 8);
        host.AddChild(box);
        box.SetAnchorsAndOffsetsPreset(LayoutPreset.FullRect);
        box.OffsetLeft = 10;
        box.OffsetRight = -6;
        return box;
    }

    private static Label InlineLabel(string text, Color color)
    {
        var label = new Label
        {
            Text = text,
            VerticalAlignment = VerticalAlignment.Center,
            SizeFlagsVertical = SizeFlags.Fill,
            MouseFilter = MouseFilterEnum.Ignore,
            TextOverrunBehavior = TextServer.OverrunBehavior.TrimEllipsis,
            SizeFlagsHorizontal = SizeFlags.ExpandFill,
        };
        label.AddThemeColorOverride("font_color", color);
        return label;
    }

    /// <summary>The colored status pill. Purely visual; its cell handles the click.</summary>
    private static Control StatusPill(BoardColumn column)
    {
        var (bg, border, text) = BoardVisuals.StatusColors(BoardVisuals.ToneOf(column));
        var pill = new PanelContainer
        {
            MouseFilter = MouseFilterEnum.Ignore,
            SizeFlagsVertical = SizeFlags.ShrinkCenter,
            SizeFlagsHorizontal = SizeFlags.ShrinkBegin,
        };
        pill.AddThemeStyleboxOverride("panel", AppTheme.Box(bg, 4, 8, 2, border, 1));
        var label = new Label { Text = column.Name + "  ▾", MouseFilter = MouseFilterEnum.Ignore };
        label.AddThemeFontOverride("font", AppFonts.Medium);
        label.AddThemeFontSizeOverride("font_size", 12);
        label.AddThemeColorOverride("font_color", text);
        pill.AddChild(label);
        return pill;
    }

    private static Button SmallFlat(string text)
    {
        var b = new Button { Text = text, Flat = true, FocusMode = FocusModeEnum.None, Alignment = HorizontalAlignment.Left, MouseFilter = MouseFilterEnum.Pass };
        // No inner padding, so the text starts exactly where the cell's content does.
        foreach (var state in new[] { "normal", "hover", "pressed", "focus" })
            b.AddThemeStyleboxOverride(state, AppTheme.Empty(0, 4));
        b.AddThemeFontSizeOverride("font_size", 13);
        b.AddThemeColorOverride("font_color", AppTheme.TextFaint);
        b.AddThemeColorOverride("font_hover_color", AppTheme.Text);
        return b;
    }
}
