using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Godot;
using Polyphyr.Core;
using Polyphyr.Core.Storage;
using Polyphyr.UI.Board;

namespace Polyphyr.UI;

/// <summary>
/// Root of the app: top bar, the four tabs, opening workspaces, and autosave.
/// </summary>
public partial class MainWindow : Control
{
    private const string WelcomeText =
        "# Welcome to Polyphyr\n" +
        "Your tasks, documents and sheets, together in one place. Everything saves as you go.\n" +
        "This is a document too, so edit it or delete it whenever you like.\n" +
        "## Finding your way\n" +
        "- *Home* shows your top tasks and the documents you used last\n" +
        "- *Tasks* has the board on the left and the list on the right; add new tasks from the list\n" +
        "- *Documents* is where you write; right-click one to rename or delete it\n" +
        "- Set your name with the pencil next to the greeting on Home\n" +
        "## Writing\n" +
        "Click any line to see its raw text; the rest stays formatted.\n" +
        "- *bold*, //italic//, _underline_, --strikethrough-- and `code`\n" +
        "- Start a line with # for a heading, or ## and ### for smaller ones\n" +
        "- Start a line with a dash and a space for a bullet; Tab indents it\n" +
        "= Start a line with = and a space for a checkbox\n" +
        "=x Click the box, or press Ctrl+Enter, to tick it\n" +
        "Put a backslash before a marker to keep it as plain text: \\*not bold\\*.\n" +
        "## One more thing\n" +
        "The button in the bottom-right corner switches between preview and raw text.";

    /// <summary>The first version of the welcome document; replaced if it was never edited.</summary>
    private const string OldWelcomeText =
        "# Welcome to Polyphyr\n" +
        "Click any line to see its raw text. Everything else stays formatted.\n" +
        "## Text styles\n" +
        "*bold*, //italic//, _underline_, --strikethrough-- and `code`.\n" +
        "Put a backslash before a marker to keep it literal: \\*not bold\\*.\n" +
        "Links like https://example.com and words like snake_case are left alone.\n" +
        "## Lists\n" +
        "- Bullet points start with a dash and a space\n" +
        "  - Tab indents a list item, Shift+Tab outdents it\n" +
        "= Checkboxes start with an equals sign\n" +
        "=x Click the box, or press Ctrl+Enter, to tick it\n" +
        "### Small heading\n" +
        "Use the button in the bottom-right corner to switch between live preview and source.";

    private AppSettings _settings = null!;
    private Workspace? _ws;
    private IWorkspaceStore? _store;

    private Label _workspaceLabel = null!;
    private Label _status = null!;
    private TabContainer _tabs = null!;
    private NotesTab _notes = null!;
    private HomeTab _home = null!;
    private BoardTab _board = null!;
    private SheetsTab _sheets = null!;
    private Polyphyr.UI.Flow.FlowchartTab _flow = null!;
    private Timer _autosave = null!;
    private Button _workspacesButton = null!;
    private ThemeToggle _themeToggle = null!;
    private Control _tabsHost = null!;

    // Survive the scene reload that switching light/dark mode does.
    private static bool _windowReady;
    private static int _restoreTab = -1;
    private WorkspaceScreen _workspaceScreen = null!;

    public override void _Ready()
    {
        GetTree().AutoAcceptQuit = false;
        _settings = AppSettings.Load();

        // One theme on the root window styles everything, including popups and dialogs.
        AppTheme.ApplyMode(_settings.LightMode);
        RenderingServer.SetDefaultClearColor(AppTheme.Bg);
        GetTree().Root.Theme = AppTheme.Build();
        HoverFade.Install(GetTree());
        PopupStyle.Install(GetTree());
        TextFieldMenu.Install(GetTree());
        if (!_windowReady)
        {
            SetupWindow();
            _windowReady = true;
        }

        BuildUi();
        // Start in the most recent workspace (and back on the workspace menu if that's where you left).
        OpenWorkspace(_settings.WorkspacePath);
        if (_settings.ShowWorkspaceMenu) Callable.From(ShowWorkspaceMenu).CallDeferred();
        if (_restoreTab >= 0)
        {
            _tabs.CurrentTab = Math.Clamp(_restoreTab, 0, _tabs.GetTabCount() - 1);
            _restoreTab = -1;
        }

        _autosave = new Timer { WaitTime = 1.5, OneShot = false, Autostart = true };
        _autosave.Timeout += () =>
        {
            SaveNow(flushEditors: false);
            _settings.SaveActivityIfChanged();
        };
        AddChild(_autosave);
    }

    public override void _Notification(int what)
    {
        if ((long)what == NotificationWMCloseRequest)
        {
            SaveNow(flushEditors: true);
            RememberWindow();
            _settings.Save();
            GetTree().Quit();
        }
    }

    // ------------------------------------------------------------------
    // Window
    // ------------------------------------------------------------------

    /// <summary>
    /// Opens windowed, sized to the monitor (or where it was last time). The UI is never stretched:
    /// a bigger window shows more content, and buttons and text keep the same pixel size.
    /// </summary>
    private void SetupWindow()
    {
        var win = GetWindow();
        win.ContentScaleMode = Window.ContentScaleModeEnum.Disabled;
        win.ContentScaleFactor = 1f;
        bool embedded = IsEmbeddedInEditor;

        int screen = win.CurrentScreen;
        var usable = DisplayServer.ScreenGetUsableRect(screen);
        if (usable.Size.X <= 0 || usable.Size.Y <= 0)
            usable = new Rect2I(Vector2I.Zero, DisplayServer.ScreenGetSize(screen));
        var target = new Vector2I((int)(usable.Size.X * 0.85f), (int)(usable.Size.Y * 0.85f));
        target = new Vector2I(Math.Max(target.X, 960), Math.Max(target.Y, 600));

        GD.Print($"[window] screen {screen} usable {usable.Size.X}x{usable.Size.Y}, " +
                 $"target {target.X}x{target.Y}, embedded={embedded}, saved={_settings.HasWindowState}");

        if (embedded)
        {
            // In the editor's Game tab the editor owns the size; the project's window mode
            // (Maximized) is what makes it fill the available space there.
            return;
        }

        win.MinSize = new Vector2I(960, 600);

        var saved = new Rect2I(_settings.WindowPosition, _settings.WindowSize);
        if (_settings.HasWindowState && IsOnSomeScreen(saved))
        {
            // Restore the windowed size first, so un-maximizing later returns to it.
            win.Mode = Window.ModeEnum.Windowed;
            win.Size = saved.Size;
            win.Position = saved.Position;
            if (_settings.WindowMaximized) win.Mode = Window.ModeEnum.Maximized;
            LogActualWindow(win);
            return;
        }

        // First run: open maximized (windowed, with a title bar) so it fills the monitor.
        // Un-maximizing drops to 85% of the screen, centered.
        win.Mode = Window.ModeEnum.Windowed;
        win.Size = target;
        win.Position = usable.Position + (usable.Size - target) / 2;
        win.Mode = Window.ModeEnum.Maximized;
        LogActualWindow(win);
    }

    /// <summary>Logs the size the window actually ended up at, once the window manager has applied it.</summary>
    private void LogActualWindow(Window win)
    {
        GetTree().CreateTimer(0.75).Timeout += () =>
            GD.Print($"[window] actual {win.Size.X}x{win.Size.Y} at {win.Position.X},{win.Position.Y}, mode {win.Mode}");
    }

    /// <summary>True when running inside the Godot editor's Game tab ("Embed game on next play").</summary>
    private static bool IsEmbeddedInEditor => Engine.IsEmbeddedInEditor();

    private static bool IsOnSomeScreen(Rect2I rect)
    {
        if (rect.Size.X < 200 || rect.Size.Y < 200) return false;
        for (int i = 0; i < DisplayServer.GetScreenCount(); i++)
            if (DisplayServer.ScreenGetUsableRect(i).Intersects(rect)) return true;
        return false;
    }

    private void RememberWindow()
    {
        if (IsEmbeddedInEditor) return;
        var win = GetWindow();
        _settings.WindowMaximized = win.Mode == Window.ModeEnum.Maximized;
        // Keep the last windowed size when maximized, so un-maximizing restores it.
        if (win.Mode == Window.ModeEnum.Windowed || !_settings.HasWindowState)
        {
            _settings.WindowSize = win.Size;
            _settings.WindowPosition = win.Position;
        }
        _settings.HasWindowState = true;
    }

    // ------------------------------------------------------------------
    // UI
    // ------------------------------------------------------------------

    private void BuildUi()
    {
        var bg = new ColorRect { Color = AppTheme.Bg, MouseFilter = MouseFilterEnum.Ignore };
        AddChild(bg);
        bg.SetAnchorsAndOffsetsPreset(LayoutPreset.FullRect);

        var root = new VBoxContainer();
        root.AddThemeConstantOverride("separation", 0);
        AddChild(root);
        root.SetAnchorsAndOffsetsPreset(LayoutPreset.FullRect);

        // ---- Top bar ----
        var barPad = new MarginContainer();
        Margins(barPad, 18, 18, 10, 6);
        root.AddChild(barPad);
        var bar = new HBoxContainer();
        bar.AddThemeConstantOverride("separation", 10);
        barPad.AddChild(bar);

        var appName = new Label { Text = "Polyphyr", VerticalAlignment = VerticalAlignment.Center };
        appName.AddThemeFontOverride("font", AppFonts.SemiBold);
        appName.AddThemeFontSizeOverride("font_size", 15);
        bar.AddChild(appName);

        var slash = new Label { Text = "/", VerticalAlignment = VerticalAlignment.Center };
        slash.AddThemeColorOverride("font_color", AppTheme.TextFaint);
        bar.AddChild(slash);

        _workspaceLabel = new Label { VerticalAlignment = VerticalAlignment.Center };
        _workspaceLabel.AddThemeColorOverride("font_color", AppTheme.TextDim);
        _workspaceLabel.AddThemeFontSizeOverride("font_size", 15);
        bar.AddChild(_workspaceLabel);

        bar.AddChild(new Control { SizeFlagsHorizontal = SizeFlags.ExpandFill });

        _status = new Label { VerticalAlignment = VerticalAlignment.Center };
        _status.AddThemeColorOverride("font_color", AppTheme.TextFaint);
        _status.AddThemeFontSizeOverride("font_size", 12);
        bar.AddChild(_status);


        // ---- Tabs ----
        var tabsPad = new MarginContainer { SizeFlagsVertical = SizeFlags.ExpandFill };
        Margins(tabsPad, 18, 18, 0, 14);
        root.AddChild(tabsPad);

        _tabs = new TabContainer { SizeFlagsVertical = SizeFlags.ExpandFill };
        // The tabs fill a plain holder, so the Workspaces button, the light/dark switch and the
        // workspace menu can be laid on top of them without becoming tabs themselves.
        _tabsHost = new Control { SizeFlagsVertical = SizeFlags.ExpandFill, SizeFlagsHorizontal = SizeFlags.ExpandFill };
        tabsPad.AddChild(_tabsHost);
        _tabsHost.AddChild(_tabs);
        _tabs.SetAnchorsAndOffsetsPreset(LayoutPreset.FullRect);
        _home = new HomeTab { Name = "Home" };
        _tabs.AddChild(_home);
        _board = new BoardTab { Name = "Tasks", Settings = _settings };
        _tabs.AddChild(_board);
        _notes = new NotesTab { Name = "Documents", Settings = _settings };
        _tabs.AddChild(_notes);
        _sheets = new SheetsTab { Name = "Sheets", Settings = _settings };
        _tabs.AddChild(_sheets);
        _flow = new Polyphyr.UI.Flow.FlowchartTab { Name = "Flowchart" };
        _tabs.AddChild(_flow);
        _tabs.CurrentTab = 0;
        BuildWorkspaceMenu();

        _home.OpenNoteRequested += id =>
        {
            ShowTab(_notes);
            _notes.OpenNote(id);
        };
        _board.OpenNoteRequested += id =>
        {
            ShowTab(_notes);
            _notes.OpenNote(id);
        };
        _board.OpenSheetRequested += OpenSheet;
        _home.OpenSheetRequested += OpenSheet;
        _home.OpenTaskRequested += _ => ShowTab(_board);
    }

    private void OpenSheet(SheetId id)
    {
        ShowTab(_sheets);
        _sheets.OpenSheet(id);
    }

    private void ShowTab(Control tab)
    {
        HideWorkspaceMenu();
        _tabs.CurrentTab = tab.GetIndex();
    }

    // ------------------------------------------------------------------
    // Workspace menu (button at the right end of the tab bar)
    // ------------------------------------------------------------------

    private void BuildWorkspaceMenu()
    {
        // Siblings of the tab container (in the holder), drawn over its tab bar / content.
        _workspacesButton = new Button
        {
            Text = "Workspaces",
            FocusMode = FocusModeEnum.None,
            ToggleMode = true,
            MouseDefaultCursorShape = CursorShape.PointingHand,
            TooltipText = "Switch or create workspaces",
        };
        _workspacesButton.AddThemeFontSizeOverride("font_size", 13);
        _workspacesButton.AddThemeColorOverride("font_color", AppTheme.TextDim);
        _workspacesButton.AddThemeColorOverride("font_hover_color", AppTheme.Text);
        _workspacesButton.AddThemeColorOverride("font_pressed_color", AppTheme.Text);
        _workspacesButton.AddThemeColorOverride("font_hover_pressed_color", AppTheme.Text);
        var idle = AppTheme.Box(new Color(0, 0, 0, 0), AppTheme.Radius, 12, 4);
        var on = AppTheme.Box(AppTheme.Raised, AppTheme.Radius, 12, 4, AppTheme.Border, 1);
        _workspacesButton.AddThemeStyleboxOverride("normal", idle);
        _workspacesButton.AddThemeStyleboxOverride("hover", idle);
        _workspacesButton.AddThemeStyleboxOverride("pressed", on);
        _workspacesButton.AddThemeStyleboxOverride("hover_pressed", on);
        _workspacesButton.Toggled += open =>
        {
            if (open) ShowWorkspaceMenu();
            else HideWorkspaceMenu();
        };
        _tabsHost.AddChild(_workspacesButton);

        // Light / dark switch, at the far right of the tab bar.
        _themeToggle = new ThemeToggle { Light = _settings.LightMode, TooltipText = "Light or dark mode" };
        _themeToggle.ModeChosen += SetLightMode;
        _tabsHost.AddChild(_themeToggle);

        _workspaceScreen = new WorkspaceScreen { Visible = false };
        _tabsHost.AddChild(_workspaceScreen);
        _workspaceScreen.OpenRequested += SwitchWorkspace;
        _workspaceScreen.CreateRequested += CreateWorkspace;

        // Picking any tab closes the menu.
        _tabs.TabClicked += _ => HideWorkspaceMenu();

        var tabBar = _tabs.GetTabBar();
        tabBar.Resized += LayoutWorkspaceMenu;
        _tabsHost.Resized += LayoutWorkspaceMenu;
        Callable.From(LayoutWorkspaceMenu).CallDeferred();
    }

    private void LayoutWorkspaceMenu()
    {
        float barHeight = _tabs.GetTabBar().Size.Y;
        float toggleWidth = ThemeToggle.Width;
        _themeToggle.SetAnchorsPreset(LayoutPreset.TopRight);
        _themeToggle.OffsetLeft = -toggleWidth;
        _themeToggle.OffsetRight = 0;
        _themeToggle.OffsetTop = 4;
        _themeToggle.OffsetBottom = barHeight - 4;

        float width = Mathf.Max(110f, _workspacesButton.GetCombinedMinimumSize().X);
        _workspacesButton.SetAnchorsPreset(LayoutPreset.TopRight);
        _workspacesButton.OffsetLeft = -width - toggleWidth - 10;
        _workspacesButton.OffsetRight = -toggleWidth - 10;
        _workspacesButton.OffsetTop = 3;
        _workspacesButton.OffsetBottom = barHeight - 3;

        _workspaceScreen.SetAnchorsPreset(LayoutPreset.FullRect);
        _workspaceScreen.OffsetLeft = 0;
        _workspaceScreen.OffsetRight = 0;
        _workspaceScreen.OffsetTop = barHeight;
        _workspaceScreen.OffsetBottom = 0;
    }

    /// <summary>Saves everything, then rebuilds the UI in the other color mode.</summary>
    private void SetLightMode(bool light)
    {
        if (light == _settings.LightMode) return;
        SaveNow(flushEditors: true);
        _settings.LightMode = light;
        _settings.Save();
        _restoreTab = _tabs.CurrentTab;
        Callable.From(() => GetTree().ReloadCurrentScene()).CallDeferred();
    }

    private void ShowWorkspaceMenu()
    {
        if (_ws is not null) { _notes.Flush(); _sheets.Flush(); }
        GetViewport().GuiReleaseFocus();
        _workspaceScreen.ShowEntries(ListWorkspaces());
        _workspaceScreen.Visible = true;
        _workspacesButton.SetPressedNoSignal(true);
        if (!_settings.ShowWorkspaceMenu)
        {
            _settings.ShowWorkspaceMenu = true;
            _settings.Save();
        }
    }

    private void HideWorkspaceMenu()
    {
        if (_workspaceScreen is null || !_workspaceScreen.Visible) return;
        _workspaceScreen.Visible = false;
        _workspacesButton.SetPressedNoSignal(false);
        _settings.ShowWorkspaceMenu = false;
        _settings.Save();
    }

    /// <summary>Workspaces opened before, plus any found in the default folder, most recent first.</summary>
    private List<WorkspaceScreen.Entry> ListWorkspaces()
    {
        var paths = new HashSet<string>(_settings.KnownWorkspaces.Keys);
        try
        {
            if (Directory.Exists(AppSettings.WorkspacesRoot))
                foreach (var dir in Directory.GetDirectories(AppSettings.WorkspacesRoot)) paths.Add(dir);
        }
        catch (Exception e)
        {
            GD.PrintErr($"Could not list workspaces: {e.Message}");
        }

        var entries = new List<WorkspaceScreen.Entry>();
        foreach (var path in paths)
        {
            if (!FolderWorkspaceStore.Exists(path)) continue;
            bool current = _ws is not null && SamePath(path, _settings.WorkspacePath);
            string name = current ? _ws!.Name : Path.GetFileName(path.TrimEnd('/', '\\'));
            DateTimeOffset? opened = _settings.KnownWorkspaces.TryGetValue(path, out long t) && t > 0
                ? DateTimeOffset.FromUnixTimeSeconds(t) : null;
            entries.Add(new WorkspaceScreen.Entry(name, path, opened, current));
        }
        return entries
            .OrderByDescending(e => e.IsCurrent)
            .ThenByDescending(e => e.LastOpened ?? DateTimeOffset.MinValue)
            .ThenBy(e => e.Name, StringComparer.CurrentCultureIgnoreCase)
            .ToList();
    }

    private static bool SamePath(string a, string b)
        => string.Equals(Path.GetFullPath(a).TrimEnd('/', '\\'), Path.GetFullPath(b).TrimEnd('/', '\\'), StringComparison.Ordinal);

    private void SwitchWorkspace(string path)
    {
        if (_ws is not null && SamePath(path, _settings.WorkspacePath))
        {
            HideWorkspaceMenu();
            return;
        }
        SaveNow(flushEditors: true);
        if (OpenWorkspace(path))
        {
            HideWorkspaceMenu();
            _tabs.CurrentTab = 0;
        }
        else _workspaceScreen.ShowError("Couldn't open that workspace.");
    }

    private void CreateWorkspace(string name)
    {
        // Keep the name as the folder name, minus characters folders can't have.
        var invalid = Path.GetInvalidFileNameChars();
        string folder = new string(name.Select(c => invalid.Contains(c) ? '-' : c).ToArray()).Trim().TrimEnd('.');
        if (folder.Length == 0)
        {
            _workspaceScreen.ShowError("Please use a different name.");
            return;
        }
        string path = Path.Combine(AppSettings.WorkspacesRoot, folder);
        if (FolderWorkspaceStore.Exists(path) || (Directory.Exists(path) && Directory.EnumerateFileSystemEntries(path).Any()))
        {
            _workspaceScreen.ShowError("A workspace with that name already exists.");
            return;
        }
        SaveNow(flushEditors: true);
        if (OpenWorkspace(path))
        {
            HideWorkspaceMenu();
            _tabs.CurrentTab = 0;
        }
        else _workspaceScreen.ShowError("Couldn't create the workspace.");
    }

    private static void Margins(MarginContainer m, int left, int right, int top, int bottom)
    {
        m.AddThemeConstantOverride("margin_left", left);
        m.AddThemeConstantOverride("margin_right", right);
        m.AddThemeConstantOverride("margin_top", top);
        m.AddThemeConstantOverride("margin_bottom", bottom);
    }

    private static Control Placeholder(string name, string text)
    {
        var label = new Label
        {
            Name = name,
            Text = text,
            HorizontalAlignment = HorizontalAlignment.Center,
            VerticalAlignment = VerticalAlignment.Center,
        };
        label.AddThemeColorOverride("font_color", AppTheme.TextFaint);
        return label;
    }

    // ------------------------------------------------------------------
    // Workspace
    // ------------------------------------------------------------------

    private bool OpenWorkspace(string path)
    {
        try
        {
            // Who is using this computer: one identity per computer, shared across workspaces.
            if (_settings.UserId.IsEmpty) _settings.UserId = UserId.New();

            Workspace ws;
            FolderWorkspaceStore store;
            bool isNew = !FolderWorkspaceStore.Exists(path);
            if (isNew)
            {
                string name = System.IO.Path.GetFileName(path.TrimEnd('/', '\\'));
                (ws, store) = FolderWorkspaceStore.CreateNew(path, name, _settings.UserName, ownerId: _settings.UserId);
                var welcome = ws.NewNote("Welcome");
                ws.Apply(new SetNoteText(welcome, WelcomeText));
                store.Save(ws);
            }
            else
            {
                store = new FolderWorkspaceStore(path);
                ws = store.Load();
            }

            // First time this person opens someone else's workspace: add them as a member.
            if (!ws.Users.ContainsKey(_settings.UserId))
            {
                ws.CurrentUser = _settings.UserId;
                ws.Apply(new AddUser(_settings.UserId, _settings.UserName, "#4F8CFF"));
            }
            ws.CurrentUser = _settings.UserId;

            // Refresh the welcome document if it's still the untouched first version.
            foreach (var note in ws.Notes.Values)
                if (note.Text == OldWelcomeText) ws.Apply(new SetNoteText(note.Id, WelcomeText));

            // Until a name is set from Home, you have none (the name used to come from the OS account).
            if (!_settings.NameChosen)
            {
                _settings.UserName = "";
                ws.Apply(new RenameUser(_settings.UserId, ""));
            }

            _ws = ws;
            _store = store;
            _settings.RememberWorkspace(path);

            _workspaceLabel.Text = ws.Name;
            _notes.Bind(ws);
            _sheets.Bind(ws);
            _flow.Bind(ws);
            _home.Bind(ws, _settings);
            _board.Bind(ws, store);

            // Home's activity heatmap: start from when things were created and edited,
            // then count every change made from here on.
            if (!_settings.HasActivity) SeedActivity(ws);
            ws.Changed += _ => _settings.RecordActivity(DateOnly.FromDateTime(DateTime.Now));
            SetStatus("Opened");
            return true;
        }
        catch (Exception e)
        {
            GD.PrintErr($"Could not open workspace '{path}': {e}");
            SetStatus("Could not open workspace (see Output)");
            return false;
        }
    }

    private void SeedActivity(Workspace ws)
    {
        void Add(ItemMeta meta)
        {
            if (meta.CreatedAt == default) return;
            var created = DateOnly.FromDateTime(meta.CreatedAt.LocalDateTime);
            _settings.RecordActivity(created);
            var modified = DateOnly.FromDateTime(meta.ModifiedAt.LocalDateTime);
            if (meta.ModifiedAt != default && modified != created) _settings.RecordActivity(modified);
        }
        foreach (var card in ws.Cards.Values) Add(card.Meta);
        foreach (var note in ws.Notes.Values) Add(note.Meta);
        foreach (var sheet in ws.Sheets.Values) Add(sheet.Meta);
        _settings.Save();
    }

    private void SaveNow(bool flushEditors)
    {
        if (_ws is null || _store is null) return;
        if (flushEditors)
        {
            _notes.Flush();
            _sheets.Flush();
        }
        if (!_ws.Pending.HasChanges) return;
        try
        {
            _store.Save(_ws);
            SetStatus($"Saved {DateTime.Now:t}");
        }
        catch (Exception e)
        {
            GD.PrintErr($"Save failed: {e}");
            SetStatus("Save failed (see Output)");
        }
    }

    private void SetStatus(string text) => _status.Text = text;
}

/// <summary>Two-part switch with a sun (light) and a moon (dark); the current mode is highlighted.</summary>
public partial class ThemeToggle : Control
{
    public const float Width = 64f;
    public bool Light { get; set; }
    public event Action<bool>? ModeChosen;
    private int _hover = -1;

    public ThemeToggle()
    {
        CustomMinimumSize = new Vector2(Width, 28);
        MouseFilter = MouseFilterEnum.Stop;
        MouseDefaultCursorShape = CursorShape.PointingHand;
        MouseExited += () => { _hover = -1; QueueRedraw(); };
    }

    public override void _GuiInput(InputEvent @event)
    {
        if (@event is InputEventMouseMotion mm)
        {
            int h = mm.Position.X < Size.X / 2 ? 0 : 1;
            if (h != _hover) { _hover = h; QueueRedraw(); }
        }
        else if (@event is InputEventMouseButton { Pressed: true, ButtonIndex: MouseButton.Left } mb)
        {
            bool light = mb.Position.X < Size.X / 2;
            AcceptEvent();
            ModeChosen?.Invoke(light);
        }
    }

    public override void _Draw()
    {
        var full = new Rect2(Vector2.Zero, Size);
        DrawStyleBox(AppTheme.Box(AppTheme.Surface, (int)(Size.Y / 2), 0, 0, AppTheme.Border, 1), full);
        float half = Size.X / 2;
        var sunRect = new Rect2(2, 2, half - 2, Size.Y - 4);
        var moonRect = new Rect2(half, 2, half - 2, Size.Y - 4);
        var on = Light ? sunRect : moonRect;
        DrawStyleBox(AppTheme.Box(AppTheme.Active, (int)(on.Size.Y / 2)), on);
        if (_hover >= 0 && (_hover == 0) != Light)
            DrawStyleBox(AppTheme.Box(new Color(AppTheme.Overlay, 0.06f), (int)(on.Size.Y / 2)), _hover == 0 ? sunRect : moonRect);

        // Sun: a disc with eight short rays.
        var sunColor = Light ? AppTheme.Text : AppTheme.TextFaint;
        var sc = sunRect.GetCenter();
        DrawCircle(sc, 3.2f, sunColor);
        for (int i = 0; i < 8; i++)
        {
            var dir = Vector2.Right.Rotated(Mathf.Tau * i / 8);
            DrawLine(sc + dir * 5.2f, sc + dir * 7.4f, sunColor, 1.4f, true);
        }

        // Moon: a disc with a bite taken out of it.
        var moonColor = Light ? AppTheme.TextFaint : AppTheme.Text;
        var mc = moonRect.GetCenter();
        var behind = Light ? AppTheme.Surface : AppTheme.Active;
        DrawCircle(mc, 6f, moonColor);
        DrawCircle(mc + new Vector2(3.2f, -2.4f), 5f, behind);
    }
}
