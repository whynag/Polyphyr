using System;
using System.Collections.Generic;
using System.Linq;
using Godot;
using Polyphyr.Core;
using Polyphyr.UI.Board;

namespace Polyphyr.UI;

/// <summary>
/// The landing page: greeting, numbers, top tasks, pins, recent documents, and along the bottom
/// the status bar, recently completed tasks, the activity heatmap and the version.
/// It refreshes when it becomes visible and (debounced) when the workspace changes.
/// </summary>
public partial class HomeTab : HBoxContainer
{
    public event Action<NoteId>? OpenNoteRequested;
    public event Action<CardId>? OpenTaskRequested;
    public event Action<SheetId>? OpenSheetRequested;

    private const int TaskCount = 4;
    private const int CompletedCount = 5;
    private const int PinColumns = 2, PinVisibleRows = 8;   // 16 pins visible, the rest scroll
    private const float PinRowH = 36f, PinGap = 4f;

    private StatusBar _statusBar = null!;
    private ActivityHeatmap _heatmap = null!;
    private Label _activityLabel = null!;
    private VBoxContainer _completed = null!;
    private GridContainer _pins = null!;
    private ScrollContainer _pinScroll = null!;
    private Label _pinsEmpty = null!;
    private PopupMenu _pinMenu = null!;
    private string? _pinMenuTarget;

    private VBoxContainer _newestTasks = null!;
    private VBoxContainer _oldestTasks = null!;
    private Control _page = null!;
    private Button _versionDate = null!;

    private void UpdateVersionDate()
    {
        if (_versionDate is null) return;
        _versionDate.Text = AppVersion.Date.ToString(_settings?.MonthFirstDates == true ? "MM/dd/yy" : "dd/MM/yy", System.Globalization.CultureInfo.InvariantCulture);
    }

    private Workspace? _ws;
    private AppSettings? _settings;
    private bool _dirty = true;

    private Label _greeting = null!;
    private LineEdit _nameEdit = null!;
    private Button _editName = null!;
    private bool _editingName;
    private Label _subtitle = null!;
    private VBoxContainer _topTasks = null!;
    private Control _newestPanel = null!;
    private Control _oldestPanel = null!;
    private Timer _refreshTimer = null!;

    public override void _Ready()
    {
        AddThemeConstantOverride("separation", 16);

        var scroll = new ScrollContainer
        {
            SizeFlagsHorizontal = SizeFlags.ExpandFill,
            SizeFlagsVertical = SizeFlags.ExpandFill,
            HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled,
        };
        AddChild(scroll);

        SmoothScroller.Attach(scroll);

        var pad = new MarginContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill };
        pad.AddThemeConstantOverride("margin_left", 40);
        pad.AddThemeConstantOverride("margin_right", 40);
        pad.AddThemeConstantOverride("margin_top", 36);
        pad.AddThemeConstantOverride("margin_bottom", 36);
        scroll.AddChild(pad);

        // The page is at least as tall as the view, so the bottom section sits at the bottom.
        var page = new VBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill };
        page.AddThemeConstantOverride("separation", 0);
        pad.AddChild(page);
        _page = page;
        scroll.Resized += () => _page.CustomMinimumSize = new Vector2(0, Mathf.Max(0, scroll.Size.Y - 72));

        // Keep the content a comfortable reading width on wide screens.
        var column = new VBoxContainer { SizeFlagsHorizontal = SizeFlags.ShrinkBegin, CustomMinimumSize = new Vector2(760, 0) };
        column.AddThemeConstantOverride("separation", 0);
        page.AddChild(column);

        page.AddChild(new Control { SizeFlagsVertical = SizeFlags.ExpandFill, CustomMinimumSize = new Vector2(0, 48) });

        // ---- Bottom: recently completed (left), activity + version (right), status bar under both ----
        var bottom = new HBoxContainer();
        bottom.AddThemeConstantOverride("separation", 24);
        page.AddChild(bottom);

        var completedBox = new VBoxContainer { CustomMinimumSize = new Vector2(380, 0), SizeFlagsVertical = SizeFlags.ShrinkEnd };
        completedBox.AddThemeConstantOverride("separation", 10);
        bottom.AddChild(completedBox);
        completedBox.AddChild(SectionLabel("RECENTLY COMPLETED"));
        var completedPanel = new PanelContainer();
        completedBox.AddChild(completedPanel);
        var completedPad = new MarginContainer();
        foreach (var side in new[] { "margin_left", "margin_right", "margin_top", "margin_bottom" })
            completedPad.AddThemeConstantOverride(side, 6);
        completedPanel.AddChild(completedPad);
        _completed = new VBoxContainer();
        _completed.AddThemeConstantOverride("separation", 2);
        completedPad.AddChild(_completed);

        bottom.AddChild(new Control { SizeFlagsHorizontal = SizeFlags.ExpandFill });

        var right = new VBoxContainer { SizeFlagsVertical = SizeFlags.ShrinkEnd };
        right.AddThemeConstantOverride("separation", 10);
        bottom.AddChild(right);
        _activityLabel = SectionLabel("ACTIVITY");
        right.AddChild(_activityLabel);
        _heatmap = new ActivityHeatmap { SizeFlagsHorizontal = SizeFlags.ShrinkEnd };
        right.AddChild(_heatmap);

        // ---- Version, bottom right: "0.1.0 - 18/10/26"; click the date to flip its order ----
        var versionRow = new HBoxContainer { Alignment = BoxContainer.AlignmentMode.End };
        versionRow.AddThemeConstantOverride("separation", 0);
        right.AddChild(versionRow);
        var version = new Label { Text = $"{AppVersion.Number} - " };
        version.AddThemeColorOverride("font_color", AppTheme.TextFaint);
        version.AddThemeFontSizeOverride("font_size", 12);
        versionRow.AddChild(version);
        _versionDate = new Button
        {
            Flat = true,
            FocusMode = FocusModeEnum.None,
            MouseDefaultCursorShape = CursorShape.PointingHand,
            TooltipText = "Click to switch between dd/mm/yy and mm/dd/yy",
        };
        HoverFade.OptOut(_versionDate);
        _versionDate.AddThemeFontSizeOverride("font_size", 12);
        _versionDate.AddThemeColorOverride("font_color", AppTheme.TextFaint);
        _versionDate.AddThemeColorOverride("font_hover_color", AppTheme.TextDim);
        _versionDate.AddThemeColorOverride("font_pressed_color", AppTheme.TextDim);
        foreach (var state in new[] { "normal", "hover", "pressed", "hover_pressed" })
            _versionDate.AddThemeStyleboxOverride(state, AppTheme.Empty());
        _versionDate.Pressed += () =>
        {
            if (_settings is null) return;
            _settings.MonthFirstDates = !_settings.MonthFirstDates;
            _settings.Save();
            UpdateVersionDate();
        };
        versionRow.AddChild(_versionDate);
        UpdateVersionDate();

        // Status bar, almost at the very bottom.
        page.AddChild(Spacer(24));
        _statusBar = new StatusBar();
        page.AddChild(_statusBar);

        // ---- Greeting, with a pencil to set your name ----
        var greetingRow = new HBoxContainer();
        greetingRow.AddThemeConstantOverride("separation", 8);
        column.AddChild(greetingRow);

        _greeting = new Label { SizeFlagsVertical = SizeFlags.ShrinkCenter };
        _greeting.AddThemeFontOverride("font", AppFonts.SemiBold);
        _greeting.AddThemeFontSizeOverride("font_size", 30);
        _greeting.AddThemeColorOverride("font_color", AppTheme.Text);
        greetingRow.AddChild(_greeting);

        _nameEdit = new LineEdit
        {
            Visible = false,
            PlaceholderText = "Your name",
            MaxLength = 40,
            CustomMinimumSize = new Vector2(240, 0),
            SizeFlagsVertical = SizeFlags.ShrinkCenter,
        };
        _nameEdit.AddThemeFontOverride("font", AppFonts.SemiBold);
        _nameEdit.AddThemeFontSizeOverride("font_size", 26);
        _nameEdit.TextSubmitted += _ => FinishNameEdit(commit: true);
        _nameEdit.FocusExited += () => FinishNameEdit(commit: true);
        _nameEdit.GuiInput += e =>
        {
            if (e is InputEventKey { Pressed: true, Keycode: Key.Escape })
            {
                FinishNameEdit(commit: false);
                _nameEdit.AcceptEvent();
            }
        };
        greetingRow.AddChild(_nameEdit);

        _editName = new PencilButton { TooltipText = "Edit your name", SizeFlagsVertical = SizeFlags.ShrinkCenter };
        _editName.Pressed += BeginNameEdit;
        greetingRow.AddChild(_editName);
        column.AddChild(Spacer(10));

        _subtitle = new Label();
        _subtitle.AddThemeColorOverride("font_color", AppTheme.TextFaint);
        column.AddChild(_subtitle);

        column.AddChild(Spacer(28));

        // ---- Top tasks: highest priority first, newest and oldest ----
        // Hidden entirely when no unfinished task has a priority.
        _topTasks = new VBoxContainer();
        _topTasks.AddThemeConstantOverride("separation", 0);
        column.AddChild(_topTasks);
        _topTasks.AddChild(SectionLabel("TOP TASKS"));
        _topTasks.AddChild(Spacer(10));
        var taskCols = new HBoxContainer();
        taskCols.AddThemeConstantOverride("separation", 12);
        _topTasks.AddChild(taskCols);
        _newestPanel = TaskPanel("Newest",
            "Unfinished tasks that have a priority, highest priority first.\n" +
            "Within the same priority, the latest due date comes first,\n" +
            "then the most recently created. Tasks with no due date come last.\n" +
            "Shows up to 4.", out _newestTasks);
        _oldestPanel = TaskPanel("Oldest",
            "Unfinished tasks that have a priority, highest priority first.\n" +
            "Within the same priority, the earliest (or most overdue) due date comes first,\n" +
            "then whichever has waited longest. Tasks with no due date come last.\n" +
            "Shows up to 4.", out _oldestTasks);
        taskCols.AddChild(_newestPanel);
        taskCols.AddChild(_oldestPanel);
        _topTasks.AddChild(Spacer(32));

        // ---- Pinned (right-click a document or task to pin it) ----
        column.AddChild(SectionLabel("PINNED"));
        column.AddChild(Spacer(10));
        var pinPanel = new PanelContainer();
        column.AddChild(pinPanel);
        var pinPad = new MarginContainer();
        foreach (var side in new[] { "margin_left", "margin_right", "margin_top", "margin_bottom" })
            pinPad.AddThemeConstantOverride(side, 6);
        pinPanel.AddChild(pinPad);
        var pinBox = new VBoxContainer();
        pinPad.AddChild(pinBox);
        _pinScroll = new ScrollContainer { HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled };
        pinBox.AddChild(_pinScroll);
        SmoothScroller.Attach(_pinScroll);
        _pins = new GridContainer { Columns = PinColumns, SizeFlagsHorizontal = SizeFlags.ExpandFill };
        _pins.AddThemeConstantOverride("h_separation", 4);
        _pins.AddThemeConstantOverride("v_separation", (int)PinGap);
        _pinScroll.AddChild(_pins);
        _pinsEmpty = new Label
        {
            Text = "Right-click a document, sheet or task and choose \"Pin to Home\" to keep it here.",
            HorizontalAlignment = HorizontalAlignment.Center,
            CustomMinimumSize = new Vector2(0, 38),
            VerticalAlignment = VerticalAlignment.Center,
        };
        _pinsEmpty.AddThemeColorOverride("font_color", AppTheme.TextFaint);
        _pinsEmpty.AddThemeFontSizeOverride("font_size", 13);
        pinBox.AddChild(_pinsEmpty);

        _pinMenu = new PopupMenu();
        _pinMenu.AddItem("Unpin from Home", 0);
        _pinMenu.IdPressed += _ =>
        {
            if (_settings is null || _pinMenuTarget is null) return;
            _settings.Pins.Remove(_pinMenuTarget);
            _settings.Save();
            Refresh();
        };
        AddChild(_pinMenu);

        _refreshTimer = new Timer { WaitTime = 0.4, OneShot = true };
        _refreshTimer.Timeout += Refresh;
        AddChild(_refreshTimer);

        // Always refresh when shown: opening a document elsewhere changes the recent list.
        VisibilityChanged += () =>
        {
            if (IsVisibleInTree()) Refresh();
        };
    }

    public void Bind(Workspace ws, AppSettings settings)
    {
        if (_ws is not null) _ws.Changed -= OnChanged;
        _ws = ws;
        _settings = settings;
        _ws.Changed += OnChanged;
        UpdateVersionDate();
        Refresh();
    }

    private string _part = "";

    private string CurrentName =>
        _ws is not null && _ws.Users.TryGetValue(_ws.CurrentUser, out var me) ? me.DisplayName.Trim() : _settings?.UserName.Trim() ?? "";

    private void BeginNameEdit()
    {
        if (_ws is null || _editingName) return;
        _editingName = true;
        _greeting.Text = _part + ",";
        _nameEdit.Text = CurrentName;
        _nameEdit.Visible = true;
        _editName.Visible = false;
        _nameEdit.GrabFocus();
        _nameEdit.SelectAll();
    }

    private void FinishNameEdit(bool commit)
    {
        if (!_editingName) return;
        _editingName = false;
        _nameEdit.Visible = false;
        _editName.Visible = true;
        if (commit && _ws is not null)
        {
            string name = _nameEdit.Text.Trim();
            if (_settings is not null)
            {
                _settings.UserName = name;
                _settings.NameChosen = true;
                _settings.Save();
            }
            _ws.Apply(new RenameUser(_ws.CurrentUser, name));
        }
        Refresh();
    }

    private void OnChanged(Change change)
    {
        _dirty = true;
        // Only rebuild while visible; otherwise wait until the tab is shown.
        if (IsVisibleInTree()) _refreshTimer.Start();
    }

    // ------------------------------------------------------------------

    private void Refresh()
    {
        if (_ws is null) return;
        _dirty = false;

        var now = DateTime.Now;
        string part = now.Hour switch
        {
            < 5 => "Working late",
            < 12 => "Good morning",
            < 17 => "Good afternoon",
            < 22 => "Good evening",
            _ => "Working late",
        };
        _part = part;
        if (!_editingName) _greeting.Text = string.IsNullOrWhiteSpace(CurrentName) ? part : $"{part}, {CurrentName}";
        _subtitle.Text = $"{_ws.Name}  ·  {now:dddd, MMMM d}";

        FillTasks();
        FillPins();
        FillBottom();
    }

    private static int Rank(Priority p) => BoardVisuals.Normalize(p) switch
    {
        Priority.High => 3,
        Priority.Medium => 2,
        Priority.Low => 1,
        _ => 0,
    };

    /// <summary>Unfinished tasks, highest priority first; ties broken newest-first or oldest-first.</summary>
    private void FillTasks()
    {
        if (_ws is null) return;
        // Unfinished tasks that have a priority; tasks without one never show here.
        var open = _ws.Cards.Values
            .Where(c => Rank(c.Priority) > 0 && _ws.GetColumnOf(c.Id) is { } col && col.Name != "Completed")
            .ToList();
        // Priority always comes first. Within a priority:
        //   Newest — the latest due date first, then the most recently created.
        //   Oldest — the earliest (or most overdue) due date first, then the longest-waiting.
        // Tasks with no due date come after those that have one. Up to 4 in each.
        var newest = open
            .OrderByDescending(c => Rank(c.Priority))
            .ThenBy(c => c.DueDate is null)
            .ThenByDescending(c => c.DueDate)
            .ThenByDescending(c => c.Meta.CreatedAt)
            .Take(TaskCount).ToList();
        var oldest = open
            .OrderByDescending(c => Rank(c.Priority))
            .ThenBy(c => c.DueDate is null)
            .ThenBy(c => c.DueDate)
            .ThenBy(c => c.Meta.CreatedAt)
            .Take(TaskCount).ToList();
        FillTaskList(_newestTasks, newest);
        FillTaskList(_oldestTasks, oldest);
        _topTasks.Visible = newest.Count > 0;
    }

    private void FillTaskList(VBoxContainer list, IEnumerable<Card> cards)
    {
        foreach (var child in list.GetChildren()) { list.RemoveChild(child); child.QueueFree(); }
        int n = 0;
        foreach (var card in cards)
        {
            list.AddChild(TaskRow(card));
            n++;
        }
        if (n == 0)
        {
            var empty = new Label { Text = "No open tasks", HorizontalAlignment = HorizontalAlignment.Center, CustomMinimumSize = new Vector2(0, 36), VerticalAlignment = VerticalAlignment.Center };
            empty.AddThemeColorOverride("font_color", AppTheme.TextFaint);
            empty.AddThemeFontSizeOverride("font_size", 13);
            list.AddChild(empty);
        }
    }

    private Control TaskRow(Card card) => TaskRow(card, card.Meta.CreatedAt, "created");

    private Control TaskRow(Card card, DateTimeOffset when, string verb)
    {
        var row = new Button
        {
            Flat = true,
            FocusMode = FocusModeEnum.None,
            Alignment = HorizontalAlignment.Left,
            Text = string.IsNullOrWhiteSpace(card.Title) ? "Untitled" : card.Title,
            CustomMinimumSize = new Vector2(0, 36),
            MouseDefaultCursorShape = CursorShape.PointingHand,
            TextOverrunBehavior = TextServer.OverrunBehavior.TrimEllipsis,
            TooltipText = $"{BoardVisuals.PriorityName(card.Priority)} · {verb} {Ago(when)}",
        };
        row.AddThemeFontSizeOverride("font_size", 13);
        row.AddThemeColorOverride("font_color", AppTheme.Text);
        row.AddThemeColorOverride("font_hover_color", AppTheme.Text);
        // Room on the left for the priority arrow, on the right for the age.
        row.AddThemeStyleboxOverride("normal", AppTheme.Empty(34, 6));
        row.AddThemeStyleboxOverride("hover", AppTheme.Empty(34, 6));
        row.AddThemeStyleboxOverride("pressed", AppTheme.Box(AppTheme.Active, AppTheme.Radius, 34, 6));
        var id = card.Id;
        row.Pressed += () => OpenTaskRequested?.Invoke(id);

        var icon = new PriorityIcon { Priority = card.Priority };
        row.AddChild(icon);
        icon.SetAnchorsAndOffsetsPreset(LayoutPreset.LeftWide);
        icon.OffsetLeft = 10;
        icon.OffsetRight = 26;

        var age = new Label
        {
            Text = Ago(when),
            HorizontalAlignment = HorizontalAlignment.Right,
            VerticalAlignment = VerticalAlignment.Center,
            MouseFilter = MouseFilterEnum.Ignore,
        };
        age.AddThemeColorOverride("font_color", AppTheme.TextFaint);
        age.AddThemeFontSizeOverride("font_size", 12);
        // Top tasks show the due date instead (red when overdue), since that's what they're sorted by.
        if (verb == "created" && card.DueDate is { } due)
        {
            var today = DateOnly.FromDateTime(DateTime.Now);
            age.Text = due == today ? "Due today" : "Due " + due.ToString("MMM d");
            if (due < today) age.AddThemeColorOverride("font_color", AppTheme.Danger);
            row.TooltipText += $" · due {due:MMM d}";
        }
        row.AddChild(age);
        age.SetAnchorsAndOffsetsPreset(LayoutPreset.FullRect);
        age.OffsetRight = -12;
        return row;
    }

    private static Control TaskPanel(string caption, string info, out VBoxContainer list)
    {
        var panel = new PanelContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill };
        var pad = new MarginContainer();
        foreach (var side in new[] { "margin_left", "margin_right", "margin_bottom" })
            pad.AddThemeConstantOverride(side, 6);
        pad.AddThemeConstantOverride("margin_top", 12);
        panel.AddChild(pad);
        var box = new VBoxContainer();
        box.AddThemeConstantOverride("separation", 6);
        pad.AddChild(box);
        var title = new Label { Text = caption };
        title.AddThemeColorOverride("font_color", AppTheme.TextDim);
        title.AddThemeFontSizeOverride("font_size", 12);
        var titlePad = new MarginContainer();
        titlePad.AddThemeConstantOverride("margin_left", 10);
        var titleRow = new HBoxContainer();
        titleRow.AddThemeConstantOverride("separation", 6);
        titlePad.AddChild(titleRow);
        titleRow.AddChild(title);
        titleRow.AddChild(new InfoIcon { TooltipText = info, SizeFlagsVertical = SizeFlags.ShrinkCenter });
        box.AddChild(titlePad);
        list = new VBoxContainer();
        list.AddThemeConstantOverride("separation", 2);
        box.AddChild(list);
        return panel;
    }

    // ------------------------------------------------------------------
    // Pins
    // ------------------------------------------------------------------

    private void FillPins()
    {
        if (_ws is null || _settings is null) return;
        foreach (var child in _pins.GetChildren()) { _pins.RemoveChild(child); child.QueueFree(); }
        int count = 0;
        foreach (var pin in _settings.Pins)
        {
            if (!AppSettings.TryParsePin(pin, out var kind, out var id)) continue;
            Control? item = null;
            if (kind == AppSettings.PinKind.Document && _ws.Notes.TryGetValue(new NoteId(id), out var note))
            {
                var noteId = note.Id;
                item = PinItem(KindIcon.KindType.Note, note.Title, pin, () => OpenNoteRequested?.Invoke(noteId));
            }
            else if (kind == AppSettings.PinKind.Sheet && _ws.Sheets.TryGetValue(new SheetId(id), out var sheet))
            {
                var sheetId = sheet.Id;
                item = PinItem(KindIcon.KindType.Sheet, sheet.Title, pin, () => OpenSheetRequested?.Invoke(sheetId));
            }
            else if (kind == AppSettings.PinKind.Task && _ws.Cards.TryGetValue(new CardId(id), out var card))
            {
                var cardId = card.Id;
                item = PinItem(KindIcon.KindType.Task, card.Title, pin, () => OpenTaskRequested?.Invoke(cardId));
            }
            if (item is null) continue;   // deleted since it was pinned
            _pins.AddChild(item);
            count++;
        }
        int rows = (count + PinColumns - 1) / PinColumns;
        int visible = Math.Min(rows, PinVisibleRows);
        _pinScroll.CustomMinimumSize = new Vector2(0, visible * PinRowH + Math.Max(0, visible - 1) * PinGap);
        _pinScroll.Visible = count > 0;
        _pinsEmpty.Visible = count == 0;
    }

    private Control PinItem(KindIcon.KindType kind, string title, string pin, Action open)
    {
        var row = new Button
        {
            Flat = true,
            FocusMode = FocusModeEnum.None,
            Alignment = HorizontalAlignment.Left,
            Text = string.IsNullOrWhiteSpace(title) ? "Untitled" : title,
            CustomMinimumSize = new Vector2(0, PinRowH),
            SizeFlagsHorizontal = SizeFlags.ExpandFill,
            MouseDefaultCursorShape = CursorShape.PointingHand,
            TextOverrunBehavior = TextServer.OverrunBehavior.TrimEllipsis,
        };
        row.AddThemeFontSizeOverride("font_size", 13);
        row.AddThemeColorOverride("font_color", AppTheme.Text);
        row.AddThemeColorOverride("font_hover_color", AppTheme.Text);
        row.AddThemeStyleboxOverride("normal", AppTheme.Empty(34, 6));
        row.AddThemeStyleboxOverride("hover", AppTheme.Empty(34, 6));
        row.AddThemeStyleboxOverride("pressed", AppTheme.Box(AppTheme.Active, AppTheme.Radius, 34, 6));
        row.Pressed += open;
        row.GuiInput += e =>
        {
            if (e is not InputEventMouseButton { Pressed: true, ButtonIndex: MouseButton.Right }) return;
            _pinMenuTarget = pin;
            _pinMenu.ResetSize();
            _pinMenu.Position = TextFieldMenu.PopupPosition(this);
            _pinMenu.Popup();
            row.AcceptEvent();
        };

        var icon = new KindIcon { Kind = kind, Tint = AppTheme.TextDim, MouseFilter = MouseFilterEnum.Ignore };
        row.AddChild(icon);
        icon.SetAnchorsAndOffsetsPreset(LayoutPreset.LeftWide);
        icon.OffsetLeft = 9;
        icon.OffsetRight = 27;
        return row;
    }

    // ------------------------------------------------------------------
    // Bottom: status bar, recently completed, activity
    // ------------------------------------------------------------------

    private void FillBottom()
    {
        if (_ws is null) return;

        int Count(string name) => _ws.Board.Columns.Where(c => c.Name == name).Sum(c => c.Cards.Count);
        _statusBar.SetSegments(new StatusBar.Segment[]
        {
            new("None", Count("None"), StatusBar.NoneColor),
            new("Idea", Count("Idea"), StatusBar.IdeaColor),
            new("To-Do", Count("To-Do"), StatusBar.ToDoColor),
            new("In Progress", Count("In Progress"), StatusBar.InProgressColor),
            new("Completed", Count("Completed"), StatusBar.CompletedColor),
        });

        // Recently completed: newest moves into Completed first (moving a card stamps its edit time).
        foreach (var child in _completed.GetChildren()) { _completed.RemoveChild(child); child.QueueFree(); }
        var done = _ws.Board.Columns.Where(c => c.Name == "Completed")
            .SelectMany(c => c.Cards)
            .Select(id => _ws.Cards.TryGetValue(id, out var card) ? card : null)
            .Where(c => c is not null)
            .Select(c => c!)
            .OrderByDescending(c => c.Meta.ModifiedAt)
            .Take(CompletedCount)
            .ToList();
        foreach (var card in done) _completed.AddChild(TaskRow(card, card.Meta.ModifiedAt, "completed"));
        if (done.Count == 0)
        {
            var empty = new Label { Text = "Nothing completed yet", HorizontalAlignment = HorizontalAlignment.Center, CustomMinimumSize = new Vector2(0, 36), VerticalAlignment = VerticalAlignment.Center };
            empty.AddThemeColorOverride("font_color", AppTheme.TextFaint);
            empty.AddThemeFontSizeOverride("font_size", 13);
            _completed.AddChild(empty);
        }

        var activity = _settings?.Activity;
        _heatmap.SetData(day => activity is not null && activity.TryGetValue(day, out int n) ? n : 0);
        _activityLabel.Text = $"ACTIVITY - Q{_heatmap.Quarter}";
    }

    private static string Ago(DateTimeOffset time)
    {
        var span = DateTimeOffset.UtcNow - time;
        if (span.TotalSeconds < 60) return "just now";
        if (span.TotalMinutes < 60) return $"{(int)span.TotalMinutes} min ago";
        if (span.TotalHours < 24) return $"{(int)span.TotalHours} h ago";
        if (span.TotalDays < 7) return $"{(int)span.TotalDays} d ago";
        return time.ToLocalTime().ToString("MMM d");
    }

    private static Label SectionLabel(string text)
    {
        var label = new Label { Text = text, VerticalAlignment = VerticalAlignment.Center };
        label.AddThemeFontOverride("font", AppFonts.SemiBold);
        label.AddThemeFontSizeOverride("font_size", 11);
        label.AddThemeColorOverride("font_color", AppTheme.TextFaint);
        return label;
    }

    private static Control Spacer(int height) => new() { CustomMinimumSize = new Vector2(0, height) };
}

/// <summary>A small flat button that draws a pencil; faint until hovered.</summary>
public partial class PencilButton : Button
{
    public PencilButton()
    {
        Flat = true;
        FocusMode = FocusModeEnum.None;
        CustomMinimumSize = new Vector2(30, 30);
        MouseDefaultCursorShape = CursorShape.PointingHand;
        MouseEntered += QueueRedraw;
        MouseExited += QueueRedraw;
    }

    public override void _Draw()
    {
        var color = IsHovered() ? AppTheme.TextDim : AppTheme.TextFaint;
        var c = Size / 2;
        // A pencil leaning 45°: body from top-right to the tip at bottom-left.
        var dir = new Vector2(-1, 1).Normalized();
        var normal = new Vector2(1, 1).Normalized();
        const float half = 3f, length = 13f, tip = 4f;
        var back = c - dir * (length / 2);
        var tipBase = back + dir * (length - tip);
        var point = back + dir * length;
        var a = back + normal * half;
        var b = back - normal * half;
        var a2 = tipBase + normal * half;
        var b2 = tipBase - normal * half;
        DrawPolyline(new[] { a, a2, point, b2, b, a }, color, 1.5f, true);
        // Band between the eraser end and the body.
        var band = back + dir * 3f;
        DrawLine(band + normal * half, band - normal * half, color, 1.5f, true);
    }
}
