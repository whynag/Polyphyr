using Godot;

namespace Polyphyr.UI;

/// <summary>
/// Popups, menus, tooltips and dialogs render into their own square viewport. Making that
/// viewport's background transparent lets their rounded corners show what's behind them,
/// instead of Godot's default gray filling the corners.
/// Dialogs with a title bar also get a thin divider under it.
/// </summary>
public static class PopupStyle
{
    private static bool _installed;

    public static void Install(SceneTree tree)
    {
        // Once per run: the main scene is reloaded when switching light/dark mode.
        if (_installed) return;
        _installed = true;
        tree.NodeAdded += node =>
        {
            if (node is not Window window || window == tree.Root) return;
            window.TransparentBg = true;
            if (window is not Popup && !window.Borderless)
                Callable.From(() => AddTitleDivider(window)).CallDeferred();
        };
    }

    private static void AddTitleDivider(Window window)
    {
        if (!GodotObject.IsInstanceValid(window) || window.HasMeta("_title_divider")) return;
        window.SetMeta("_title_divider", true);
        // The content area starts right under the title bar, so a line at its top edge sits on the seam.
        // Top-level, so dialogs don't treat it as content and stretch it over their text.
        var line = new ColorRect { Color = AppTheme.Border, MouseFilter = Control.MouseFilterEnum.Ignore, TopLevel = true };
        window.AddChild(line, false, Node.InternalMode.Back);
        line.SetAnchorsAndOffsetsPreset(Control.LayoutPreset.TopWide);
        line.OffsetBottom = 1;
    }
}
