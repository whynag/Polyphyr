using System;
using System.Collections.Generic;
using Godot;

namespace Polyphyr.UI;

/// <summary>
/// The workspace menu: every workspace on this computer (most recently opened first) and a box
/// to create a new one. Shown over the tab content from the "Workspaces" button in the tab bar.
/// </summary>
public partial class WorkspaceScreen : Control
{
    public readonly record struct Entry(string Name, string Path, DateTimeOffset? LastOpened, bool IsCurrent);

    public event Action<string>? OpenRequested;
    public event Action<string>? CreateRequested;

    private VBoxContainer _list = null!;
    private LineEdit _newName = null!;
    private Button _create = null!;
    private Label _error = null!;

    public override void _Ready()
    {
        MouseFilter = MouseFilterEnum.Stop;

        var bg = new ColorRect { Color = AppTheme.Bg, MouseFilter = MouseFilterEnum.Ignore };
        AddChild(bg);
        bg.SetAnchorsAndOffsetsPreset(LayoutPreset.FullRect);

        var scroll = new ScrollContainer { HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled };
        AddChild(scroll);
        scroll.SetAnchorsAndOffsetsPreset(LayoutPreset.FullRect);
        SmoothScroller.Attach(scroll);

        var pad = new MarginContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill };
        pad.AddThemeConstantOverride("margin_left", 40);
        pad.AddThemeConstantOverride("margin_right", 40);
        pad.AddThemeConstantOverride("margin_top", 36);
        pad.AddThemeConstantOverride("margin_bottom", 36);
        scroll.AddChild(pad);

        var column = new VBoxContainer { SizeFlagsHorizontal = SizeFlags.ShrinkBegin, CustomMinimumSize = new Vector2(620, 0) };
        column.AddThemeConstantOverride("separation", 0);
        pad.AddChild(column);

        var title = new Label { Text = "Workspaces" };
        title.AddThemeFontOverride("font", AppFonts.SemiBold);
        title.AddThemeFontSizeOverride("font_size", 30);
        column.AddChild(title);
        column.AddChild(Spacer(6));
        var subtitle = new Label { Text = "Each workspace has its own tasks, documents and sheets." };
        subtitle.AddThemeColorOverride("font_color", AppTheme.TextFaint);
        column.AddChild(subtitle);
        column.AddChild(Spacer(28));

        // ---- New workspace ----
        column.AddChild(SectionLabel("NEW WORKSPACE"));
        column.AddChild(Spacer(10));
        var newRow = new HBoxContainer();
        newRow.AddThemeConstantOverride("separation", 8);
        column.AddChild(newRow);
        _newName = new LineEdit
        {
            PlaceholderText = "Workspace name",
            MaxLength = 60,
            SizeFlagsHorizontal = SizeFlags.ExpandFill,
            CustomMinimumSize = new Vector2(0, 36),
        };
        _newName.TextChanged += _ =>
        {
            _error.Visible = false;
            _create.Disabled = _newName.Text.Trim().Length == 0;
        };
        _newName.TextSubmitted += _ => Create();
        newRow.AddChild(_newName);
        _create = new Button { Text = "Create", FocusMode = FocusModeEnum.None, Disabled = true, CustomMinimumSize = new Vector2(96, 36) };
        _create.AddThemeStyleboxOverride("normal", AppTheme.Box(AppTheme.PrimaryBg, AppTheme.Radius, 14, 6, AppTheme.PrimaryBorder, 1));
        _create.Pressed += Create;
        newRow.AddChild(_create);
        column.AddChild(Spacer(6));
        _error = new Label { Visible = false };
        _error.AddThemeColorOverride("font_color", AppTheme.Danger);
        _error.AddThemeFontSizeOverride("font_size", 12);
        column.AddChild(_error);
        column.AddChild(Spacer(28));

        // ---- Existing ----
        column.AddChild(SectionLabel("YOUR WORKSPACES"));
        column.AddChild(Spacer(10));
        var panel = new PanelContainer();
        column.AddChild(panel);
        var listPad = new MarginContainer();
        foreach (var side in new[] { "margin_left", "margin_right", "margin_top", "margin_bottom" })
            listPad.AddThemeConstantOverride(side, 6);
        panel.AddChild(listPad);
        _list = new VBoxContainer();
        _list.AddThemeConstantOverride("separation", 2);
        listPad.AddChild(_list);
    }

    public void ShowEntries(IReadOnlyList<Entry> entries)
    {
        foreach (var child in _list.GetChildren()) { _list.RemoveChild(child); child.QueueFree(); }
        foreach (var entry in entries) _list.AddChild(Row(entry));
        if (entries.Count == 0)
        {
            var empty = new Label { Text = "No workspaces yet", HorizontalAlignment = HorizontalAlignment.Center, CustomMinimumSize = new Vector2(0, 40), VerticalAlignment = VerticalAlignment.Center };
            empty.AddThemeColorOverride("font_color", AppTheme.TextFaint);
            _list.AddChild(empty);
        }
        _newName.Text = "";
        _create.Disabled = true;
        _error.Visible = false;
    }

    public void ShowError(string message)
    {
        _error.Text = message;
        _error.Visible = true;
    }

    private void Create()
    {
        string name = _newName.Text.Trim();
        if (name.Length == 0) return;
        CreateRequested?.Invoke(name);
    }

    private Control Row(Entry entry)
    {
        var row = new Button
        {
            Flat = true,
            FocusMode = FocusModeEnum.None,
            CustomMinimumSize = new Vector2(0, 54),
            MouseDefaultCursorShape = CursorShape.PointingHand,
            TooltipText = entry.Path,
        };
        StyleBox style = entry.IsCurrent ? AppTheme.Box(AppTheme.Raised, AppTheme.Radius) : AppTheme.Empty();
        row.AddThemeStyleboxOverride("normal", style);
        row.AddThemeStyleboxOverride("hover", style);
        row.AddThemeStyleboxOverride("pressed", AppTheme.Box(AppTheme.Active, AppTheme.Radius));
        string path = entry.Path;
        row.Pressed += () => OpenRequested?.Invoke(path);

        var pad = new MarginContainer { MouseFilter = MouseFilterEnum.Ignore };
        pad.AddThemeConstantOverride("margin_left", 14);
        pad.AddThemeConstantOverride("margin_right", 14);
        row.AddChild(pad);
        pad.SetAnchorsAndOffsetsPreset(LayoutPreset.FullRect);

        var line = new HBoxContainer { MouseFilter = MouseFilterEnum.Ignore };
        line.AddThemeConstantOverride("separation", 10);
        pad.AddChild(line);

        var text = new VBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill, SizeFlagsVertical = SizeFlags.ShrinkCenter, MouseFilter = MouseFilterEnum.Ignore };
        text.AddThemeConstantOverride("separation", 0);
        line.AddChild(text);
        var name = new Label { Text = entry.Name, TextOverrunBehavior = TextServer.OverrunBehavior.TrimEllipsis, MouseFilter = MouseFilterEnum.Ignore };
        name.AddThemeFontOverride("font", AppFonts.Medium);
        text.AddChild(name);
        var where = new Label { Text = entry.Path, TextOverrunBehavior = TextServer.OverrunBehavior.TrimEllipsis, MouseFilter = MouseFilterEnum.Ignore };
        where.AddThemeColorOverride("font_color", AppTheme.TextFaint);
        where.AddThemeFontSizeOverride("font_size", 11);
        text.AddChild(where);

        var right = new Label
        {
            Text = entry.IsCurrent ? "Current" : entry.LastOpened is { } t ? "Opened " + Ago(t) : "",
            VerticalAlignment = VerticalAlignment.Center,
            SizeFlagsVertical = SizeFlags.ShrinkCenter,
            MouseFilter = MouseFilterEnum.Ignore,
        };
        right.AddThemeColorOverride("font_color", entry.IsCurrent ? AppTheme.Accent : AppTheme.TextFaint);
        right.AddThemeFontSizeOverride("font_size", 12);
        line.AddChild(right);
        return row;
    }

    private static string Ago(DateTimeOffset time)
    {
        var span = DateTimeOffset.UtcNow - time;
        if (span.TotalMinutes < 1) return "just now";
        if (span.TotalMinutes < 60) return $"{(int)span.TotalMinutes} min ago";
        if (span.TotalHours < 24) return $"{(int)span.TotalHours} h ago";
        if (span.TotalDays < 7) return $"{(int)span.TotalDays} d ago";
        return time.ToLocalTime().ToString("MMM d");
    }

    private static Label SectionLabel(string text)
    {
        var label = new Label { Text = text };
        label.AddThemeFontOverride("font", AppFonts.SemiBold);
        label.AddThemeFontSizeOverride("font_size", 11);
        label.AddThemeColorOverride("font_color", AppTheme.TextFaint);
        return label;
    }

    private static Control Spacer(int height) => new() { CustomMinimumSize = new Vector2(0, height), MouseFilter = MouseFilterEnum.Ignore };
}
