using System;
using Godot;

namespace Polyphyr.UI;

/// <summary>
/// The app's version and build date. The number comes from Project Settings →
/// Application → Config → Version ("major.minor.patch.hotfix"); the date is when the code was last built.
/// </summary>
public static class AppVersion
{
    public static string Number
    {
        get
        {
            string v = ProjectSettings.GetSetting("application/config/version", "").AsString();
            return string.IsNullOrWhiteSpace(v) ? "0.1.0.0" : v;
        }
    }

    public static DateTime Date { get; } = BuildDate();

    private static DateTime BuildDate()
    {
        try
        {
            string path = typeof(AppVersion).Assembly.Location;
            if (!string.IsNullOrEmpty(path) && System.IO.File.Exists(path))
                return System.IO.File.GetLastWriteTime(path);
        }
        catch (Exception) { }
        return DateTime.Now;
    }
}
