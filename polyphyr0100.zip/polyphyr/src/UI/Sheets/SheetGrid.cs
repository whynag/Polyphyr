using System;
using System.Collections.Generic;
using System.Text;
using Godot;
using Polyphyr.Core;

namespace Polyphyr.UI.Sheets;

/// <summary>
/// The spreadsheet grid: column letters along the top, row numbers down the side, cells with
/// optional fill, text color and outline. Custom-drawn, so only the visible cells cost anything.
///
/// Mouse: click or drag to select, Shift+click to extend, click a header to select a whole
/// column/row, drag a column header's right edge to resize, double-click to edit.
/// Keys: arrows (Shift extends), Enter/F2 edit, typing replaces, Delete clears,
/// Tab moves right, Ctrl+A/C/V select all / copy / paste.
/// </summary>
public partial class SheetGrid : Control
{
    public const float DefaultColumnWidth = 110f;
    public const float RowHeight = 28f;
    public const float HeaderHeight = 26f;
    public const float RowHeaderWidth = 48f;
    private const float BarSize = 10f;
    private const float ResizeGrab = 4f;
    private const int FontSize = 13;

    private static Color GridBg => AppTheme.Canvas;
    private static Color GridLine => AppTheme.GridLine;
    private static Color HeaderBg => AppTheme.Surface;
    private static Color HeaderActive => AppTheme.Hover;

    /// <summary>Raised when the selection moves, so the toolbar can show the right colors.</summary>
    public event Action? SelectionChanged;

    private Workspace? _ws;
    private SheetId _sheetId;

    private float[] _colX = Array.Empty<float>();   // left edge of each column, plus one past the end
    private Vector2 _scroll;
    private ScrollGlide _glideX, _glideY;

    private CellRef _anchor, _cursor;
    private bool _selecting;

    private int _resizeColumn = -1;
    private float _resizeStartMouse, _resizeStartWidth, _resizePreview;

    private LineEdit _edit = null!;
    private bool _editing;
    private CellRef _editCell;

    private PopupMenu _menu = null!;
    private const int MenuRowAbove = 0, MenuRowBelow = 1, MenuColLeft = 2, MenuColRight = 3,
        MenuDeleteRows = 4, MenuDeleteCols = 5, MenuClear = 6;

    private VScrollBar _vbar = null!;
    private HScrollBar _hbar = null!;
    private bool _syncing;

    private readonly Dictionary<CellRef, (string Text, float Width, string Shown)> _fitCache = new();

    public Sheet? Sheet => _ws is not null && _ws.Sheets.TryGetValue(_sheetId, out var s) ? s : null;

    /// <summary>The selected block: top-left cell and size.</summary>
    public (int Row, int Column, int Rows, int Columns) Selection
    {
        get
        {
            int r0 = Math.Min(_anchor.Row, _cursor.Row), r1 = Math.Max(_anchor.Row, _cursor.Row);
            int c0 = Math.Min(_anchor.Column, _cursor.Column), c1 = Math.Max(_anchor.Column, _cursor.Column);
            return (r0, c0, r1 - r0 + 1, c1 - c0 + 1);
        }
    }

    public CellRef Cursor => _cursor;

    public override void _Ready()
    {
        FocusMode = FocusModeEnum.All;
        ClipContents = true;
        MouseFilter = MouseFilterEnum.Stop;

        _vbar = new VScrollBar();
        AddChild(_vbar);
        _vbar.ValueChanged += v =>
        {
            if (_syncing) return;
            _glideY.Stop();
            _scroll.Y = (float)v;
            PlaceEditor();
            QueueRedraw();
        };
        _hbar = new HScrollBar();
        AddChild(_hbar);
        _hbar.ValueChanged += v =>
        {
            if (_syncing) return;
            _glideX.Stop();
            _scroll.X = (float)v;
            PlaceEditor();
            QueueRedraw();
        };

        _edit = new LineEdit { Visible = false };
        _edit.AddThemeStyleboxOverride("normal", AppTheme.Box(AppTheme.InputBg, 0, 6, 0, AppTheme.Accent, 2));
        _edit.AddThemeStyleboxOverride("focus", AppTheme.Empty());
        _edit.AddThemeFontSizeOverride("font_size", FontSize);
        _edit.TextSubmitted += _ => { CommitEdit(); Move(1, 0, false); };
        _edit.FocusExited += () => CommitEdit(refocus: false);
        _edit.GuiInput += e =>
        {
            if (e is not InputEventKey { Pressed: true } key) return;
            if (key.Keycode == Key.Escape) { CancelEdit(); _edit.AcceptEvent(); }
            else if (key.Keycode == Key.Tab) { CommitEdit(); Move(0, key.ShiftPressed ? -1 : 1, false); _edit.AcceptEvent(); }
        };
        AddChild(_edit);

        _menu = new PopupMenu();
        _menu.IdPressed += OnMenu;
        AddChild(_menu);

        Resized += () => { SyncBars(); PlaceEditor(); };
        SetProcess(false);
    }

    public void Load(Workspace ws, SheetId id)
    {
        CommitEdit();
        _ws = ws;
        _sheetId = id;
        _scroll = Vector2.Zero;
        _glideX.Stop();
        _glideY.Stop();
        _anchor = _cursor = new CellRef(0, 0);
        _fitCache.Clear();
        Refresh();
        SelectionChanged?.Invoke();
    }

    /// <summary>Call after the sheet changed (cells, size, widths, colors).</summary>
    public void Refresh()
    {
        var sheet = Sheet;
        if (sheet is null) return;
        int cols = sheet.ColumnCount;
        if (_colX.Length != cols + 1) _colX = new float[cols + 1];
        float x = 0;
        for (int c = 0; c < cols; c++)
        {
            _colX[c] = x;
            x += ColumnWidth(sheet, c);
        }
        _colX[cols] = x;
        _anchor = Clamp(_anchor, sheet);
        _cursor = Clamp(_cursor, sheet);
        SyncBars();
        QueueRedraw();
    }

    private static float ColumnWidth(Sheet sheet, int column)
        => sheet.ColumnWidths.TryGetValue(column, out var w) ? w : DefaultColumnWidth;

    private static CellRef Clamp(CellRef cell, Sheet sheet)
        => new(Math.Clamp(cell.Row, 0, sheet.RowCount - 1), Math.Clamp(cell.Column, 0, sheet.ColumnCount - 1));

    // ------------------------------------------------------------------
    // Geometry
    // ------------------------------------------------------------------

    private Vector2 ViewSize => new(
        Mathf.Max(0, Size.X - RowHeaderWidth - (_vbar.Visible ? BarSize : 0)),
        Mathf.Max(0, Size.Y - HeaderHeight - (_hbar.Visible ? BarSize : 0)));

    private Vector2 ContentSize => Sheet is { } s ? new Vector2(_colX[^1], s.RowCount * RowHeight) : Vector2.Zero;

    private Vector2 MaxScroll => new(Mathf.Max(0, ContentSize.X - ViewSize.X), Mathf.Max(0, ContentSize.Y - ViewSize.Y));

    private Rect2 CellRect(int row, int column)
        => new(RowHeaderWidth + _colX[column] - _scroll.X, HeaderHeight + row * RowHeight - _scroll.Y,
               _colX[column + 1] - _colX[column], RowHeight);

    private int ColumnAt(float x)
    {
        float cx = x - RowHeaderWidth + _scroll.X;
        if (cx < 0 || _colX.Length < 2) return -1;
        int lo = 0, hi = _colX.Length - 2;
        while (lo < hi)
        {
            int mid = (lo + hi + 1) / 2;
            if (_colX[mid] <= cx) lo = mid;
            else hi = mid - 1;
        }
        return cx < _colX[^1] ? lo : -1;
    }

    private int RowAt(float y, Sheet sheet)
    {
        float cy = y - HeaderHeight + _scroll.Y;
        if (cy < 0) return -1;
        int row = (int)(cy / RowHeight);
        return row < sheet.RowCount ? row : -1;
    }

    /// <summary>Column whose right edge is under the mouse in the header, for resizing.</summary>
    private int ResizeEdgeAt(Vector2 pos)
    {
        if (pos.Y > HeaderHeight || pos.X < RowHeaderWidth) return -1;
        for (int c = 0; c < _colX.Length - 1; c++)
        {
            float edge = RowHeaderWidth + _colX[c + 1] - _scroll.X;
            if (Mathf.Abs(pos.X - edge) <= ResizeGrab) return c;
            if (edge > pos.X + ResizeGrab) break;
        }
        return -1;
    }

    private void SyncBars()
    {
        if (Sheet is null) return;
        var content = ContentSize;
        // Two passes: showing one bar can make the other necessary.
        for (int pass = 0; pass < 2; pass++)
        {
            var view = ViewSize;
            _vbar.Visible = content.Y > view.Y + 0.5f;
            _hbar.Visible = content.X > view.X + 0.5f;
        }
        _scroll = _scroll.Clamp(Vector2.Zero, MaxScroll);
        _syncing = true;
        _vbar.Position = new Vector2(Size.X - BarSize, HeaderHeight);
        _vbar.Size = new Vector2(BarSize, Mathf.Max(0, Size.Y - HeaderHeight - (_hbar.Visible ? BarSize : 0)));
        _vbar.MaxValue = content.Y;
        _vbar.Page = ViewSize.Y;
        _vbar.Value = _scroll.Y;
        _hbar.Position = new Vector2(RowHeaderWidth, Size.Y - BarSize);
        _hbar.Size = new Vector2(Mathf.Max(0, Size.X - RowHeaderWidth - (_vbar.Visible ? BarSize : 0)), BarSize);
        _hbar.MaxValue = content.X;
        _hbar.Page = ViewSize.X;
        _hbar.Value = _scroll.X;
        _syncing = false;
    }

    private void EnsureVisible(CellRef cell)
    {
        var view = ViewSize;
        float left = _colX[cell.Column], right = _colX[cell.Column + 1];
        float top = cell.Row * RowHeight, bottom = top + RowHeight;
        _glideX.Stop();
        _glideY.Stop();
        if (left < _scroll.X) _scroll.X = left;
        else if (right > _scroll.X + view.X) _scroll.X = right - view.X;
        if (top < _scroll.Y) _scroll.Y = top;
        else if (bottom > _scroll.Y + view.Y) _scroll.Y = bottom - view.Y;
        SyncBars();
        PlaceEditor();
        QueueRedraw();
    }

    // ------------------------------------------------------------------
    // Drawing
    // ------------------------------------------------------------------

    public override void _Draw()
    {
        var sheet = Sheet;
        DrawRect(new Rect2(Vector2.Zero, Size), GridBg);
        if (sheet is null) return;

        var font = AppFonts.Regular;
        var view = ViewSize;
        float ascent = font.GetAscent(FontSize);
        float textY = (RowHeight - font.GetHeight(FontSize)) * 0.5f + ascent;

        int firstRow = Math.Max(0, (int)(_scroll.Y / RowHeight));
        int lastRow = Math.Min(sheet.RowCount - 1, (int)((_scroll.Y + view.Y) / RowHeight));
        int firstCol = Math.Max(0, ColumnAt(RowHeaderWidth));
        int lastCol = firstCol;
        while (lastCol < sheet.ColumnCount - 1 && _colX[lastCol + 1] < _scroll.X + view.X) lastCol++;

        float right = Mathf.Min(RowHeaderWidth + view.X, RowHeaderWidth + _colX[^1] - _scroll.X);
        float bottom = Mathf.Min(HeaderHeight + view.Y, HeaderHeight + sheet.RowCount * RowHeight - _scroll.Y);

        // Fills
        for (int r = firstRow; r <= lastRow; r++)
            for (int c = firstCol; c <= lastCol; c++)
                if (sheet.Styles.TryGetValue(new CellRef(r, c), out var st) && Parse(st.Fill) is { } fill)
                    DrawRect(CellRect(r, c), fill);

        // Grid lines
        for (int r = firstRow; r <= lastRow + 1; r++)
        {
            float y = HeaderHeight + r * RowHeight - _scroll.Y;
            DrawLine(new Vector2(RowHeaderWidth, y), new Vector2(right, y), GridLine);
        }
        for (int c = firstCol; c <= lastCol + 1 && c < _colX.Length; c++)
        {
            float x = RowHeaderWidth + _colX[c] - _scroll.X;
            DrawLine(new Vector2(x, HeaderHeight), new Vector2(x, bottom), GridLine);
        }

        // Text and outlines
        for (int r = firstRow; r <= lastRow; r++)
            for (int c = firstCol; c <= lastCol; c++)
            {
                var key = new CellRef(r, c);
                var rect = CellRect(r, c);
                sheet.Styles.TryGetValue(key, out var st);
                if (sheet.Cells.TryGetValue(key, out var text) && !(_editing && key == _editCell))
                {
                    var color = Parse(st?.Text) ?? AppTheme.Text;
                    string shown = Fit(key, text, rect.Size.X - 14, font);
                    DrawString(font, new Vector2(rect.Position.X + 7, rect.Position.Y + textY), shown,
                        HorizontalAlignment.Left, -1, FontSize, color);
                }
                if (Parse(st?.Outline) is { } outline)
                    DrawRect(rect.Grow(-0.75f), outline, false, 1.5f);
            }

        // Selection
        var (sr, sc, rows, cols) = Selection;
        var selRect = CellRect(sr, sc).Merge(CellRect(sr + rows - 1, sc + cols - 1));
        if (rows * cols > 1) DrawRect(selRect, new Color(AppTheme.Accent, 0.10f));
        DrawRect(selRect.Grow(-1f), AppTheme.Accent, false, 2f);
        if (rows * cols > 1) DrawRect(CellRect(_cursor.Row, _cursor.Column).Grow(-2f), new Color(AppTheme.Accent, 0.55f), false, 1f);

        // Column resize preview
        if (_resizeColumn >= 0)
        {
            float x = RowHeaderWidth + _colX[_resizeColumn] + _resizePreview - _scroll.X;
            DrawLine(new Vector2(x, 0), new Vector2(x, bottom), AppTheme.Accent, 1.5f);
        }

        // Headers (drawn last so cells scroll underneath them)
        var headerFont = AppFonts.Medium;
        const int headerSize = 11;
        DrawRect(new Rect2(0, 0, Size.X, HeaderHeight), HeaderBg);
        for (int c = firstCol; c <= lastCol; c++)
        {
            var rect = new Rect2(RowHeaderWidth + _colX[c] - _scroll.X, 0, _colX[c + 1] - _colX[c], HeaderHeight);
            bool on = c >= sc && c < sc + cols;
            if (on) DrawRect(rect, HeaderActive);
            DrawString(headerFont, new Vector2(rect.Position.X, (HeaderHeight - headerFont.GetHeight(headerSize)) * 0.5f + headerFont.GetAscent(headerSize)),
                ColumnName(c), HorizontalAlignment.Center, rect.Size.X, headerSize, on ? AppTheme.Text : AppTheme.TextFaint);
            DrawLine(new Vector2(rect.End.X, 4), new Vector2(rect.End.X, HeaderHeight - 4), GridLine);
        }
        DrawRect(new Rect2(0, HeaderHeight, RowHeaderWidth, Size.Y - HeaderHeight), HeaderBg);
        for (int r = firstRow; r <= lastRow; r++)
        {
            var rect = new Rect2(0, HeaderHeight + r * RowHeight - _scroll.Y, RowHeaderWidth, RowHeight);
            bool on = r >= sr && r < sr + rows;
            if (on) DrawRect(rect, HeaderActive);
            DrawString(headerFont, new Vector2(0, rect.Position.Y + (RowHeight - headerFont.GetHeight(headerSize)) * 0.5f + headerFont.GetAscent(headerSize)),
                (r + 1).ToString(), HorizontalAlignment.Center, RowHeaderWidth, headerSize, on ? AppTheme.Text : AppTheme.TextFaint);
        }
        DrawRect(new Rect2(0, 0, RowHeaderWidth, HeaderHeight), HeaderBg);
        DrawLine(new Vector2(0, HeaderHeight), new Vector2(Size.X, HeaderHeight), AppTheme.Border);
        DrawLine(new Vector2(RowHeaderWidth, 0), new Vector2(RowHeaderWidth, Size.Y), AppTheme.Border);
    }

    /// <summary>Text cut to fit the cell, with an ellipsis. Cached per cell.</summary>
    private string Fit(CellRef key, string text, float width, Font font)
    {
        if (_fitCache.TryGetValue(key, out var hit) && hit.Text == text && hit.Width == width) return hit.Shown;
        string shown = text.Replace('\n', ' ');
        if (font.GetStringSize(shown, HorizontalAlignment.Left, -1, FontSize).X > width)
        {
            int lo = 0, hi = shown.Length;
            while (lo < hi)
            {
                int mid = (lo + hi + 1) / 2;
                if (font.GetStringSize(shown[..mid] + "…", HorizontalAlignment.Left, -1, FontSize).X <= width) lo = mid;
                else hi = mid - 1;
            }
            shown = lo > 0 ? shown[..lo] + "…" : "";
        }
        _fitCache[key] = (text, width, shown);
        return shown;
    }

    public static Color? Parse(string? hex)
    {
        if (string.IsNullOrEmpty(hex) || !Color.HtmlIsValid(hex)) return null;
        return Color.FromHtml(hex);
    }

    public static string ColumnName(int column)
    {
        var sb = new StringBuilder();
        column++;
        while (column > 0)
        {
            int m = (column - 1) % 26;
            sb.Insert(0, (char)('A' + m));
            column = (column - 1) / 26;
        }
        return sb.ToString();
    }

    public string SelectionName()
    {
        var (r, c, rows, cols) = Selection;
        string first = ColumnName(c) + (r + 1);
        return rows * cols == 1 ? first : $"{first}:{ColumnName(c + cols - 1)}{r + rows}";
    }

    // ------------------------------------------------------------------
    // Mouse
    // ------------------------------------------------------------------

    public override int _GetCursorShape(Vector2 atPosition)
        => (int)(_resizeColumn >= 0 || ResizeEdgeAt(atPosition) >= 0 ? CursorShape.Hsize : CursorShape.Arrow);

    public override void _GuiInput(InputEvent @event)
    {
        var sheet = Sheet;
        if (sheet is null) return;
        switch (@event)
        {
            case InputEventMouseButton { Pressed: true } mb when mb.ButtonIndex is MouseButton.WheelUp or MouseButton.WheelDown or MouseButton.WheelLeft or MouseButton.WheelRight:
            {
                float factor = mb.Factor > 0 ? mb.Factor : 1f;
                bool horizontal = mb.ShiftPressed || mb.ButtonIndex is MouseButton.WheelLeft or MouseButton.WheelRight;
                float dir = mb.ButtonIndex is MouseButton.WheelUp or MouseButton.WheelLeft ? -1f : 1f;
                if (horizontal) _glideX.Push(_scroll.X, dir * 120f * factor, MaxScroll.X);
                else _glideY.Push(_scroll.Y, dir * RowHeight * 3f * factor, MaxScroll.Y);
                SetProcess(true);
                AcceptEvent();
                break;
            }
            case InputEventMouseButton { ButtonIndex: MouseButton.Right, Pressed: true } mb:
                OnRightPress(mb.Position, sheet);
                AcceptEvent();
                break;
            case InputEventMouseButton { ButtonIndex: MouseButton.Left } mb:
                if (mb.Pressed) OnLeftPress(mb, sheet);
                else OnLeftRelease();
                AcceptEvent();
                break;
            case InputEventMouseMotion mm:
                OnMotion(mm.Position, sheet);
                break;
            case InputEventKey { Pressed: true } key:
                OnKey(key, sheet);
                break;
        }
    }

    private void OnLeftPress(InputEventMouseButton mb, Sheet sheet)
    {
        GrabFocus();
        var pos = mb.Position;

        int edge = ResizeEdgeAt(pos);
        if (edge >= 0)
        {
            CommitEdit();
            _resizeColumn = edge;
            _resizeStartMouse = pos.X;
            _resizeStartWidth = _resizePreview = ColumnWidth(sheet, edge);
            return;
        }

        bool inHeader = pos.Y < HeaderHeight, inRowHeader = pos.X < RowHeaderWidth;
        int row = RowAt(pos.Y, sheet), col = ColumnAt(pos.X);
        CommitEdit();

        if (inHeader && inRowHeader) { Select(new CellRef(0, 0), new CellRef(sheet.RowCount - 1, sheet.ColumnCount - 1)); return; }
        if (inHeader && col >= 0) { Select(new CellRef(0, col), new CellRef(sheet.RowCount - 1, col)); return; }
        if (inRowHeader && row >= 0) { Select(new CellRef(row, 0), new CellRef(row, sheet.ColumnCount - 1)); return; }
        if (row < 0 || col < 0) return;

        var cell = new CellRef(row, col);
        if (mb.DoubleClick)
        {
            Select(cell, cell);
            BeginEdit(null);
            return;
        }
        if (mb.ShiftPressed) _cursor = cell;
        else _anchor = _cursor = cell;
        _selecting = true;
        SelectionChanged?.Invoke();
        QueueRedraw();
    }

    // ------------------------------------------------------------------
    // Right-click menu: insert / delete rows and columns, clear
    // ------------------------------------------------------------------

    private void OnRightPress(Vector2 pos, Sheet sheet)
    {
        GrabFocus();
        CommitEdit();
        int row = RowAt(pos.Y, sheet), col = ColumnAt(pos.X);
        bool inHeader = pos.Y < HeaderHeight, inRowHeader = pos.X < RowHeaderWidth;
        var (sr, sc, rows, cols) = Selection;
        bool insideSelection = (inHeader || row >= sr && row < sr + rows) && (inRowHeader || col >= sc && col < sc + cols);

        // Right-clicking outside the selection selects what was clicked first.
        if (!insideSelection)
        {
            if (inHeader && col >= 0) Select(new CellRef(0, col), new CellRef(sheet.RowCount - 1, col));
            else if (inRowHeader && row >= 0) Select(new CellRef(row, 0), new CellRef(row, sheet.ColumnCount - 1));
            else if (row >= 0 && col >= 0) Select(new CellRef(row, col), new CellRef(row, col));
            else return;
        }

        (sr, sc, rows, cols) = Selection;
        string Rows(int n) => n == 1 ? "row" : $"{n} rows";
        string Cols(int n) => n == 1 ? "column" : $"{n} columns";
        _menu.Clear();
        _menu.AddItem($"Insert {Rows(rows)} above", MenuRowAbove);
        _menu.AddItem($"Insert {Rows(rows)} below", MenuRowBelow);
        _menu.AddItem($"Insert {Cols(cols)} left", MenuColLeft);
        _menu.AddItem($"Insert {Cols(cols)} right", MenuColRight);
        _menu.AddSeparator();
        _menu.AddItem($"Delete {Rows(rows)}", MenuDeleteRows);
        _menu.AddItem($"Delete {Cols(cols)}", MenuDeleteCols);
        _menu.SetItemDisabled(_menu.GetItemIndex(MenuDeleteRows), rows >= sheet.RowCount);
        _menu.SetItemDisabled(_menu.GetItemIndex(MenuDeleteCols), cols >= sheet.ColumnCount);
        _menu.AddSeparator();
        _menu.AddItem("Clear", MenuClear);
        _menu.ResetSize();
        _menu.Position = TextFieldMenu.PopupPosition(this);
        _menu.Popup();
    }

    private void OnMenu(long id)
    {
        if (_ws is null || Sheet is not { } sheet) return;
        var (r, c, rows, cols) = Selection;
        switch ((int)id)
        {
            case MenuRowAbove:
                _ws.Apply(new InsertSheetRows(_sheetId, r, rows));
                break;
            case MenuRowBelow:
                _ws.Apply(new InsertSheetRows(_sheetId, r + rows, rows));
                _anchor = new CellRef(_anchor.Row + rows, _anchor.Column);
                _cursor = new CellRef(_cursor.Row + rows, _cursor.Column);
                break;
            case MenuColLeft:
                _ws.Apply(new InsertSheetColumns(_sheetId, c, cols));
                break;
            case MenuColRight:
                _ws.Apply(new InsertSheetColumns(_sheetId, c + cols, cols));
                _anchor = new CellRef(_anchor.Row, _anchor.Column + cols);
                _cursor = new CellRef(_cursor.Row, _cursor.Column + cols);
                break;
            case MenuDeleteRows:
                _ws.Apply(new DeleteSheetRows(_sheetId, r, rows));
                _anchor = _cursor = new CellRef(r, c);
                break;
            case MenuDeleteCols:
                _ws.Apply(new DeleteSheetColumns(_sheetId, c, cols));
                _anchor = _cursor = new CellRef(r, c);
                break;
            case MenuClear:
                ClearSelection();
                break;
        }
        _fitCache.Clear();
        Refresh();
        SelectionChanged?.Invoke();
    }

    private void Select(CellRef anchor, CellRef cursor)
    {
        _anchor = anchor;
        _cursor = cursor;
        SelectionChanged?.Invoke();
        QueueRedraw();
    }

    private void OnLeftRelease()
    {
        _selecting = false;
        if (_resizeColumn >= 0 && _ws is not null)
        {
            int column = _resizeColumn;
            _resizeColumn = -1;
            if (Mathf.Abs(_resizePreview - _resizeStartWidth) > 0.5f)
                _ws.Apply(new SetSheetColumnWidth(_sheetId, column, Mathf.Round(_resizePreview)));
            QueueRedraw();
        }
    }

    private void OnMotion(Vector2 pos, Sheet sheet)
    {
        if (_resizeColumn >= 0)
        {
            _resizePreview = Mathf.Clamp(_resizeStartWidth + pos.X - _resizeStartMouse, 40f, 800f);
            QueueRedraw();
            return;
        }
        if (!_selecting) return;
        int row = RowAt(Mathf.Clamp(pos.Y, HeaderHeight + 1, HeaderHeight + ViewSize.Y - 1), sheet);
        int col = ColumnAt(Mathf.Clamp(pos.X, RowHeaderWidth + 1, RowHeaderWidth + ViewSize.X - 1));
        if (row < 0) row = pos.Y < HeaderHeight ? 0 : sheet.RowCount - 1;
        if (col < 0) col = sheet.ColumnCount - 1;
        var cell = new CellRef(row, col);
        if (cell == _cursor) return;
        _cursor = cell;
        SelectionChanged?.Invoke();
        QueueRedraw();
    }

    public override void _Process(double delta)
    {
        float dt = (float)delta;
        if (_glideX.Active) _scroll.X = _glideX.Step(_scroll.X, dt);
        if (_glideY.Active) _scroll.Y = _glideY.Step(_scroll.Y, dt);
        SyncBars();
        PlaceEditor();
        QueueRedraw();
        if (!_glideX.Active && !_glideY.Active) SetProcess(false);
    }

    // ------------------------------------------------------------------
    // Keyboard
    // ------------------------------------------------------------------

    private void OnKey(InputEventKey key, Sheet sheet)
    {
        if (_editing) return;

        bool ctrl = key.CtrlPressed || key.MetaPressed;
        bool handled = true;
        switch (key.Keycode)
        {
            case Key.Up: Move(-1, 0, key.ShiftPressed); break;
            case Key.Down: Move(1, 0, key.ShiftPressed); break;
            case Key.Left: Move(0, -1, key.ShiftPressed); break;
            case Key.Right: Move(0, 1, key.ShiftPressed); break;
            case Key.Tab: Move(0, key.ShiftPressed ? -1 : 1, false); break;
            case Key.Enter or Key.KpEnter or Key.F2: BeginEdit(null); break;
            case Key.Delete or Key.Backspace: ClearSelection(); break;
            case Key.A when ctrl: Select(new CellRef(0, 0), new CellRef(sheet.RowCount - 1, sheet.ColumnCount - 1)); break;
            case Key.C when ctrl: Copy(sheet); break;
            case Key.X when ctrl: Copy(sheet); ClearSelection(); break;
            case Key.V when ctrl: Paste(); break;
            default:
                handled = false;
                if (!ctrl && !key.AltPressed && key.Unicode >= 32)
                {
                    BeginEdit(char.ConvertFromUtf32((int)key.Unicode));
                    handled = true;
                }
                break;
        }
        if (handled) AcceptEvent();
    }

    private void Move(int dRow, int dCol, bool extend)
    {
        if (Sheet is not { } sheet) return;
        var next = Clamp(new CellRef(_cursor.Row + dRow, _cursor.Column + dCol), sheet);
        _cursor = next;
        if (!extend) _anchor = next;
        EnsureVisible(next);
        SelectionChanged?.Invoke();
        GrabFocus();
    }

    private void ClearSelection()
    {
        if (_ws is null) return;
        var (r, c, rows, cols) = Selection;
        _ws.Apply(new ClearSheetRange(_sheetId, r, c, rows, cols));
    }

    private void Copy(Sheet sheet)
    {
        var (r, c, rows, cols) = Selection;
        if ((long)rows * cols > 200_000) return;
        var sb = new StringBuilder();
        for (int i = 0; i < rows; i++)
        {
            if (i > 0) sb.Append('\n');
            for (int j = 0; j < cols; j++)
            {
                if (j > 0) sb.Append('\t');
                sb.Append(sheet.GetCell(r + i, c + j).Replace('\t', ' ').Replace('\n', ' '));
            }
        }
        DisplayServer.ClipboardSet(sb.ToString());
    }

    /// <summary>Pastes tab/newline separated text starting at the cursor (grows the sheet if needed).</summary>
    private void Paste()
    {
        if (_ws is null || Sheet is not { } sheet) return;
        string text = DisplayServer.ClipboardGet().Replace("\r\n", "\n").TrimEnd('\n');
        if (text.Length == 0) return;
        var lines = text.Split('\n');
        int top = Math.Min(_anchor.Row, _cursor.Row), left = Math.Min(_anchor.Column, _cursor.Column);
        int maxCols = 0;
        foreach (var line in lines) maxCols = Math.Max(maxCols, line.Split('\t').Length);
        int needRows = top + lines.Length, needCols = left + maxCols;
        if (needRows > sheet.RowCount || needCols > sheet.ColumnCount)
            _ws.Apply(new ResizeSheet(_sheetId, Math.Max(sheet.RowCount, needRows), Math.Max(sheet.ColumnCount, needCols)));
        for (int i = 0; i < lines.Length; i++)
        {
            var parts = lines[i].Split('\t');
            for (int j = 0; j < parts.Length; j++)
                _ws.Apply(new SetSheetCell(_sheetId, top + i, left + j, parts[j]));
        }
        _anchor = new CellRef(top, left);
        _cursor = new CellRef(top + lines.Length - 1, left + maxCols - 1);
        Refresh();
        SelectionChanged?.Invoke();
    }

    // ------------------------------------------------------------------
    // Editing
    // ------------------------------------------------------------------

    /// <summary>Starts editing the cursor cell; <paramref name="replaceWith"/> replaces its text (typing), null keeps it.</summary>
    private void BeginEdit(string? replaceWith)
    {
        if (Sheet is not { } sheet) return;
        _anchor = _cursor;
        _editCell = _cursor;
        _editing = true;
        EnsureVisible(_cursor);
        _edit.Text = replaceWith ?? sheet.GetCell(_cursor.Row, _cursor.Column);
        var color = sheet.Styles.TryGetValue(_cursor, out var st) ? Parse(st.Text) : null;
        _edit.AddThemeColorOverride("font_color", color ?? AppTheme.Text);
        _edit.Visible = true;
        PlaceEditor();
        _edit.GrabFocus();
        _edit.CaretColumn = _edit.Text.Length;
        QueueRedraw();
    }

    private void PlaceEditor()
    {
        if (!_editing || _colX.Length < 2) return;
        var rect = CellRect(_editCell.Row, _editCell.Column);
        _edit.Position = rect.Position;
        _edit.Size = new Vector2(Mathf.Max(rect.Size.X, 120f), rect.Size.Y);
    }

    /// <summary>Saves the cell being edited, if any.</summary>
    public void CommitEdit(bool refocus = true)
    {
        if (!_editing) return;
        _editing = false;
        _edit.Visible = false;
        if (_ws is not null && Sheet is not null)
            _ws.Apply(new SetSheetCell(_sheetId, _editCell.Row, _editCell.Column, _edit.Text));
        if (refocus && IsVisibleInTree()) GrabFocus();
        QueueRedraw();
    }

    private void CancelEdit()
    {
        if (!_editing) return;
        _editing = false;
        _edit.Visible = false;
        GrabFocus();
        QueueRedraw();
    }
}
