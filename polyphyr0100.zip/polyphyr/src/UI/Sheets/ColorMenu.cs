using System;
using Godot;

namespace Polyphyr.UI.Sheets;

/// <summary>
/// Color dropdown for the sheet toolbar: a palette of swatches, "None", and a full color picker
/// for anything else. Picking calls back with "#rrggbb" (or null for none).
/// </summary>
public partial class ColorMenu : PopupPanel
{
    private static readonly string[] Palette =
    {
        // Light / neutral
        "#ffffff", "#e6e6e7", "#98989d", "#646468", "#2c2c30", "#000000",
        // Bright
        "#e5646e", "#f0883e", "#e3b341", "#3fb950", "#39c5cf", "#4f8cff", "#a371f7", "#db61a2",
        // Deep (good for fills behind light text)
        "#4a1f24", "#4a2c14", "#4a3b12", "#173d22", "#123c40", "#1b2d55", "#2f2350", "#47203a",
    };

    private Action<string?>? _onPick;
    private ColorPicker _picker = null!;
    private Label _title = null!;

    public override void _Ready()
    {
        var pad = new MarginContainer();
        foreach (var side in new[] { "margin_left", "margin_right", "margin_top", "margin_bottom" })
            pad.AddThemeConstantOverride(side, 8);
        AddChild(pad);
        var box = new VBoxContainer();
        box.AddThemeConstantOverride("separation", 8);
        pad.AddChild(box);

        _title = new Label();
        _title.AddThemeFontOverride("font", AppFonts.SemiBold);
        _title.AddThemeFontSizeOverride("font_size", 11);
        _title.AddThemeColorOverride("font_color", AppTheme.TextFaint);
        box.AddChild(_title);

        var grid = new GridContainer { Columns = 8 };
        grid.AddThemeConstantOverride("h_separation", 4);
        grid.AddThemeConstantOverride("v_separation", 4);
        box.AddChild(grid);
        foreach (var hex in Palette)
        {
            var swatch = new Button
            {
                FocusMode = Control.FocusModeEnum.None,
                CustomMinimumSize = new Vector2(24, 24),
                TooltipText = hex,
                MouseDefaultCursorShape = Control.CursorShape.PointingHand,
            };
            var look = AppTheme.Box(new Color(hex), 4, 0, 0, new Color(AppTheme.Overlay, 0.15f), 1);
            var hover = AppTheme.Box(new Color(hex), 4, 0, 0, AppTheme.Text, 1);
            swatch.AddThemeStyleboxOverride("normal", look);
            swatch.AddThemeStyleboxOverride("hover", hover);
            swatch.AddThemeStyleboxOverride("pressed", hover);
            HoverFade.OptOut(swatch);
            string value = hex;
            swatch.Pressed += () => Pick(value);
            grid.AddChild(swatch);
        }

        var none = new Button { Text = "None", FocusMode = Control.FocusModeEnum.None, Alignment = HorizontalAlignment.Left };
        none.Pressed += () => Pick(null);
        box.AddChild(none);

        box.AddChild(new ColorRect { Color = AppTheme.Border, CustomMinimumSize = new Vector2(0, 1) });

        // Anything else: a full picker, applied with the button under it.
        _picker = new ColorPicker
        {
            EditAlpha = true,
            PresetsVisible = false,
            SamplerVisible = false,
            ColorModesVisible = false,
            CustomMinimumSize = new Vector2(232, 0),
        };
        box.AddChild(_picker);
        var apply = new Button { Text = "Use this color", FocusMode = Control.FocusModeEnum.None };
        apply.Pressed += () => Pick("#" + _picker.Color.ToHtml(_picker.Color.A < 0.999f));
        box.AddChild(apply);
    }

    public void Open(Vector2I at, string title, Color? current, Action<string?> onPick)
    {
        _onPick = onPick;
        _title.Text = title.ToUpperInvariant();
        _picker.Color = current ?? AppTheme.Text;
        Popup(new Rect2I(at, Vector2I.Zero));
    }

    private void Pick(string? hex)
    {
        Hide();
        _onPick?.Invoke(hex);
    }
}
