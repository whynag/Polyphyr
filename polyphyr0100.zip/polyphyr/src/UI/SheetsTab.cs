using System;
using System.Collections.Generic;
using System.Linq;
using Godot;
using Polyphyr.Core;
using Polyphyr.UI.Sheets;

namespace Polyphyr.UI;

/// <summary>
/// Sheets: the same layout as Documents (list on the left), with a grid on the right and a
/// toolbar for fill, text and outline colors. New sheets start as a 24 × 24 grid.
/// </summary>
public partial class SheetsTab : HSplitContainer
{
    private Workspace? _ws;
    private SheetId? _current;
    private readonly List<SheetId> _listIds = new();

    private LineEdit _filter = null!;
    private NoteList _list = null!;
    private SheetGrid _grid = null!;
    private Control _editorArea = null!;
    private ColorMenu _colorMenu = null!;
    private ColorToolButton _fillButton = null!, _textButton = null!, _outlineButton = null!;
    private Label _selectionLabel = null!;
    private Label _empty = null!;
    private ConfirmationDialog _confirmDelete = null!;
    private Label _deleteMessage = null!;
    private CheckBox _dontAskAgain = null!;

    /// <summary>Per-computer preferences (used for "Don't ask me again" on delete).</summary>
    public AppSettings? Settings { get; set; }
    private PopupMenu _context = null!;
    private PopupPanel _renamePopup = null!;
    private LineEdit _renameEdit = null!;

    private SheetId? _contextTarget;
    private SheetId? _pendingDelete;
    private Vector2I _contextPos;
    private bool _renameCancelled;

    // Resize handle between the sidebar and the editor: drawn here so it can fade.
    private Control _sidebar = null!;
    private Control _right = null!;
    private float _handleAlpha;
    private bool _handleDragging;
    private bool _mouseWasDown;
    private Rect2 _lastGap;
    private readonly StyleBoxFlat _handleStyle = AppTheme.Box(AppTheme.TextDim, 2);

    private const int MenuRename = 0;
    private const int MenuDelete = 1;
    private const int MenuPin = 2;

    public override void _Ready()
    {
        // ---- Left: sidebar panel with header, filter and list ----
        var sidebar = new PanelContainer { CustomMinimumSize = new Vector2(250, 0) };
        _sidebar = sidebar;
        AddChild(sidebar);
        var sidebarPad = new MarginContainer();
        sidebarPad.AddThemeConstantOverride("margin_left", 10);
        sidebarPad.AddThemeConstantOverride("margin_right", 10);
        sidebarPad.AddThemeConstantOverride("margin_top", 12);
        sidebarPad.AddThemeConstantOverride("margin_bottom", 10);
        sidebar.AddChild(sidebarPad);
        var left = new VBoxContainer();
        left.AddThemeConstantOverride("separation", 10);
        sidebarPad.AddChild(left);

        var header = new HBoxContainer();
        left.AddChild(header);
        var heading = new Label { Text = "SHEETS", SizeFlagsHorizontal = SizeFlags.ExpandFill, VerticalAlignment = VerticalAlignment.Center };
        heading.AddThemeFontOverride("font", AppFonts.SemiBold);
        heading.AddThemeFontSizeOverride("font_size", 11);
        heading.AddThemeColorOverride("font_color", AppTheme.TextFaint);
        heading.AddThemeConstantOverride("outline_size", 0);
        header.AddChild(heading);
        var add = new Button { Text = "+", TooltipText = "New sheet", Flat = true, FocusMode = FocusModeEnum.None, CustomMinimumSize = new Vector2(28, 26) };
        add.AddThemeFontSizeOverride("font_size", 18);
        add.AddThemeColorOverride("font_color", AppTheme.TextDim);
        add.AddThemeColorOverride("font_hover_color", AppTheme.Text);
        add.Pressed += AddSheet;
        header.AddChild(add);

        _filter = new LineEdit { PlaceholderText = "Search", SizeFlagsHorizontal = SizeFlags.ExpandFill, ClearButtonEnabled = true };
        _filter.TextChanged += _ => RefreshList();
        left.AddChild(_filter);

        _list = new NoteList { SizeFlagsVertical = SizeFlags.ExpandFill };
        _list.ItemActivated += index => Open(_listIds[index]);
        _list.ItemContextRequested += (index, _) => OnItemContext(index);
        left.AddChild(_list);

        // ---- Right: title bar + editor ----
        var right = new VBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill };
        right.AddThemeConstantOverride("separation", 0);
        _right = right;
        AddChild(right);


        // Toolbar: colors for the selection, grow the grid, and which cells are selected.
        var toolbarPad = new MarginContainer();
        toolbarPad.AddThemeConstantOverride("margin_left", 12);
        toolbarPad.AddThemeConstantOverride("margin_top", 12);
        toolbarPad.AddThemeConstantOverride("margin_bottom", 8);
        right.AddChild(toolbarPad);
        var toolbar = new HBoxContainer();
        toolbar.AddThemeConstantOverride("separation", 6);
        toolbarPad.AddChild(toolbar);
        _fillButton = new ColorToolButton { Part = CellStylePart.Fill, Text = "Fill", TooltipText = "Highlight the selected cells" };
        _textButton = new ColorToolButton { Part = CellStylePart.Text, Text = "Text", TooltipText = "Color the text in the selected cells" };
        _outlineButton = new ColorToolButton { Part = CellStylePart.Outline, Text = "Outline", TooltipText = "Outline the selected cells" };
        foreach (var b in new[] { _fillButton, _textButton, _outlineButton })
        {
            var button = b;
            button.Pressed += () => OpenColorMenu(button);
            toolbar.AddChild(button);
        }
        toolbar.AddChild(new VSeparator());
        var addRow = new Button { Text = "+ Row", FocusMode = FocusModeEnum.None, TooltipText = "Add a row at the bottom" };
        addRow.Pressed += () => Grow(1, 0);
        toolbar.AddChild(addRow);
        var addColumn = new Button { Text = "+ Column", FocusMode = FocusModeEnum.None, TooltipText = "Add a column on the right" };
        addColumn.Pressed += () => Grow(0, 1);
        toolbar.AddChild(addColumn);
        toolbar.AddChild(new Control { SizeFlagsHorizontal = SizeFlags.ExpandFill });
        _selectionLabel = new Label { VerticalAlignment = VerticalAlignment.Center };
        _selectionLabel.AddThemeColorOverride("font_color", AppTheme.TextFaint);
        _selectionLabel.AddThemeFontOverride("font", AppFonts.Mono);
        _selectionLabel.AddThemeFontSizeOverride("font_size", 12);
        toolbar.AddChild(_selectionLabel);

        var editorHolder = new Control { SizeFlagsVertical = SizeFlags.ExpandFill, SizeFlagsHorizontal = SizeFlags.ExpandFill };
        right.AddChild(editorHolder);
        _editorArea = toolbarPad;
        _grid = new SheetGrid();
        editorHolder.AddChild(_grid);
        _grid.SetAnchorsAndOffsetsPreset(LayoutPreset.FullRect);
        _grid.SelectionChanged += UpdateToolbar;

        _colorMenu = new ColorMenu();
        AddChild(_colorMenu);

        _empty = new Label
        {
            Text = "No sheet selected.\nPress + to create one.",
            HorizontalAlignment = HorizontalAlignment.Center,
            VerticalAlignment = VerticalAlignment.Center,
            MouseFilter = MouseFilterEnum.Ignore,
        };
        _empty.AddThemeColorOverride("font_color", AppTheme.TextFaint);
        editorHolder.AddChild(_empty);
        _empty.SetAnchorsAndOffsetsPreset(LayoutPreset.FullRect);

        _confirmDelete = new ConfirmationDialog { OkButtonText = "Delete", Title = "Delete sheet" };
        var deleteBody = new VBoxContainer { CustomMinimumSize = new Vector2(360, 0) };
        deleteBody.AddThemeConstantOverride("separation", 16);
        // A fixed width, so the wrapped message can't stretch the dialog tall.
        _deleteMessage = new Label { AutowrapMode = TextServer.AutowrapMode.WordSmart, CustomMinimumSize = new Vector2(360, 0) };
        deleteBody.AddChild(_deleteMessage);
        _dontAskAgain = new CheckBox { Text = "Don't ask me again", FocusMode = FocusModeEnum.None };
        deleteBody.AddChild(_dontAskAgain);
        deleteBody.AddChild(new Control { CustomMinimumSize = new Vector2(0, 6) });
        _confirmDelete.AddChild(deleteBody);
        _confirmDelete.Confirmed += () =>
        {
            if (_dontAskAgain.ButtonPressed && Settings is not null)
            {
                Settings.SkipDeleteConfirm = true;
                Settings.Save();
            }
            if (_pendingDelete is { } id) DeleteSheetById(id);
            _pendingDelete = null;
        };
        AddChild(_confirmDelete);

        // Right-click menu on the notes list.
        _context = new PopupMenu();
        _context.AddItem("Rename", MenuRename);
        _context.AddItem("Pin to Home", MenuPin);
        _context.AddSeparator();
        _context.AddItem("Delete", MenuDelete);
        _context.IdPressed += OnContextMenu;
        AddChild(_context);

        // Small inline box for renaming from the list. Enter or clicking away saves; Escape cancels.
        _renamePopup = new PopupPanel();
        _renameEdit = new LineEdit { CustomMinimumSize = new Vector2(220, 0) };
        _renameEdit.TextSubmitted += _ => _renamePopup.Hide();
        _renameEdit.GuiInput += e =>
        {
            if (!e.IsActionPressed("ui_cancel")) return;
            _renameCancelled = true;
            _renamePopup.Hide();
        };
        _renamePopup.AddChild(_renameEdit);
        _renamePopup.PopupHide += () =>
        {
            if (!_renameCancelled) CommitRename();
            _renameCancelled = false;
        };
        AddChild(_renamePopup);

        UpdateEnabled();
    }

    /// <summary>Opens a sheet (used by Home and the task list).</summary>
    public void OpenSheet(SheetId id)
    {
        if (_ws is null || !_ws.Sheets.ContainsKey(id)) return;
        if (!_listIds.Contains(id))
        {
            _filter.Text = "";
            RefreshList();
        }
        Open(id);
        _grid.GrabFocus();
    }

    // ------------------------------------------------------------------
    // Resize handle
    // ------------------------------------------------------------------

    private Rect2 GapRect()
    {
        float left = _sidebar.Position.X + _sidebar.Size.X;
        float right = _right.Position.X;
        return new Rect2(left, 0, Mathf.Max(1f, right - left), Size.Y);
    }

    public override void _Process(double delta)
    {
        if (_sidebar is null || !IsVisibleInTree()) return;

        bool down = Input.IsMouseButtonPressed(MouseButton.Left);
        bool over = GapRect().Grow(2f).HasPoint(GetLocalMousePosition());
        if (down && !_mouseWasDown && over) _handleDragging = true;
        if (!down) _handleDragging = false;
        _mouseWasDown = down;

        var gap = GapRect();
        if (gap != _lastGap)
        {
            _lastGap = gap;
            QueueRedraw();
        }

        float target = over || _handleDragging ? 1f : 0f;
        if (_handleAlpha == target) return;
        float dt = (float)delta;
        _handleAlpha = target > _handleAlpha
            ? Mathf.Min(target, _handleAlpha + dt / HoverFade.FadeIn)
            : Mathf.Max(target, _handleAlpha - dt / HoverFade.FadeOut);
        QueueRedraw();
    }

    public override void _Draw()
    {
        if (_handleAlpha <= 0.001f || _sidebar is null) return;
        var gap = GapRect();
        const float width = 4f, height = 44f;
        var rect = new Rect2(gap.Position.X + (gap.Size.X - width) * 0.5f, (Size.Y - height) * 0.5f, width, height);
        _handleStyle.BgColor = new Color(_handleDragging ? AppTheme.Text : AppTheme.TextDim, 0.85f * _handleAlpha);
        _handleStyle.Draw(GetCanvasItem(), rect);
    }

    public void Bind(Workspace ws)
    {
        if (_ws is not null) _ws.Changed -= OnWorkspaceChanged;
        _ws = ws;
        _ws.Changed += OnWorkspaceChanged;
        _current = null;
        RefreshList();

        var first = SortedSheets().FirstOrDefault();
        if (first is not null) Open(first.Id);
        else UpdateEnabled();
    }

    /// <summary>Saves the cell being typed in, if any. Called before saving.</summary>
    public void Flush() => _grid?.CommitEdit(refocus: false);

    // ------------------------------------------------------------------

    private IEnumerable<Sheet> SortedSheets()
        => _ws is null ? Enumerable.Empty<Sheet>()
            : _ws.Sheets.Values.OrderBy(n => n.Title, StringComparer.CurrentCultureIgnoreCase);

    private void RefreshList()
    {
        _listIds.Clear();
        var titles = new List<string>();
        int selected = -1;
        string filter = _filter.Text.Trim();
        foreach (var note in SortedSheets())
        {
            if (filter.Length > 0 && !note.Title.Contains(filter, StringComparison.CurrentCultureIgnoreCase)) continue;
            if (_current == note.Id) selected = titles.Count;
            titles.Add(string.IsNullOrWhiteSpace(note.Title) ? Polyphyr.UI.Board.BoardTab.UntitledSheet : note.Title);
            _listIds.Add(note.Id);
        }
        _list.SetItems(titles, selected);
    }

    private void Open(SheetId id)
    {
        if (_ws is null || !_ws.Sheets.ContainsKey(id)) return;
        if (_current == id) return;
        Flush();
        _current = id;
        _grid.Load(_ws, id);
        int index = _listIds.IndexOf(id);
        if (index >= 0) _list.Select(index);
        UpdateEnabled();
    }

    private void AddSheet()
    {
        if (_ws is null) return;
        Flush();
        var id = _ws.NewSheet(Polyphyr.UI.Board.BoardTab.UntitledSheet);
        _filter.Text = "";
        RefreshList();
        Open(id);

        // Name it right away, in place on its row in the list.
        int index = _listIds.IndexOf(id);
        if (index < 0) return;
        var row = _list.RowRect(index);
        BeginRename(id, ToPopupPosition(_list.GetGlobalRect().Position + row.Position), (int)row.Size.X);
    }

    /// <summary>Converts a position in this window to the coordinates popups use.</summary>
    private Vector2I ToPopupPosition(Vector2 global)
        => GetViewport().GuiEmbedSubwindows ? (Vector2I)global : GetWindow().Position + (Vector2I)global;

    private void BeginRename(SheetId id, Vector2I position, int width)
    {
        if (_ws is null || !_ws.Sheets.TryGetValue(id, out var note)) return;
        _contextTarget = id;
        _renameCancelled = false;
        _renameEdit.Text = note.Title;
        _renamePopup.Popup(new Rect2I(position, new Vector2I(Math.Max(220, width), 0)));
        _renameEdit.GrabFocus();
        _renameEdit.SelectAll();
    }

    // ------------------------------------------------------------------
    // Right-click menu
    // ------------------------------------------------------------------

    private void OnItemContext(int index)
    {
        if (index < 0 || index >= _listIds.Count) return;
        _contextTarget = _listIds[index];

        // Popups are positioned in window coordinates when embedded, screen coordinates otherwise.
        _contextPos = GetViewport().GuiEmbedSubwindows
            ? (Vector2I)GetGlobalMousePosition()
            : DisplayServer.MouseGetPosition();
        bool pinned = Settings?.IsPinned(AppSettings.PinKind.Sheet, _contextTarget.Value.Value) == true;
        _context.SetItemText(_context.GetItemIndex(MenuPin), pinned ? "Unpin from Home" : "Pin to Home");
        _context.ResetSize();
        _context.Position = _contextPos;
        _context.Popup();
    }

    private void OnContextMenu(long id)
    {
        if (_contextTarget is not { } target || _ws is null || !_ws.Sheets.TryGetValue(target, out _)) return;
        switch ((int)id)
        {
            case MenuRename:
                BeginRename(target, _contextPos - new Vector2I(8, 18), (int)_list.Size.X - 16);
                break;
            case MenuDelete:
                AskDelete(target);
                break;
            case MenuPin:
                Settings?.TogglePin(AppSettings.PinKind.Sheet, target.Value);
                break;
        }
    }

    private void CommitRename()
    {
        if (_ws is null || _contextTarget is not { } id || !_ws.Sheets.TryGetValue(id, out var note)) return;
        string title = _renameEdit.Text.Trim();
        if (title.Length == 0 || title == note.Title) return;
        _ws.Apply(new RenameSheet(id, title));
    }

    private void AskDelete(SheetId id)
    {
        if (_ws is null || !_ws.Sheets.TryGetValue(id, out var note)) return;
        if (Settings?.SkipDeleteConfirm == true)
        {
            DeleteSheetById(id);
            return;
        }
        _pendingDelete = id;
        string name = string.IsNullOrWhiteSpace(note.Title) ? Polyphyr.UI.Board.BoardTab.UntitledSheet : note.Title;
        _deleteMessage.Text = $"Delete \"{name}\"? This can't be undone.";
        _dontAskAgain.ButtonPressed = false;
        _confirmDelete.Size = new Vector2I(420, 1);
        _confirmDelete.ResetSize();
        _confirmDelete.PopupCentered();
    }

    private void DeleteSheetById(SheetId id)
    {
        if (_ws is null || !_ws.Sheets.ContainsKey(id)) return;
        if (_current != id)
        {
            _ws.Apply(new DeleteSheet(id));
            return;
        }

        // Deleting the open sheet: drop the cell being typed, then open another one.
        _current = null;
        _ws.Apply(new DeleteSheet(id));
        var next = SortedSheets().FirstOrDefault();
        if (next is not null) Open(next.Id);
        else UpdateEnabled();
    }

    private void OnWorkspaceChanged(Change change)
    {
        switch (change)
        {
            case CreateSheet or RenameSheet or DeleteSheet:
                RefreshList();
                break;
            case SetSheetCell or SetSheetStyle or ClearSheetRange or ResizeSheet or SetSheetColumnWidth
                or InsertSheetRows or DeleteSheetRows or InsertSheetColumns or DeleteSheetColumns:
                _grid.Refresh();
                UpdateToolbar();
                break;
        }
    }

    private void UpdateEnabled()
    {
        bool hasSheet = _current is not null;
        _grid.Visible = hasSheet;
        _editorArea.Visible = hasSheet;
        _empty.Visible = !hasSheet;
        UpdateToolbar();
    }

    // ------------------------------------------------------------------
    // Toolbar
    // ------------------------------------------------------------------

    private void UpdateToolbar()
    {
        if (_grid.Sheet is not { } sheet)
        {
            _selectionLabel.Text = "";
            return;
        }
        _selectionLabel.Text = _grid.SelectionName();
        sheet.Styles.TryGetValue(_grid.Cursor, out var style);
        _fillButton.Swatch = SheetGrid.Parse(style?.Fill);
        _textButton.Swatch = SheetGrid.Parse(style?.Text);
        _outlineButton.Swatch = SheetGrid.Parse(style?.Outline);
    }

    private void OpenColorMenu(ColorToolButton button)
    {
        if (_ws is null || _current is not { } id) return;
        var ws = _ws;
        var (row, col, rows, cols) = _grid.Selection;
        var at = (Vector2I)(button.GetScreenPosition() + new Vector2(0, button.Size.Y + 4));
        if (GetViewport().GuiEmbedSubwindows) at = (Vector2I)(button.GetGlobalRect().Position + new Vector2(0, button.Size.Y + 4));
        _colorMenu.Open(at, button.Text, button.Swatch, hex =>
        {
            ws.Apply(new SetSheetStyle(id, row, col, rows, cols, button.Part, hex));
            _grid.GrabFocus();
        });
    }

    private void Grow(int rows, int columns)
    {
        if (_ws is null || _grid.Sheet is not { } sheet || _current is not { } id) return;
        _grid.CommitEdit();
        _ws.Apply(new ResizeSheet(id, sheet.RowCount + rows, sheet.ColumnCount + columns));
    }
}

/// <summary>Toolbar button with a label and a strip underneath showing the current color.</summary>
public partial class ColorToolButton : Button
{
    public CellStylePart Part { get; set; }

    private Color? _swatch;
    public Color? Swatch
    {
        get => _swatch;
        set { _swatch = value; QueueRedraw(); }
    }

    public ColorToolButton()
    {
        FocusMode = FocusModeEnum.None;
        CustomMinimumSize = new Vector2(64, 30);
        AddThemeFontSizeOverride("font_size", 13);
    }

    public override void _Draw()
    {
        var bar = new Rect2(10, Size.Y - 6, Size.X - 20, 3);
        if (_swatch is { } c) DrawRect(bar, c);
        else DrawRect(bar, new Color(AppTheme.TextFaint, 0.35f));
    }
}
