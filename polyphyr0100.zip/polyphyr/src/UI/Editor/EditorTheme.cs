using Godot;
using Polyphyr.Core.Text;

namespace Polyphyr.UI.Editor;

/// <summary>Colors, fonts and spacing for the note editor.</summary>
public sealed class EditorTheme
{
    // Colors
    // (Picked for the current light/dark mode when the editor is created.)
    public Color Text = AppTheme.Pick("dcdcdd", "28282b");
    public Color Heading = AppTheme.Pick("f4f4f4", "121214");
    public Color Dim = AppTheme.TextFaint;
    public Color Code = AppTheme.Pick("e3b07c", "a35d1c");
    public Color CodeBackground = new(AppTheme.Overlay, 0.05f);
    public Color Accent = AppTheme.Accent;
    public Color Selection = AppTheme.IsLight ? new(0.24f, 0.39f, 0.87f, 0.20f) : new(0.44f, 0.56f, 1f, 0.30f);
    public Color Caret = AppTheme.Pick("f4f4f4", "121214");
    public Color Background = AppTheme.Bg;

    // Checkboxes: muted, desaturated blue instead of the bright accent.
    public Color CheckboxBorder = AppTheme.Pick("4e4e53", "b8b8b7");
    public Color CheckboxBorderHover = AppTheme.Pick("828287", "8e8e93");
    public Color CheckboxFill = AppTheme.Pick("3a4563", "dbe4fb");
    public Color CheckboxFillHover = AppTheme.Pick("46547a", "c7d4f7");
    public Color CheckMark = AppTheme.Pick("c9d1e3", "3d63dd");
    public Color CheckboxHalo = new(AppTheme.Overlay, 0.07f);

    // Fonts
    public Font Regular = AppFonts.Regular;
    public Font Bold = AppFonts.SemiBold;
    public Font Italic = AppFonts.Italic;
    public Font BoldItalic = AppFonts.SemiBoldItalic;
    public Font Mono = AppFonts.Mono;
    public int BaseSize = 16;

    // Spacing
    public float LineGap = 7f;
    public float PadLeft = 40f;
    public float PadRight = 40f;
    public float PadTop = 28f;
    public float PadBottom = 120f;
    public float BulletWidth = 22f;
    public float CheckboxWidth = 28f;

    public static EditorTheme Create(int baseSize = 16) => new() { BaseSize = baseSize };

    public int SizeFor(int headingLevel, bool sourceMode) => sourceMode ? BaseSize - 1 : headingLevel switch
    {
        1 => Mathf.RoundToInt(BaseSize * 1.75f),
        2 => Mathf.RoundToInt(BaseSize * 1.4f),
        3 => Mathf.RoundToInt(BaseSize * 1.15f),
        _ => BaseSize,
    };

    public Font FontFor(InlineStyle style, bool heading, bool sourceMode)
    {
        if (sourceMode || (style & InlineStyle.Code) != 0) return Mono;
        if ((style & InlineStyle.Marker) != 0) return heading ? Bold : Regular;
        bool bold = heading || (style & InlineStyle.Bold) != 0;
        bool italic = (style & InlineStyle.Italic) != 0;
        return bold ? (italic ? BoldItalic : Bold) : (italic ? Italic : Regular);
    }

    /// <summary>Extra space above and below a block, so headings breathe.</summary>
    public (float Top, float Bottom) BlockPadding(int headingLevel, bool sourceMode) => sourceMode ? (1f, 1f) : headingLevel switch
    {
        1 => (18f, 6f),
        2 => (14f, 4f),
        3 => (10f, 2f),
        _ => (2f, 2f),
    };
}
