using System;
using System.Collections.Generic;
using Godot;
using Polyphyr.Core;
using Polyphyr.Core.Text;

namespace Polyphyr.UI.Editor;

/// <summary>
/// Live-preview note editor. Lines being edited show their raw markers (dimmed);
/// every other line is shown formatted. The button in the bottom-right switches to
/// source mode, which shows every line raw.
///
/// Performance: each line is parsed, shaped and wrapped once and cached until it changes.
/// Line heights off screen are estimated until they scroll into view, so opening a long
/// note only lays out what's visible.
/// </summary>
public partial class NoteEditor : Control
{
    private sealed class Slot
    {
        public LineLayout? Preview;
        public LineLayout? Raw;
        public float Top;
        public float Height;
    }

    public TextDocument Document { get; } = new();

    /// <summary>Raised after every edit made by the user (not after <see cref="Load"/>).</summary>
    public event Action? TextEdited;

    private readonly List<Slot> _slots = new() { new Slot() };
    private EditorTheme _theme = null!;
    private TextPos _caret;
    private TextPos _anchor;
    private float? _goalX;
    private float _scroll;
    private ScrollGlide _glide;
    private float _contentHeight;
    private float _textWidth = 600f;
    private bool _dragging;
    private bool _sourceMode;
    private bool _blinkOn = true;
    private bool _syncingScroll;
    private Rect2 _caretRect;
    private bool _caretRectValid;

    private VScrollBar _vbar = null!;
    private Button _modeButton = null!;
    private CaretLayer _caretLayer = null!;
    private Timer _blink = null!;
    private PopupMenu _menu = null!;

    // Right-click menu ids
    private const int MenuCut = 0, MenuCopy = 1, MenuPaste = 2, MenuSelectAll = 3, MenuUndo = 4, MenuRedo = 5;
    private const int FmtBold = 100, FmtItalic = 101, FmtUnderline = 102, FmtStrike = 103, FmtCode = 104;
    private const int FmtH1 = 110, FmtH2 = 111, FmtH3 = 112, FmtBullet = 113, FmtCheckbox = 114;

    // Checkbox hover: which checkbox the mouse is over, and a 0..1 fade amount per checkbox line.
    private const float FadeIn = 0.08f;
    private const float FadeOut = 0.16f;
    private int _hoverCheckLine = -1;
    private readonly Dictionary<int, float> _checkHover = new();
    private readonly StyleBoxFlat _checkStyle = new() { AntiAliasing = true };
    private readonly StyleBoxFlat _haloStyle = new() { AntiAliasing = true };

    public NoteEditor()
    {
        Document.LinesReplaced += OnLinesReplaced;
    }

    // ------------------------------------------------------------------
    // Public API
    // ------------------------------------------------------------------

    public string Text => Document.GetText();

    public bool SourceMode
    {
        get => _sourceMode;
        set
        {
            if (_sourceMode == value) return;
            _sourceMode = value;
            UpdateModeButton();
            QueueRedraw();
        }
    }

    /// <summary>Replaces the content (e.g. when switching notes). Clears undo history.</summary>
    public void Load(string text)
    {
        Document.SetText(text);
        _caret = _anchor = new TextPos(0, 0);
        _scroll = 0;
        _glide.Stop();
        _goalX = null;
        QueueRedraw();
    }

    internal bool CaretVisible => HasFocus() && _blinkOn && _caretRectValid;
    internal Rect2 CaretRect => _caretRect;
    internal Color CaretColor => _theme.Caret;

    // ------------------------------------------------------------------
    // Setup
    // ------------------------------------------------------------------

    public override void _Ready()
    {
        FocusMode = FocusModeEnum.All;
        ClipContents = true;
        MouseDefaultCursorShape = CursorShape.Ibeam;

        _theme = EditorTheme.Create();
        _checkStyle.SetCornerRadiusAll(4);
        _checkStyle.SetBorderWidthAll(1);
        _haloStyle.SetCornerRadiusAll(6);
        SetProcess(false);

        _caretLayer = new CaretLayer { Editor = this, MouseFilter = MouseFilterEnum.Ignore };
        AddChild(_caretLayer);
        _caretLayer.SetAnchorsAndOffsetsPreset(LayoutPreset.FullRect);

        _vbar = new VScrollBar { MouseDefaultCursorShape = CursorShape.Arrow };
        AddChild(_vbar);
        _vbar.SetAnchorsAndOffsetsPreset(LayoutPreset.RightWide);
        _vbar.OffsetLeft = -12;
        _vbar.ValueChanged += value =>
        {
            if (_syncingScroll) return;
            _glide.Stop();
            _scroll = (float)value;
            QueueRedraw();
        };

        _modeButton = new Button
        {
            FocusMode = FocusModeEnum.None,
            MouseDefaultCursorShape = CursorShape.PointingHand,
        };
        AddChild(_modeButton);
        _modeButton.SetAnchorsAndOffsetsPreset(LayoutPreset.BottomRight);
        _modeButton.GrowHorizontal = GrowDirection.Begin;
        _modeButton.GrowVertical = GrowDirection.Begin;
        _modeButton.OffsetLeft = -120;
        _modeButton.OffsetTop = -46;
        _modeButton.OffsetRight = -22;
        _modeButton.OffsetBottom = -16;
        _modeButton.AddThemeFontSizeOverride("font_size", 12);
        _modeButton.AddThemeColorOverride("font_color", AppTheme.TextDim);
        _modeButton.Pressed += () => SourceMode = !SourceMode;
        UpdateModeButton();

        _blink = new Timer { WaitTime = 0.55, OneShot = false };
        AddChild(_blink);
        _blink.Timeout += () =>
        {
            _blinkOn = !_blinkOn;
            _caretLayer.QueueRedraw();
        };

        BuildContextMenu();
    }

    private static Key Ctrl(Key key) => (Key)((long)KeyModifierMask.MaskCmdOrCtrl | (long)key);
    private static Key CtrlShift(Key key) => (Key)((long)KeyModifierMask.MaskCmdOrCtrl | (long)KeyModifierMask.MaskShift | (long)key);

    private void BuildContextMenu()
    {
        _menu = new PopupMenu();
        _menu.AddItem("Cut", MenuCut, Ctrl(Key.X));
        _menu.AddItem("Copy", MenuCopy, Ctrl(Key.C));
        _menu.AddItem("Paste", MenuPaste, Ctrl(Key.V));
        _menu.AddSeparator();
        _menu.AddItem("Select All", MenuSelectAll, Ctrl(Key.A));
        _menu.AddSeparator();
        _menu.AddItem("Undo", MenuUndo, Ctrl(Key.Z));
        _menu.AddItem("Redo", MenuRedo, CtrlShift(Key.Z));
        _menu.AddSeparator();

        var format = new PopupMenu();
        format.AddItem("Bold   *", FmtBold, Ctrl(Key.B));
        format.AddItem("Italic   //", FmtItalic, Ctrl(Key.I));
        format.AddItem("Underline   _", FmtUnderline, Ctrl(Key.U));
        format.AddItem("Strikethrough   --", FmtStrike);
        format.AddItem("Code   `", FmtCode);
        format.AddSeparator();
        format.AddItem("Heading 1   #", FmtH1);
        format.AddItem("Heading 2   ##", FmtH2);
        format.AddItem("Heading 3   ###", FmtH3);
        format.AddItem("Bullet   -", FmtBullet);
        format.AddItem("Checkbox   =", FmtCheckbox);
        format.IdPressed += id => OnMenu((int)id);
        _menu.AddChild(format);
        _menu.AddSubmenuNodeItem("Format", format);

        _menu.IdPressed += id => OnMenu((int)id);
        AddChild(_menu, false, InternalMode.Front);
    }

    private void ShowContextMenu()
    {
        void Disable(int id, bool disabled)
        {
            int index = _menu.GetItemIndex(id);
            if (index >= 0) _menu.SetItemDisabled(index, disabled);
        }
        Disable(MenuCut, !HasSelection);
        Disable(MenuCopy, !HasSelection);
        Disable(MenuUndo, !Document.CanUndo);
        Disable(MenuRedo, !Document.CanRedo);
        _menu.Position = TextFieldMenu.PopupPosition(this);
        _menu.Popup();
    }

    private void OnMenu(int id)
    {
        switch (id)
        {
            case MenuCut:
                if (!HasSelection) break;
                DisplayServer.ClipboardSet(Document.GetRange(_anchor, _caret));
                ReplaceSelection("", false);
                break;
            case MenuCopy:
                if (HasSelection) DisplayServer.ClipboardSet(Document.GetRange(_anchor, _caret));
                break;
            case MenuPaste:
                ReplaceSelection(DisplayServer.ClipboardGet(), false);
                break;
            case MenuSelectAll:
                _anchor = new TextPos(0, 0);
                _caret = Document.End;
                QueueRedraw();
                break;
            case MenuUndo:
                ApplyUndo(Document.Undo());
                break;
            case MenuRedo:
                ApplyUndo(Document.Redo());
                break;
            case FmtBold: ApplyInline("*"); break;
            case FmtItalic: ApplyInline("//"); break;
            case FmtUnderline: ApplyInline("_"); break;
            case FmtStrike: ApplyInline("--"); break;
            case FmtCode: ApplyInline("`"); break;
            case FmtH1: ApplyBlock(BlockKind.Heading, 1); break;
            case FmtH2: ApplyBlock(BlockKind.Heading, 2); break;
            case FmtH3: ApplyBlock(BlockKind.Heading, 3); break;
            case FmtBullet: ApplyBlock(BlockKind.Bullet, 0); break;
            case FmtCheckbox: ApplyBlock(BlockKind.Checkbox, 0); break;
        }
        GrabFocus();
    }

    // ------------------------------------------------------------------
    // Formatting commands
    // ------------------------------------------------------------------

    /// <summary>
    /// Wraps the selection in a marker (e.g. *text*), or removes it if the selection is already wrapped.
    /// With nothing selected, inserts the pair and puts the caret between them.
    /// Spaces at the edges stay outside the markers, since markers must touch the text.
    /// </summary>
    private void ApplyInline(string marker)
    {
        Document.BreakUndoGroup();
        if (!HasSelection)
        {
            var end = Document.Replace(_caret, _caret, marker + marker, _caret);
            _caret = _anchor = new TextPos(end.Line, end.Col - marker.Length);
            AfterEdit();
            return;
        }

        var a = SelStart;
        var b = SelEnd;
        string text = Document.GetRange(a, b);
        string result;
        if (a.Line == b.Line && text.Length > marker.Length * 2 && text.StartsWith(marker) && text.EndsWith(marker))
        {
            result = text.Substring(marker.Length, text.Length - marker.Length * 2);
        }
        else
        {
            var lines = text.Split('\n');
            for (int i = 0; i < lines.Length; i++)
            {
                // Lines that start at column 0 keep their block prefix (# , - , = ) outside the markers.
                bool atLineStart = i > 0 || a.Col == 0;
                lines[i] = WrapSegment(lines[i], marker, atLineStart);
            }
            result = string.Join('\n', lines);
        }

        var newEnd = Document.Replace(a, b, result, _caret);
        _anchor = a;
        _caret = newEnd;
        Document.BreakUndoGroup();
        AfterEdit();
    }

    // ------------------------------------------------------------------
    // Colors: {f=#.. t=#.. o=#..|text}
    // ------------------------------------------------------------------

    /// <summary>The color span the caret is in (or that the selection sits inside), if any.</summary>
    private ColorSpan? SpanAt(int line, int from, int to)
    {
        foreach (var span in MarkupParser.Parse(Document[line]).Colors)
            if (from >= span.Open && to <= span.End + 1 && !(from == span.End + 1 && to == from)) return span;
        return null;
    }

    /// <summary>The fill / text / outline color where the caret is, for the toolbar.</summary>
    public string? ColorAtCaret(CellStylePart part)
    {
        var span = SpanAt(_caret.Line, Math.Min(_caret.Col, _anchor.Line == _caret.Line ? _anchor.Col : _caret.Col),
            Math.Max(_caret.Col, _anchor.Line == _caret.Line ? _anchor.Col : _caret.Col));
        if (span is not { } s) return null;
        return part switch { CellStylePart.Fill => s.Fill, CellStylePart.Text => s.Text, _ => s.Outline };
    }

    /// <summary>A cheap fingerprint of the caret's line and position, so the toolbar knows when to refresh.</summary>
    public (int, int, int, string) CaretState => (_caret.Line, _caret.Col, _anchor.Col, Document[_caret.Line]);

    /// <summary>
    /// Sets one color on the selection. Inside an existing colored span it changes that span;
    /// otherwise the selected text (each line of it) is wrapped in a new span. Null removes the color.
    /// </summary>
    public void ApplyColor(CellStylePart part, string? hex)
    {
        var a = SelStart;
        var b = SelEnd;
        Document.BreakUndoGroup();

        // Inside (or exactly around) an existing span on one line: edit it.
        if (a.Line == b.Line && SpanAt(a.Line, a.Col, b.Col) is { } span)
        {
            string fill = span.Fill ?? "", text = span.Text ?? "", outline = span.Outline ?? "";
            switch (part)
            {
                case CellStylePart.Fill: fill = hex ?? ""; break;
                case CellStylePart.Text: text = hex ?? ""; break;
                default: outline = hex ?? ""; break;
            }
            string line = Document[a.Line];
            string content = line.Substring(span.Start, span.End - span.Start);
            string replacement = OpenTag(fill, text, outline) is { } tag ? tag + content + "}" : content;
            var start = new TextPos(a.Line, span.Open);
            var end = Document.Replace(start, new TextPos(a.Line, span.End + 1), replacement, _caret);
            _anchor = HasSelection ? start : end;
            _caret = end;
            if (!HasSelection) _anchor = _caret;
            Document.BreakUndoGroup();
            AfterEdit();
            return;
        }

        if (hex is null || !HasSelection) return;
        string tagText = OpenTag(part == CellStylePart.Fill ? hex : "", part == CellStylePart.Text ? hex : "", part == CellStylePart.Outline ? hex : "")!;
        var lines = Document.GetRange(a, b).Split('\n');
        for (int i = 0; i < lines.Length; i++)
        {
            bool atLineStart = i > 0 || a.Col == 0;
            int prefix = atLineStart ? MarkupParser.Parse(lines[i]).ContentStart : 0;
            int s0 = prefix;
            while (s0 < lines[i].Length && char.IsWhiteSpace(lines[i][s0])) s0++;
            int e0 = lines[i].Length;
            while (e0 > s0 && char.IsWhiteSpace(lines[i][e0 - 1])) e0--;
            if (s0 >= e0) continue;
            lines[i] = lines[i][..s0] + tagText + lines[i][s0..e0] + "}" + lines[i][e0..];
        }
        var newEnd = Document.Replace(a, b, string.Join('\n', lines), _caret);
        _anchor = a;
        _caret = newEnd;
        Document.BreakUndoGroup();
        AfterEdit();
    }

    private static string? OpenTag(string fill, string text, string outline)
    {
        var parts = new List<string>(3);
        if (fill.Length > 0) parts.Add("f=" + fill);
        if (text.Length > 0) parts.Add("t=" + text);
        if (outline.Length > 0) parts.Add("o=" + outline);
        return parts.Count == 0 ? null : "{" + string.Join(' ', parts) + "|";
    }

    private static string WrapSegment(string segment, string marker, bool atLineStart)
    {
        int prefix = atLineStart ? MarkupParser.Parse(segment).ContentStart : 0;
        int start = prefix;
        while (start < segment.Length && char.IsWhiteSpace(segment[start])) start++;
        int end = segment.Length;
        while (end > start && char.IsWhiteSpace(segment[end - 1])) end--;
        if (start >= end) return segment;
        return segment.Substring(0, start) + marker + segment.Substring(start, end - start) + marker + segment.Substring(end);
    }

    /// <summary>
    /// Turns the caret line (or every selected line) into a heading, bullet or checkbox.
    /// Applying the same kind again turns it back into plain text.
    /// </summary>
    private void ApplyBlock(BlockKind kind, int level)
    {
        Document.BreakUndoGroup();
        int first = SelStart.Line, last = SelEnd.Line;

        bool allAlready = true;
        for (int i = first; i <= last; i++)
        {
            var p = MarkupParser.Parse(Document[i]);
            if (p.Kind != kind || (kind == BlockKind.Heading && p.HeadingLevel != level)) { allAlready = false; break; }
        }

        string prefix = kind switch
        {
            BlockKind.Heading => new string('#', level) + " ",
            BlockKind.Bullet => "- ",
            BlockKind.Checkbox => "= ",
            _ => "",
        };

        var newLines = new string[last - first + 1];
        int caretShift = 0, anchorShift = 0;
        for (int i = first; i <= last; i++)
        {
            string line = Document[i];
            var p = MarkupParser.Parse(line);
            string indent = kind == BlockKind.Heading ? "" : line.Substring(0, p.IndentLength);
            string content = line.Substring(p.ContentStart);
            string updated = allAlready ? line.Substring(0, p.IndentLength) + content : indent + prefix + content;
            newLines[i - first] = updated;
            int shift = updated.Length - line.Length;
            if (i == _caret.Line) caretShift = shift;
            if (i == _anchor.Line) anchorShift = shift;
        }

        var start = new TextPos(first, 0);
        var stop = new TextPos(last, Document[last].Length);
        Document.Replace(start, stop, string.Join('\n', newLines), _caret);
        _caret = Document.Clamp(new TextPos(_caret.Line, Math.Max(0, _caret.Col + caretShift)));
        _anchor = Document.Clamp(new TextPos(_anchor.Line, Math.Max(0, _anchor.Col + anchorShift)));
        Document.BreakUndoGroup();
        AfterEdit();
    }

    private void UpdateModeButton()
    {
        if (_modeButton is null) return;
        _modeButton.Text = _sourceMode ? "Live preview" : "Source";
        _modeButton.TooltipText = _sourceMode ? "Show formatting" : "Show raw text";
    }

    public override void _Notification(int what)
    {
        switch ((long)what)
        {
            case NotificationFocusEnter:
                ResetBlink();
                QueueRedraw();
                break;
            case NotificationFocusExit:
                _blink?.Stop();
                _dragging = false;
                QueueRedraw();
                break;
            case NotificationMouseExit:
                SetCheckboxHover(-1);
                break;
            case NotificationResized:
                QueueRedraw();
                break;
        }
    }

    private void OnLinesReplaced(int first, int removed, int inserted)
    {
        _checkHover.Clear();
        _hoverCheckLine = -1;
        _slots.RemoveRange(first, removed);
        var fresh = new Slot[inserted];
        for (int i = 0; i < inserted; i++) fresh[i] = new Slot();
        _slots.InsertRange(first, fresh);
        QueueRedraw();
    }

    // ------------------------------------------------------------------
    // Layout
    // ------------------------------------------------------------------

    private bool HasSelection => _anchor != _caret;
    private TextPos SelStart => TextPos.Min(_anchor, _caret);
    private TextPos SelEnd => TextPos.Max(_anchor, _caret);

    /// <summary>Lines being edited show raw text: the caret line and every line in the selection.</summary>
    private bool IsRaw(int line)
    {
        if (_sourceMode) return true;
        if (!HasFocus()) return false;
        return line >= SelStart.Line && line <= SelEnd.Line;
    }

    private LineLayout GetLayout(int line, bool? raw = null)
    {
        bool r = raw ?? IsRaw(line);
        var slot = _slots[line];
        var cached = r ? slot.Raw : slot.Preview;
        string text = Document[line];
        if (cached is not null && cached.Matches(text, r, _sourceMode, _textWidth)) return cached;

        var built = LineLayout.Build(text, r, _sourceMode, _textWidth, _theme);
        if (r) slot.Raw = built;
        else slot.Preview = built;
        return built;
    }

    private LineLayout? CachedLayout(int line)
    {
        bool r = IsRaw(line);
        var slot = _slots[line];
        var cached = r ? slot.Raw : slot.Preview;
        return cached is not null && cached.Matches(Document[line], r, _sourceMode, _textWidth) ? cached : null;
    }

    private float EstimatedLineHeight => _theme.Regular.GetHeight(_theme.BaseSize) + _theme.LineGap + 4f;

    /// <summary>
    /// Positions every line. Lines near the viewport get real layouts; the rest use cached or estimated heights.
    /// </summary>
    private void UpdateLayout()
    {
        _textWidth = Mathf.Max(80f, Size.X - _theme.PadLeft - _theme.PadRight - 12f);
        float viewTop = _scroll - 300f;
        float viewBottom = _scroll + Size.Y + 300f;
        float est = EstimatedLineHeight;
        float charW = _theme.BaseSize * 0.5f;

        float y = _theme.PadTop;
        for (int i = 0; i < _slots.Count; i++)
        {
            var slot = _slots[i];
            slot.Top = y;
            var lay = CachedLayout(i);
            if (lay is null)
            {
                int len = Document[i].Length;
                float guess = est * Mathf.Max(1f, Mathf.Ceil(len * charW / _textWidth));
                if (y + guess >= viewTop && y <= viewBottom) lay = GetLayout(i);
                else
                {
                    slot.Height = guess;
                    y += guess;
                    continue;
                }
            }
            slot.Height = lay.Height;
            y += lay.Height;
        }
        _contentHeight = y + _theme.PadBottom;
        SyncScrollbar();
    }

    private void SyncScrollbar()
    {
        _scroll = Mathf.Clamp(_scroll, 0f, Mathf.Max(0f, _contentHeight - Size.Y));
        _syncingScroll = true;
        _vbar.MaxValue = _contentHeight;
        _vbar.Page = Size.Y;
        _vbar.Value = _scroll;
        _vbar.Visible = _contentHeight > Size.Y + 1f;
        _syncingScroll = false;
    }

    private int LineAtContentY(float y)
    {
        int lo = 0, hi = _slots.Count - 1;
        while (lo < hi)
        {
            int mid = (lo + hi + 1) / 2;
            if (_slots[mid].Top <= y) lo = mid;
            else hi = mid - 1;
        }
        return lo;
    }

    // ------------------------------------------------------------------
    // Drawing
    // ------------------------------------------------------------------

    public override void _Draw()
    {
        DrawRect(new Rect2(Vector2.Zero, Size), _theme.Background);
        UpdateLayout();

        float viewBottom = _scroll + Size.Y;
        bool hasSel = HasSelection && HasFocus();
        var selA = SelStart;
        var selB = SelEnd;

        for (int i = LineAtContentY(_scroll); i < _slots.Count; i++)
        {
            var slot = _slots[i];
            if (slot.Top > viewBottom) break;
            var lay = GetLayout(i);
            var origin = new Vector2(_theme.PadLeft, slot.Top - _scroll);
            DrawBlock(i, lay, origin, hasSel, selA, selB);
        }

        UpdateCaretRect();
        _caretLayer.QueueRedraw();
    }

    /// <summary>The area each colored span covers on each wrapped row (with a little padding).</summary>
    private static List<(int Span, Rect2 Rect)>? SpanBoxes(LineLayout lay, Vector2 textOrigin)
    {
        if (lay.Parsed.Colors.Length == 0 || lay.ColorOf.Length == 0) return null;
        var bounds = new Dictionary<(int Span, int Line), (float X0, float X1)>();
        foreach (ref readonly var g in lay.Glyphs.AsSpan())
        {
            int span = g.Char < lay.ColorOf.Length ? lay.ColorOf[g.Char] : -1;
            if (span < 0) continue;
            var key = (span, g.Line);
            float x0 = g.Pos.X, x1 = g.Pos.X + g.Advance;
            bounds[key] = bounds.TryGetValue(key, out var b) ? (Math.Min(b.X0, x0), Math.Max(b.X1, x1)) : (x0, x1);
        }
        var result = new List<(int, Rect2)>(bounds.Count);
        foreach (var ((span, line), (x0, x1)) in bounds)
        {
            var vl = lay.Lines[line];
            result.Add((span, new Rect2(textOrigin.X + x0 - 3f, textOrigin.Y + vl.Top + 1f, x1 - x0 + 6f, vl.Height - 2f)));
        }
        return result;
    }

    private void DrawBlock(int line, LineLayout lay, Vector2 origin, bool hasSel, TextPos selA, TextPos selB)
    {
        var textOrigin = origin + new Vector2(lay.ContentX, lay.TextTop);
        var styles = lay.Styles;
        bool heading = lay.Parsed.Kind == BlockKind.Heading && !_sourceMode;
        bool checkedItem = lay.Parsed.Kind == BlockKind.Checkbox && lay.Parsed.Checked && !lay.Raw;

        // Colored spans: one box per span per wrapped row, for the fill and the outline.
        var colorBoxes = SpanBoxes(lay, textOrigin);
        if (colorBoxes is not null)
            foreach (var (span, rect) in colorBoxes)
                if (Sheets.SheetGrid.Parse(lay.Parsed.Colors[span].Fill) is { } fill)
                    DrawStyleBox(AppTheme.Box(fill, 3), rect);

        // Code backgrounds
        foreach (ref readonly var g in lay.Glyphs.AsSpan())
        {
            if (styles.Length == 0 || (styles[g.Char] & InlineStyle.Code) == 0) continue;
            var vl = lay.Lines[g.Line];
            DrawRect(new Rect2(textOrigin.X + g.Pos.X, textOrigin.Y + vl.Top, g.Advance, vl.Ascent + vl.Descent - _theme.LineGap + 2f),
                _theme.CodeBackground);
        }

        // Selection
        if (hasSel && line >= selA.Line && line <= selB.Line)
        {
            int rawFrom = line == selA.Line ? selA.Col : 0;
            int rawTo = line == selB.Line ? selB.Col : lay.Source.Length;
            int dFrom = lay.RawToDisplay[Math.Clamp(rawFrom, 0, lay.RawToDisplay.Length - 1)];
            int dTo = lay.RawToDisplay[Math.Clamp(rawTo, 0, lay.RawToDisplay.Length - 1)];
            for (int v = 0; v < lay.Lines.Length; v++)
            {
                var vl = lay.Lines[v];
                bool lastVisual = v == lay.Lines.Length - 1;
                bool newlineSelected = lastVisual && line < selB.Line;
                int from = Math.Max(dFrom, vl.Start);
                int to = Math.Min(dTo, vl.End);
                if (from > to || (from == to && !newlineSelected)) continue;
                float x0 = from >= vl.End ? vl.EndX : lay.CaretX[from];
                float x1 = to >= vl.End ? vl.EndX : lay.CaretX[to];
                if (newlineSelected) x1 += _theme.BaseSize * 0.4f;
                DrawRect(new Rect2(textOrigin.X + x0, textOrigin.Y + vl.Top, x1 - x0, vl.Height), _theme.Selection);
            }
        }

        // Text
        var ts = TextServerManager.GetPrimaryInterface();
        var canvas = GetCanvasItem();
        foreach (ref readonly var g in lay.Glyphs.AsSpan())
        {
            var style = styles.Length > 0 ? styles[g.Char] : InlineStyle.None;
            int spanIndex = lay.ColorOf.Length > g.Char ? lay.ColorOf[g.Char] : -1;
            Color? spanColor = spanIndex >= 0 ? Sheets.SheetGrid.Parse(lay.Parsed.Colors[spanIndex].Text) : null;
            Color color =
                (style & InlineStyle.Marker) != 0 ? _theme.Dim :
                spanColor is { } custom ? custom :
                (style & InlineStyle.Code) != 0 ? _theme.Code :
                checkedItem ? _theme.Dim :
                heading ? _theme.Heading :
                _theme.Text;

            var pos = textOrigin + g.Pos;
            ts.FontDrawGlyph(g.Font, canvas, g.Size, pos, g.Index, color);

            if ((style & (InlineStyle.Underline | InlineStyle.Strike)) != 0 && (style & InlineStyle.Marker) == 0)
            {
                var vl = lay.Lines[g.Line];
                float baseline = textOrigin.Y + vl.Top + vl.Ascent;
                float x0 = textOrigin.X + g.Pos.X;
                float x1 = x0 + g.Advance;
                float thickness = Mathf.Max(1f, g.Size / 14f);
                if ((style & InlineStyle.Underline) != 0)
                    DrawLine(new Vector2(x0, baseline + 2f), new Vector2(x1, baseline + 2f), color, thickness);
                if ((style & InlineStyle.Strike) != 0)
                {
                    float y = baseline - vl.Ascent * 0.32f;
                    DrawLine(new Vector2(x0, y), new Vector2(x1, y), color, thickness);
                }
            }
        }

        if (colorBoxes is not null)
            foreach (var (span, rect) in colorBoxes)
                if (Sheets.SheetGrid.Parse(lay.Parsed.Colors[span].Outline) is { } outline)
                    DrawStyleBox(AppTheme.Box(new Color(0, 0, 0, 0), 3, 0, 0, outline, 1), rect);

        // Block decorations
        if (lay.ShowsBullet)
            DrawCircle(origin + lay.BulletCenter, 3f, _theme.Dim);

        if (lay.ShowsCheckbox)
        {
            var box = new Rect2(origin + lay.CheckboxRect.Position, lay.CheckboxRect.Size);
            float hover = _checkHover.TryGetValue(line, out var h) ? h : 0f;

            if (hover > 0.001f)
            {
                var halo = _theme.CheckboxHalo;
                _haloStyle.BgColor = new Color(halo.R, halo.G, halo.B, halo.A * hover);
                _haloStyle.Draw(canvas, box.Grow(4f));
            }

            if (lay.Parsed.Checked)
            {
                var fill = _theme.CheckboxFill.Lerp(_theme.CheckboxFillHover, hover);
                _checkStyle.BgColor = fill;
                _checkStyle.BorderColor = fill;
                _checkStyle.Draw(canvas, box);
                var s = box.Size;
                var p = box.Position;
                DrawPolyline(new[]
                {
                    p + new Vector2(s.X * 0.24f, s.Y * 0.52f),
                    p + new Vector2(s.X * 0.43f, s.Y * 0.70f),
                    p + new Vector2(s.X * 0.76f, s.Y * 0.32f),
                }, _theme.CheckMark, 1.75f, true);
            }
            else
            {
                _checkStyle.BgColor = Colors.Transparent;
                _checkStyle.BorderColor = _theme.CheckboxBorder.Lerp(_theme.CheckboxBorderHover, hover);
                _checkStyle.Draw(canvas, box);
            }
        }
    }

    private void UpdateCaretRect()
    {
        _caretRectValid = false;
        if (!HasFocus() || _caret.Line >= _slots.Count) return;
        var slot = _slots[_caret.Line];
        var lay = GetLayout(_caret.Line);
        int d = lay.RawToDisplay[Math.Clamp(_caret.Col, 0, lay.RawToDisplay.Length - 1)];
        var vl = lay.Lines[lay.VisualLineOf[d]];
        float x = _theme.PadLeft + lay.ContentX + lay.CaretX[d];
        float y = slot.Top - _scroll + lay.TextTop + vl.Top;
        _caretRect = new Rect2(Mathf.Round(x), y, 2f, vl.Ascent + vl.Descent - _theme.LineGap);
        _caretRectValid = true;
    }

    private void ResetBlink()
    {
        _blinkOn = true;
        if (HasFocus()) _blink?.Start();
        _caretLayer?.QueueRedraw();
    }

    private void EnsureCaretVisible()
    {
        UpdateLayout();
        var slot = _slots[_caret.Line];
        var lay = GetLayout(_caret.Line, raw: true);
        int d = lay.RawToDisplay[Math.Clamp(_caret.Col, 0, lay.RawToDisplay.Length - 1)];
        var vl = lay.Lines[lay.VisualLineOf[d]];
        float top = slot.Top + lay.TextTop + vl.Top;
        float bottom = top + vl.Height;
        const float margin = 24f;
        _glide.Stop();
        if (top - margin < _scroll) _scroll = top - margin;
        else if (bottom + margin > _scroll + Size.Y) _scroll = bottom + margin - Size.Y;
        SyncScrollbar();
        QueueRedraw();
    }

    // ------------------------------------------------------------------
    // Hit testing
    // ------------------------------------------------------------------

    private TextPos PosFromPoint(Vector2 point, out bool onCheckbox)
    {
        UpdateLayout();
        float y = point.Y + _scroll;
        int line = LineAtContentY(y);
        var slot = _slots[line];
        var lay = GetLayout(line);
        var local = new Vector2(point.X - _theme.PadLeft, y - slot.Top);

        onCheckbox = !lay.Raw && lay.ShowsCheckbox && lay.CheckboxHitRect.HasPoint(local);

        if (y < slot.Top) return new TextPos(line, 0);
        int v = lay.VisualLineAtY(local.Y);
        int d = lay.IndexAt(v, local.X - lay.ContentX);
        return new TextPos(line, lay.DisplayToRaw[d]);
    }

    // ------------------------------------------------------------------
    // Checkbox hover animation
    // ------------------------------------------------------------------

    private void SetCheckboxHover(int line)
    {
        if (line == _hoverCheckLine) return;
        _hoverCheckLine = line;
        if (line >= 0 && !_checkHover.ContainsKey(line)) _checkHover[line] = 0f;
        SetProcess(true);
    }

    public override void _Process(double delta)
    {
        float dt = (float)delta;
        bool animating = false;
        if (_glide.Active)
        {
            _scroll = _glide.Step(_scroll, dt);
            SyncScrollbar();
            animating |= _glide.Active;
        }
        List<int>? finished = null;
        foreach (var line in new List<int>(_checkHover.Keys))
        {
            float target = line == _hoverCheckLine ? 1f : 0f;
            float v = _checkHover[line];
            v = v < target ? Mathf.Min(target, v + dt / FadeIn) : Mathf.Max(target, v - dt / FadeOut);
            _checkHover[line] = v;
            if (v != target) animating = true;
            else if (target == 0f) (finished ??= new List<int>()).Add(line);
        }
        if (finished is not null) foreach (var line in finished) _checkHover.Remove(line);
        QueueRedraw();
        if (!animating) SetProcess(false);
    }

    // Godot's C# binding returns the cursor shape as an int.
    public override int _GetCursorShape(Vector2 atPosition)
        => (int)(_hoverCheckLine >= 0 ? CursorShape.PointingHand : CursorShape.Ibeam);

    // ------------------------------------------------------------------
    // Input
    // ------------------------------------------------------------------

    public override void _GuiInput(InputEvent @event)
    {
        switch (@event)
        {
            case InputEventMouseButton mb:
                HandleMouseButton(mb);
                break;
            case InputEventMouseMotion mm when _dragging && (mm.ButtonMask & MouseButtonMask.Left) != 0:
                _caret = PosFromPoint(mm.Position, out _);
                EnsureCaretVisible();
                AcceptEvent();
                break;
            case InputEventMouseMotion mm:
                var hovered = PosFromPoint(mm.Position, out bool overBox);
                SetCheckboxHover(overBox ? hovered.Line : -1);
                break;
            case InputEventKey key when key.Pressed:
                if (HandleKey(key))
                {
                    ResetBlink();
                    AcceptEvent();
                }
                break;
        }
    }

    private void HandleMouseButton(InputEventMouseButton mb)
    {
        if (mb.ButtonIndex is MouseButton.WheelUp or MouseButton.WheelDown)
        {
            if (!mb.Pressed) return;
            float factor = mb.Factor > 0 ? mb.Factor : 1f;
            _glide.Push(_scroll, (mb.ButtonIndex == MouseButton.WheelUp ? -1f : 1f) * EstimatedLineHeight * 3f * factor,
                _contentHeight - Size.Y);
            SetProcess(true);
            AcceptEvent();
            return;
        }

        if (mb.ButtonIndex == MouseButton.Right && mb.Pressed)
        {
            // Right-clicking outside the selection moves the caret there first, like most editors.
            var at = PosFromPoint(mb.Position, out _);
            if (!HasFocus()) GrabFocus();
            bool insideSelection = HasSelection && at >= SelStart && at <= SelEnd;
            if (!insideSelection) _caret = _anchor = at;
            ResetBlink();
            QueueRedraw();
            ShowContextMenu();
            AcceptEvent();
            return;
        }

        if (mb.ButtonIndex != MouseButton.Left) return;

        if (!mb.Pressed)
        {
            _dragging = false;
            return;
        }

        // Hit-test against what the user sees *before* focusing, since focusing changes which lines are raw.
        var pos = PosFromPoint(mb.Position, out bool onCheckbox);
        if (!HasFocus()) GrabFocus();

        if (onCheckbox)
        {
            ToggleCheckbox(pos.Line, reveal: false);
            AcceptEvent();
            return;
        }

        Document.BreakUndoGroup();
        _goalX = null;
        if (mb.DoubleClick)
        {
            SelectWord(pos);
        }
        else
        {
            _caret = pos;
            if (!mb.ShiftPressed) _anchor = pos;
            _dragging = true;
        }
        ResetBlink();
        QueueRedraw();
        AcceptEvent();
    }

    private bool HandleKey(InputEventKey k)
    {
        bool ctrl = k.IsCommandOrControlPressed();
        bool shift = k.ShiftPressed;

        switch (k.Keycode)
        {
            case Key.Left:
                if (HasSelection && !shift) { MoveTo(SelStart, false); return true; }
                MoveTo(ctrl ? WordLeft(_caret) : CharLeft(_caret), shift);
                return true;
            case Key.Right:
                if (HasSelection && !shift) { MoveTo(SelEnd, false); return true; }
                MoveTo(ctrl ? WordRight(_caret) : CharRight(_caret), shift);
                return true;
            case Key.Up:
                MoveVertical(-1, shift);
                return true;
            case Key.Down:
                MoveVertical(1, shift);
                return true;
            case Key.Pageup:
            case Key.Pagedown:
            {
                int steps = Math.Max(1, (int)(Size.Y / EstimatedLineHeight) - 1);
                for (int i = 0; i < steps; i++) MoveVertical(k.Keycode == Key.Pageup ? -1 : 1, shift);
                return true;
            }
            case Key.Home:
            {
                if (ctrl) { MoveTo(new TextPos(0, 0), shift); return true; }
                int contentStart = MarkupParser.Parse(Document[_caret.Line]).ContentStart;
                MoveTo(new TextPos(_caret.Line, _caret.Col == contentStart ? 0 : contentStart), shift);
                return true;
            }
            case Key.End:
                MoveTo(ctrl ? Document.End : new TextPos(_caret.Line, Document[_caret.Line].Length), shift);
                return true;

            case Key.Backspace:
                if (HasSelection) { ReplaceSelection("", false); return true; }
                DeleteTo(ctrl ? WordLeft(_caret) : CharLeft(_caret), !ctrl);
                return true;
            case Key.Delete:
                if (HasSelection) { ReplaceSelection("", false); return true; }
                DeleteTo(ctrl ? WordRight(_caret) : CharRight(_caret), false);
                return true;

            case Key.Enter:
            case Key.KpEnter:
                if (ctrl) ToggleCheckbox(_caret.Line);
                else InsertNewline();
                return true;
            case Key.Tab:
                IndentLine(shift);
                return true;
            case Key.Escape:
                if (!HasSelection) return false;
                _anchor = _caret;
                QueueRedraw();
                return true;
        }

        if (ctrl)
        {
            switch (k.Keycode)
            {
                case Key.A:
                    _anchor = new TextPos(0, 0);
                    _caret = Document.End;
                    QueueRedraw();
                    return true;
                case Key.C:
                    if (HasSelection) DisplayServer.ClipboardSet(Document.GetRange(_anchor, _caret));
                    return true;
                case Key.X:
                    if (HasSelection)
                    {
                        DisplayServer.ClipboardSet(Document.GetRange(_anchor, _caret));
                        ReplaceSelection("", false);
                    }
                    return true;
                case Key.V:
                    ReplaceSelection(DisplayServer.ClipboardGet(), false);
                    return true;
                case Key.Z:
                    ApplyUndo(shift ? Document.Redo() : Document.Undo());
                    return true;
                case Key.Y:
                    ApplyUndo(Document.Redo());
                    return true;
                case Key.B:
                    ApplyInline("*");
                    return true;
                case Key.I:
                    ApplyInline("//");
                    return true;
                case Key.U:
                    ApplyInline("_");
                    return true;
            }
            return false;
        }

        long unicode = k.Unicode;
        bool validChar = unicode >= 32 && unicode <= 0x10FFFF && unicode is < 0xD800 or > 0xDFFF && unicode != 127;
        if (validChar && !k.AltPressed)
        {
            ReplaceSelection(char.ConvertFromUtf32((int)unicode), mergeable: true);
            return true;
        }
        return false;
    }

    // ------------------------------------------------------------------
    // Editing
    // ------------------------------------------------------------------

    private void ReplaceSelection(string text, bool mergeable)
    {
        _caret = _anchor = Document.Replace(SelStart, SelEnd, text, _caret, mergeable);
        AfterEdit();
    }

    private void DeleteTo(TextPos target, bool mergeable)
    {
        if (target == _caret) return;
        _caret = _anchor = Document.Replace(target, _caret, "", _caret, mergeable);
        AfterEdit();
    }

    private void AfterEdit(bool reveal = true)
    {
        _goalX = null;
        ResetBlink();
        if (reveal) EnsureCaretVisible();
        else QueueRedraw();
        TextEdited?.Invoke();
    }

    private void ApplyUndo(TextPos? pos)
    {
        if (pos is not { } p) return;
        _caret = _anchor = Document.Clamp(p);
        AfterEdit();
    }

    /// <summary>Enter continues a list; Enter on an empty list item ends the list.</summary>
    private void InsertNewline()
    {
        if (!HasSelection)
        {
            string line = Document[_caret.Line];
            var parsed = MarkupParser.Parse(line);
            if (parsed.Kind is BlockKind.Bullet or BlockKind.Checkbox && _caret.Col >= parsed.ContentStart)
            {
                if (line.Length == parsed.ContentStart)
                {
                    _caret = _anchor = Document.Replace(new TextPos(_caret.Line, 0), new TextPos(_caret.Line, line.Length), "", _caret);
                    AfterEdit();
                    return;
                }
                string prefix = line.Substring(0, parsed.IndentLength) + (parsed.Kind == BlockKind.Bullet ? "- " : "= ");
                ReplaceSelection("\n" + prefix, false);
                return;
            }
        }
        ReplaceSelection("\n", false);
    }

    /// <summary>Tab indents a list item by two spaces (Shift+Tab outdents); elsewhere it inserts a tab.</summary>
    private void IndentLine(bool outdent)
    {
        string line = Document[_caret.Line];
        var parsed = MarkupParser.Parse(line);
        if (parsed.Kind is not (BlockKind.Bullet or BlockKind.Checkbox))
        {
            if (!outdent) ReplaceSelection("\t", false);
            return;
        }

        var lineStart = new TextPos(_caret.Line, 0);
        int delta;
        if (outdent)
        {
            int remove = Math.Min(2, parsed.IndentLength);
            if (remove == 0) return;
            Document.Replace(lineStart, new TextPos(_caret.Line, remove), "", _caret);
            delta = -remove;
        }
        else
        {
            Document.Replace(lineStart, lineStart, "  ", _caret);
            delta = 2;
        }
        _caret = new TextPos(_caret.Line, Math.Max(0, _caret.Col + delta));
        _anchor = _anchor.Line == _caret.Line ? new TextPos(_anchor.Line, Math.Max(0, _anchor.Col + delta)) : _anchor;
        AfterEdit();
    }

    /// <summary>Switches "= " and "=x " on a checkbox line.</summary>
    private void ToggleCheckbox(int lineIndex, bool reveal = true)
    {
        string line = Document[lineIndex];
        var parsed = MarkupParser.Parse(line);
        if (parsed.Kind != BlockKind.Checkbox) return;

        string newPrefix = parsed.Checked ? "= " : "=x ";
        int delta = newPrefix.Length - parsed.PrefixLength;
        var a = new TextPos(lineIndex, parsed.IndentLength);
        var b = new TextPos(lineIndex, parsed.ContentStart);
        var caretBefore = _caret;
        Document.Replace(a, b, newPrefix, caretBefore);

        TextPos Shift(TextPos p) => p.Line == lineIndex && p.Col >= parsed.ContentStart ? new TextPos(p.Line, p.Col + delta) : p;
        _caret = Shift(_caret);
        _anchor = Shift(_anchor);
        Document.BreakUndoGroup();
        AfterEdit(reveal);
    }

    private void SelectWord(TextPos pos)
    {
        string line = Document[pos.Line];
        int start = pos.Col, end = pos.Col;
        while (start > 0 && IsWordChar(line[start - 1])) start--;
        while (end < line.Length && IsWordChar(line[end])) end++;
        _anchor = new TextPos(pos.Line, start);
        _caret = new TextPos(pos.Line, end);
    }

    // ------------------------------------------------------------------
    // Caret movement
    // ------------------------------------------------------------------

    private void MoveTo(TextPos p, bool extend)
    {
        _caret = Document.Clamp(p);
        if (!extend) _anchor = _caret;
        _goalX = null;
        Document.BreakUndoGroup();
        EnsureCaretVisible();
    }

    private void MoveVertical(int dir, bool extend)
    {
        var lay = GetLayout(_caret.Line, raw: true);
        int d = lay.RawToDisplay[Math.Clamp(_caret.Col, 0, lay.RawToDisplay.Length - 1)];
        int v = lay.VisualLineOf[d];
        float goal = _goalX ?? lay.ContentX + lay.CaretX[d];

        TextPos target;
        int nv = v + dir;
        if (nv >= 0 && nv < lay.Lines.Length)
        {
            target = new TextPos(_caret.Line, lay.DisplayToRaw[lay.IndexAt(nv, goal - lay.ContentX)]);
        }
        else
        {
            int newLine = _caret.Line + dir;
            if (newLine < 0) target = new TextPos(0, 0);
            else if (newLine >= Document.LineCount) target = Document.End;
            else
            {
                var next = GetLayout(newLine, raw: true);
                int tv = dir < 0 ? next.Lines.Length - 1 : 0;
                target = new TextPos(newLine, next.DisplayToRaw[next.IndexAt(tv, goal - next.ContentX)]);
            }
        }

        _caret = Document.Clamp(target);
        if (!extend) _anchor = _caret;
        _goalX = goal;
        Document.BreakUndoGroup();
        EnsureCaretVisible();
    }

    private static bool IsWordChar(char c) => char.IsLetterOrDigit(c) || c == '_';

    private TextPos CharLeft(TextPos p)
    {
        if (p.Col > 0)
        {
            string line = Document[p.Line];
            int c = p.Col - 1;
            if (c > 0 && char.IsLowSurrogate(line[c]) && char.IsHighSurrogate(line[c - 1])) c--;
            return new TextPos(p.Line, c);
        }
        return p.Line > 0 ? new TextPos(p.Line - 1, Document[p.Line - 1].Length) : p;
    }

    private TextPos CharRight(TextPos p)
    {
        string line = Document[p.Line];
        if (p.Col < line.Length)
        {
            int c = p.Col + 1;
            if (c < line.Length && char.IsLowSurrogate(line[c]) && char.IsHighSurrogate(line[c - 1])) c++;
            return new TextPos(p.Line, c);
        }
        return p.Line < Document.LineCount - 1 ? new TextPos(p.Line + 1, 0) : p;
    }

    private TextPos WordLeft(TextPos p)
    {
        if (p.Col == 0) return CharLeft(p);
        string line = Document[p.Line];
        int c = p.Col;
        while (c > 0 && char.IsWhiteSpace(line[c - 1])) c--;
        if (c > 0 && IsWordChar(line[c - 1])) while (c > 0 && IsWordChar(line[c - 1])) c--;
        else if (c > 0) c--;
        return new TextPos(p.Line, c);
    }

    private TextPos WordRight(TextPos p)
    {
        string line = Document[p.Line];
        if (p.Col == line.Length) return CharRight(p);
        int c = p.Col;
        if (IsWordChar(line[c])) while (c < line.Length && IsWordChar(line[c])) c++;
        else c++;
        while (c < line.Length && char.IsWhiteSpace(line[c])) c++;
        return new TextPos(p.Line, c);
    }
}
