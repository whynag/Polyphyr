using Godot;

namespace Polyphyr.UI.Editor;

/// <summary>
/// Draws only the blinking caret, on top of the editor. Blinking redraws this tiny layer
/// instead of re-drawing all the text twice a second.
/// </summary>
public partial class CaretLayer : Control
{
    public NoteEditor? Editor { get; set; }

    public override void _Draw()
    {
        if (Editor is { } e && e.CaretVisible)
            DrawRect(e.CaretRect, e.CaretColor);
    }
}
