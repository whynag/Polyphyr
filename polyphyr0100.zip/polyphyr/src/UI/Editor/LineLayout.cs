using System;
using System.Collections.Generic;
using System.Text;
using Godot;
using Polyphyr.Core.Text;

namespace Polyphyr.UI.Editor;

/// <summary>One wrapped row of text inside a line's layout.</summary>
internal struct VisualLine
{
    public float Top;
    public float Ascent;
    public float Descent;
    /// <summary>Display-text range [Start, End).</summary>
    public int Start;
    public int End;
    public float EndX;
    public float Height => Ascent + Descent;
}

/// <summary>A glyph ready to draw, with its position relative to the text origin.</summary>
internal struct GlyphInfo
{
    public Rid Font;
    public int Size;
    public long Index;
    public Vector2 Pos;
    public float Advance;
    /// <summary>Display-text index of the character this glyph draws.</summary>
    public int Char;
    public int Line;
}

/// <summary>
/// The shaped, wrapped layout of one document line, either as raw text (being edited)
/// or as formatted preview. Built once and cached until the line, width or mode changes.
/// Holds only plain arrays, so drawing never calls back into the text engine except to draw glyphs.
/// </summary>
internal sealed class LineLayout
{
    public string Source = "";
    public bool Raw;
    public bool SourceMode;
    public float Width;

    public ParsedLine Parsed = null!;
    public string Display = "";
    public InlineStyle[] Styles = Array.Empty<InlineStyle>();
    /// <summary>Index into <c>Parsed.Colors</c> for each display character, or -1. Length Display.Length.</summary>
    public int[] ColorOf = Array.Empty<int>();
    /// <summary>Display index → raw column. Length Display.Length + 1.</summary>
    public int[] DisplayToRaw = Array.Empty<int>();
    /// <summary>Raw column → display index. Length Source.Length + 1.</summary>
    public int[] RawToDisplay = Array.Empty<int>();

    public float ContentX;
    public float TextTop;
    public float Height;
    public VisualLine[] Lines = Array.Empty<VisualLine>();
    public GlyphInfo[] Glyphs = Array.Empty<GlyphInfo>();
    /// <summary>Caret x (relative to ContentX) before each display index. Length Display.Length + 1.</summary>
    public float[] CaretX = Array.Empty<float>();
    /// <summary>Visual line holding each display index. Length Display.Length + 1.</summary>
    public int[] VisualLineOf = Array.Empty<int>();

    public Rect2 CheckboxRect;
    /// <summary>Clickable area for the checkbox: larger than the box itself, covering the gap up to the text.</summary>
    public Rect2 CheckboxHitRect;
    public Vector2 BulletCenter;
    public bool ShowsBullet;
    public bool ShowsCheckbox;

    public bool Matches(string source, bool raw, bool sourceMode, float width)
        => Raw == raw && SourceMode == sourceMode && Width == width && Source == source;

    public float XOf(int displayIndex)
    {
        var vl = Lines[VisualLineOf[displayIndex]];
        return displayIndex == vl.End ? vl.EndX : CaretX[displayIndex];
    }

    /// <summary>Closest display index to x on a visual line.</summary>
    public int IndexAt(int visualLine, float x)
    {
        var vl = Lines[visualLine];
        bool last = visualLine == Lines.Length - 1;
        int maxIndex = last ? vl.End : Math.Max(vl.Start, vl.End - 1);
        int best = vl.Start;
        float bestDist = float.MaxValue;
        for (int i = vl.Start; i <= maxIndex; i++)
        {
            float cx = i == vl.End ? vl.EndX : CaretX[i];
            float d = Math.Abs(cx - x);
            if (d < bestDist) { bestDist = d; best = i; }
        }
        return best;
    }

    public int VisualLineAtY(float y)
    {
        for (int i = 0; i < Lines.Length; i++)
            if (y < TextTop + Lines[i].Top + Lines[i].Height) return i;
        return Lines.Length - 1;
    }

    // ------------------------------------------------------------------
    // Building
    // ------------------------------------------------------------------

    private static TextServer? _ts;
    private static TextServer Ts => _ts ??= TextServerManager.GetPrimaryInterface();

    public static LineLayout Build(string source, bool raw, bool sourceMode, float width, EditorTheme theme)
    {
        var parsed = MarkupParser.Parse(source);
        var lay = new LineLayout
        {
            Source = source,
            Raw = raw,
            SourceMode = sourceMode,
            Width = width,
            Parsed = parsed,
        };

        bool heading = parsed.Kind == BlockKind.Heading && !sourceMode;
        int fontSize = theme.SizeFor(heading ? parsed.HeadingLevel : 0, sourceMode);

        BuildDisplay(lay, source, parsed, raw);

        // Block decorations (bullets, checkboxes, indent) only in preview.
        if (!raw && !sourceMode)
        {
            float space = theme.Regular.GetStringSize(" ", HorizontalAlignment.Left, -1, theme.BaseSize).X;
            float indentPx = 0;
            for (int i = 0; i < parsed.IndentLength; i++) indentPx += source[i] == '\t' ? space * 4 : space;

            float lineH = theme.Regular.GetHeight(fontSize);
            switch (parsed.Kind)
            {
                case BlockKind.Bullet:
                    lay.ShowsBullet = true;
                    lay.BulletCenter = new Vector2(indentPx + theme.BulletWidth * 0.4f, lineH * 0.5f);
                    lay.ContentX = indentPx + theme.BulletWidth;
                    break;
                case BlockKind.Checkbox:
                    float box = Mathf.Round(theme.BaseSize * 0.95f);
                    lay.ShowsCheckbox = true;
                    lay.CheckboxRect = new Rect2(indentPx + 1f, (lineH - box) * 0.5f, box, box);
                    lay.ContentX = indentPx + theme.CheckboxWidth;
                    break;
                default:
                    lay.ContentX = indentPx;
                    break;
            }
        }

        var (padTop, padBottom) = theme.BlockPadding(heading ? parsed.HeadingLevel : 0, sourceMode);
        lay.TextTop = padTop;
        Shape(lay, theme, fontSize, heading, sourceMode);
        float textHeight = 0;
        foreach (var vl in lay.Lines) textHeight = vl.Top + vl.Height;
        lay.Height = padTop + textHeight + padBottom;

        // Decorations are positioned relative to the first visual line.
        lay.BulletCenter += new Vector2(0, padTop);
        lay.CheckboxRect.Position += new Vector2(0, padTop);

        if (lay.ShowsCheckbox)
        {
            const float slack = 8f;
            var first = lay.Lines[0];
            float left = lay.CheckboxRect.Position.X - slack;
            float top = Mathf.Min(lay.CheckboxRect.Position.Y, padTop) - slack * 0.5f;
            float bottom = Mathf.Max(lay.CheckboxRect.End.Y, padTop + first.Height) + slack * 0.5f;
            lay.CheckboxHitRect = new Rect2(left, top, lay.ContentX + 2f - left, bottom - top);
        }
        return lay;
    }

    private static void BuildDisplay(LineLayout lay, string source, ParsedLine parsed, bool raw)
    {
        // Which color span (if any) each raw character's content belongs to.
        var rawColor = new int[source.Length];
        Array.Fill(rawColor, -1);
        for (int k = 0; k < parsed.Colors.Length; k++)
            for (int i = parsed.Colors[k].Start; i < parsed.Colors[k].End; i++) rawColor[i] = k;

        if (raw)
        {
            lay.Display = source;
            lay.Styles = parsed.Styles;
            lay.ColorOf = rawColor;
            lay.DisplayToRaw = new int[source.Length + 1];
            lay.RawToDisplay = new int[source.Length + 1];
            for (int i = 0; i <= source.Length; i++) lay.DisplayToRaw[i] = lay.RawToDisplay[i] = i;
            return;
        }

        // Preview: drop the indent, block prefix and all inline markers.
        var sb = new StringBuilder(source.Length);
        var d2r = new List<int>(source.Length + 1);
        var styles = new List<InlineStyle>(source.Length);
        var colors = new List<int>(source.Length);
        for (int i = parsed.ContentStart; i < source.Length; i++)
        {
            if ((parsed.Styles[i] & InlineStyle.Marker) != 0) continue;
            sb.Append(source[i]);
            d2r.Add(i);
            styles.Add(parsed.Styles[i]);
            colors.Add(rawColor[i]);
        }
        d2r.Add(source.Length);

        lay.Display = sb.ToString();
        lay.Styles = styles.ToArray();
        lay.ColorOf = colors.ToArray();
        lay.DisplayToRaw = d2r.ToArray();

        // Each raw column maps to the first display character at or after it.
        var r2d = new int[source.Length + 1];
        int d = 0;
        for (int r = 0; r <= source.Length; r++)
        {
            while (d < lay.DisplayToRaw.Length - 1 && lay.DisplayToRaw[d] < r) d++;
            r2d[r] = d;
        }
        lay.RawToDisplay = r2d;
    }

    private static void Shape(LineLayout lay, EditorTheme theme, int fontSize, bool heading, bool sourceMode)
    {
        string text = lay.Display;
        int n = text.Length;
        lay.CaretX = new float[n + 1];
        lay.VisualLineOf = new int[n + 1];

        if (n == 0)
        {
            var font = sourceMode ? theme.Mono : heading ? theme.Bold : theme.Regular;
            lay.Lines = new[] { new VisualLine { Top = 0, Ascent = font.GetAscent(fontSize), Descent = font.GetDescent(fontSize) + theme.LineGap } };
            return;
        }

        float wrapWidth = Math.Max(40f, lay.Width - lay.ContentX);
        var para = new TextParagraph
        {
            Width = wrapWidth,
            BreakFlags = TextServer.LineBreakFlag.Mandatory | TextServer.LineBreakFlag.WordBound | TextServer.LineBreakFlag.Adaptive,
        };

        // One run per stretch of characters that share a font.
        int runStart = 0;
        var runFont = theme.FontFor(lay.Styles[0], heading, sourceMode);
        for (int i = 1; i <= n; i++)
        {
            var f = i < n ? theme.FontFor(lay.Styles[i], heading, sourceMode) : null;
            if (f == runFont) continue;
            para.AddString(text.Substring(runStart, i - runStart), runFont, fontSize);
            runStart = i;
            if (f is not null) runFont = f;
        }

        // The text engine counts in Unicode code points; C# strings count UTF-16 units.
        // Only build a conversion table if the line actually has characters outside the BMP (e.g. emoji).
        int[]? cpToUtf16 = BuildCodePointMap(text);
        int ToUtf16(int cp) => cpToUtf16 is null ? cp : cpToUtf16[Math.Clamp(cp, 0, cpToUtf16.Length - 1)];

        var ts = Ts;
        int lineCount = para.GetLineCount();
        var lines = new VisualLine[lineCount];
        var glyphs = new List<GlyphInfo>(n);
        var hasX = new bool[n + 1];
        float top = 0;

        for (int li = 0; li < lineCount; li++)
        {
            var range = para.GetLineRange(li);
            float ascent = para.GetLineAscent(li);
            float descent = para.GetLineDescent(li);
            var vl = new VisualLine
            {
                Top = top,
                Ascent = ascent,
                Descent = descent + theme.LineGap,
                Start = ToUtf16(range.X),
                End = ToUtf16(range.Y),
            };

            var rid = para.GetLineRid(li);
            var gl = ts.ShapedTextGetGlyphs(rid);
            float x = 0;
            for (int gi = 0; gi < gl.Count; gi++)
            {
                var g = gl[gi];
                int start = ToUtf16(g["start"].AsInt32());
                int end = ToUtf16(g["end"].AsInt32());
                int repeat = Math.Max(1, g["repeat"].AsInt32());
                float advance = g["advance"].AsSingle();
                var offset = g["offset"].AsVector2();
                var fontRid = g["font_rid"].AsRid();
                int size = g["font_size"].AsInt32();
                long index = g["index"].AsInt64();

                // Caret stops: the first glyph of a cluster owns its start; multi-char clusters are interpolated.
                if (start >= 0 && start < n && !hasX[start])
                {
                    int span = Math.Max(1, end - start);
                    for (int c = start; c < Math.Min(end, n); c++)
                    {
                        if (hasX[c]) continue;
                        lay.CaretX[c] = x + advance * repeat * (c - start) / span;
                        lay.VisualLineOf[c] = li;
                        hasX[c] = true;
                    }
                }

                for (int r = 0; r < repeat; r++)
                {
                    if (fontRid.IsValid)
                    {
                        glyphs.Add(new GlyphInfo
                        {
                            Font = fontRid,
                            Size = size,
                            Index = index,
                            Pos = new Vector2(x + offset.X, top + ascent + offset.Y),
                            Advance = advance,
                            Char = Math.Clamp(start, 0, n - 1),
                            Line = li,
                        });
                    }
                    x += advance;
                }
            }
            vl.EndX = x;
            lines[li] = vl;
            top += vl.Height;
        }

        // Fill caret stops for characters that produced no glyph (e.g. trailing break characters).
        int lastLine = lineCount - 1;
        for (int c = 0; c < n; c++)
        {
            if (hasX[c]) continue;
            int line = 0;
            for (int li = 0; li < lineCount; li++)
                if (c >= lines[li].Start && c < lines[li].End) { line = li; break; }
            lay.VisualLineOf[c] = line;
            lay.CaretX[c] = c > 0 && lay.VisualLineOf[c - 1] == line ? lay.CaretX[c - 1] : 0;
        }
        lay.VisualLineOf[n] = lastLine;
        lay.CaretX[n] = lines[lastLine].EndX;

        lay.Lines = lines;
        lay.Glyphs = glyphs.ToArray();
    }

    private static int[]? BuildCodePointMap(string text)
    {
        bool any = false;
        foreach (char ch in text)
            if (char.IsSurrogate(ch)) { any = true; break; }
        if (!any) return null;

        var map = new List<int>(text.Length + 1);
        for (int i = 0; i < text.Length; i++)
        {
            map.Add(i);
            if (char.IsHighSurrogate(text[i]) && i + 1 < text.Length && char.IsLowSurrogate(text[i + 1])) i++;
        }
        map.Add(text.Length);
        return map.ToArray();
    }
}
