using System;
using System.Collections.Generic;
using System.Linq;
using Godot;
using Polyphyr.Core;

namespace Polyphyr.UI;

/// <summary>
/// Per-computer settings, kept outside any workspace: which workspace was open last,
/// who the person using this computer is, and where the window was. Stored in user://settings.cfg.
/// </summary>
public sealed class AppSettings
{
    private const string FilePath = "user://settings.cfg";
    // Bumped once to discard a window size saved while running inside the editor.
    private const string WindowSection = "window_v3";

    public string WorkspacePath { get; set; } = "";

    /// <summary>Workspaces opened on this computer: folder path → when it was last opened (unix seconds).</summary>
    public Dictionary<string, long> KnownWorkspaces { get; } = new();

    /// <summary>The app was closed while the workspace menu was open, so it reopens there.</summary>
    public bool ShowWorkspaceMenu { get; set; }

    /// <summary>Where new workspaces are created.</summary>
    public static string WorkspacesRoot => ProjectSettings.GlobalizePath("user://workspaces");

    public void RememberWorkspace(string path)
    {
        KnownWorkspaces[path] = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
        WorkspacePath = path;
        Save();
    }
    public UserId UserId { get; set; }
    public string UserName { get; set; } = "";

    /// <summary>False until the person has set their name (pencil next to the Home greeting).</summary>
    public bool NameChosen { get; set; }

    /// <summary>Delete notes without asking ("Don't ask me again" in the delete dialog).</summary>
    public bool SkipDeleteConfirm { get; set; }

    /// <summary>Show dates month-first (mm/dd/yy) instead of dd/mm/yy.</summary>
    public bool MonthFirstDates { get; set; }

    /// <summary>Light mode instead of dark.</summary>
    public bool LightMode { get; set; }

    /// <summary>When each document was last opened on this computer (unix seconds), for Home's recent list.</summary>
    public Dictionary<Guid, long> DocumentOpened { get; } = new();
    private const int MaxRemembered = 100;

    public void TouchDocument(Guid id)
    {
        DocumentOpened[id] = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
        if (DocumentOpened.Count > MaxRemembered)
            foreach (var old in DocumentOpened.OrderBy(p => p.Value).Take(DocumentOpened.Count - MaxRemembered).ToList())
                DocumentOpened.Remove(old.Key);
        Save();
    }

    // ---- Pinned items (shown on Home), in pin order ----

    public enum PinKind { Document, Task, Sheet }

    /// <summary>Pins as "document:guid" / "task:guid".</summary>
    public List<string> Pins { get; } = new();

    private static string PinKey(PinKind kind, Guid id) => kind switch
    {
        PinKind.Document => "document",
        PinKind.Sheet => "sheet",
        _ => "task",
    } + $":{id:N}";

    public bool IsPinned(PinKind kind, Guid id) => Pins.Contains(PinKey(kind, id));

    public void TogglePin(PinKind kind, Guid id)
    {
        string key = PinKey(kind, id);
        if (!Pins.Remove(key)) Pins.Add(key);
        Save();
    }

    public static bool TryParsePin(string pin, out PinKind kind, out Guid id)
    {
        kind = PinKind.Document;
        id = Guid.Empty;
        int colon = pin.IndexOf(':');
        if (colon < 0 || !Guid.TryParse(pin[(colon + 1)..], out id)) return false;
        string k = pin[..colon];
        if (k == "task") kind = PinKind.Task;
        else if (k == "sheet") kind = PinKind.Sheet;
        else if (k != "document") return false;
        return true;
    }

    // ---- Activity per day (for Home's heatmap) ----

    public Dictionary<DateOnly, int> Activity { get; } = new();
    /// <summary>False until activity has been recorded once (then the heatmap is seeded from item dates).</summary>
    public bool HasActivity { get; private set; }
    private bool _activityDirty;
    private const int ActivityDays = 400;

    public void RecordActivity(DateOnly day, int amount = 1)
    {
        Activity[day] = Activity.GetValueOrDefault(day) + amount;
        HasActivity = true;
        _activityDirty = true;
    }

    /// <summary>Saves if activity changed since the last save (called from the autosave timer).</summary>
    public void SaveActivityIfChanged()
    {
        if (_activityDirty) Save();
    }

    public bool HasWindowState { get; set; }
    public Vector2I WindowPosition { get; set; }
    public Vector2I WindowSize { get; set; }
    public bool WindowMaximized { get; set; }

    public static AppSettings Load()
    {
        var s = new AppSettings();
        var cfg = new ConfigFile();
        if (cfg.Load(FilePath) == Error.Ok)
        {
            s.WorkspacePath = cfg.GetValue("workspace", "path", "").AsString();
            s.ShowWorkspaceMenu = cfg.GetValue("workspace", "show_menu", false).AsBool();
            var paths = cfg.GetValue("workspace", "known_paths", Array.Empty<string>()).AsStringArray();
            var times = cfg.GetValue("workspace", "known_opened", Array.Empty<string>()).AsStringArray();
            for (int i = 0; i < paths.Length; i++)
                s.KnownWorkspaces[paths[i]] = i < times.Length && long.TryParse(times[i], out long t) ? t : 0;
            s.UserName = cfg.GetValue("user", "name", "").AsString();
            s.NameChosen = cfg.GetValue("user", "name_chosen", false).AsBool();
            if (Guid.TryParse(cfg.GetValue("user", "id", "").AsString(), out var id)) s.UserId = new UserId(id);
            s.SkipDeleteConfirm = cfg.GetValue("prefs", "skip_delete_confirm", false).AsBool();
            s.MonthFirstDates = cfg.GetValue("prefs", "month_first_dates", false).AsBool();
            s.LightMode = cfg.GetValue("prefs", "light_mode", false).AsBool();

            s.Pins.AddRange(cfg.GetValue("pins", "items", Array.Empty<string>()).AsStringArray());
            if (cfg.HasSection("activity"))
            {
                s.HasActivity = true;
                foreach (var key in cfg.GetSectionKeys("activity"))
                    if (DateOnly.TryParseExact(key, "yyyyMMdd", out var day))
                        s.Activity[day] = cfg.GetValue("activity", key, 0).AsInt32();
            }

            if (cfg.HasSection("recent_documents"))
                foreach (var key in cfg.GetSectionKeys("recent_documents"))
                    if (Guid.TryParse(key, out var doc))
                        s.DocumentOpened[doc] = cfg.GetValue("recent_documents", key, 0L).AsInt64();

            if (cfg.HasSectionKey(WindowSection, "size"))
            {
                s.HasWindowState = true;
                s.WindowSize = cfg.GetValue(WindowSection, "size").AsVector2I();
                s.WindowPosition = cfg.GetValue(WindowSection, "position").AsVector2I();
                s.WindowMaximized = cfg.GetValue(WindowSection, "maximized", false).AsBool();
            }
        }

        if (string.IsNullOrWhiteSpace(s.WorkspacePath))
            s.WorkspacePath = ProjectSettings.GlobalizePath("user://workspaces/My Workspace");
        return s;
    }

    public void Save()
    {
        var cfg = new ConfigFile();
        cfg.SetValue("workspace", "path", WorkspacePath);
        cfg.SetValue("workspace", "show_menu", ShowWorkspaceMenu);
        cfg.SetValue("workspace", "known_paths", KnownWorkspaces.Keys.ToArray());
        cfg.SetValue("workspace", "known_opened", KnownWorkspaces.Values.Select(v => v.ToString()).ToArray());
        cfg.SetValue("user", "name", UserName);
        cfg.SetValue("user", "name_chosen", NameChosen);
        cfg.SetValue("user", "id", UserId.IsEmpty ? "" : UserId.Value.ToString("D"));
        cfg.SetValue("prefs", "skip_delete_confirm", SkipDeleteConfirm);
        cfg.SetValue("prefs", "month_first_dates", MonthFirstDates);
        cfg.SetValue("prefs", "light_mode", LightMode);
        cfg.SetValue("pins", "items", Pins.ToArray());
        var oldest = DateOnly.FromDateTime(DateTime.Now).AddDays(-ActivityDays);
        foreach (var (day, count) in Activity)
            if (day >= oldest && count > 0) cfg.SetValue("activity", day.ToString("yyyyMMdd"), count);
        _activityDirty = false;
        foreach (var (doc, time) in DocumentOpened)
            cfg.SetValue("recent_documents", doc.ToString("N"), time);
        if (HasWindowState)
        {
            cfg.SetValue(WindowSection, "size", WindowSize);
            cfg.SetValue(WindowSection, "position", WindowPosition);
            cfg.SetValue(WindowSection, "maximized", WindowMaximized);
        }
        cfg.Save(FilePath);
    }
}
