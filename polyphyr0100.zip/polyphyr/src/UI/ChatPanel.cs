// The chat feature was removed. This file is intentionally empty and can be deleted
// (along with ChatPanel.cs.uid if Godot created one).
