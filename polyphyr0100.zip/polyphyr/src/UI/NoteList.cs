using System;
using System.Collections.Generic;
using Godot;

namespace Polyphyr.UI;

/// <summary>
/// The notes sidebar list. Custom-drawn so hover and selection highlights can fade
/// (quick fade in, slightly slower fade out) instead of snapping like Godot's ItemList.
/// Only visible rows are drawn, and text layouts are cached per row.
/// </summary>
public partial class NoteList : Control
{
    private const float RowHeight = 32f;
    private const float RowGap = 2f;
    private const float Pitch = RowHeight + RowGap;
    private const float PadX = 10f;
    private const float FadeIn = 0.08f;
    private const float FadeOut = 0.16f;

    /// <summary>Left-click or keyboard selection of a row.</summary>
    public event Action<int>? ItemActivated;
    /// <summary>Right-click on a row, with the local mouse position.</summary>
    public event Action<int, Vector2>? ItemContextRequested;

    private readonly List<string> _titles = new();
    private readonly List<TextLine?> _lines = new();
    private readonly List<float> _hover = new();
    private readonly List<float> _sel = new();
    private int _selected = -1;
    private int _hovered = -1;
    private float _scroll;
    private ScrollGlide _glide;
    private float _lineWidth = -1f;
    private bool _syncing;

    private VScrollBar _vbar = null!;
    private readonly StyleBoxFlat _hoverBox = AppTheme.Box(AppTheme.Raised);
    private readonly StyleBoxFlat _selBox = AppTheme.Box(AppTheme.Active);

    public int Count => _titles.Count;
    public int Selected => _selected;

    public override void _Ready()
    {
        FocusMode = FocusModeEnum.Click;
        ClipContents = true;
        MouseDefaultCursorShape = CursorShape.PointingHand;

        _vbar = new VScrollBar { MouseDefaultCursorShape = CursorShape.Arrow };
        AddChild(_vbar, false, InternalMode.Front);
        _vbar.SetAnchorsAndOffsetsPreset(LayoutPreset.RightWide);
        _vbar.OffsetLeft = -8;
        _vbar.ValueChanged += value =>
        {
            if (_syncing) return;
            _glide.Stop();
            _scroll = (float)value;
            QueueRedraw();
        };
        SetProcess(false);
    }

    /// <summary>Replaces the rows. The selected row appears highlighted immediately, without a fade.</summary>
    public void SetItems(IReadOnlyList<string> titles, int selected)
    {
        _titles.Clear();
        _titles.AddRange(titles);
        _lines.Clear();
        _hover.Clear();
        _sel.Clear();
        if (_hovered >= _titles.Count) _hovered = -1;
        for (int i = 0; i < _titles.Count; i++)
        {
            _lines.Add(null);
            _hover.Add(i == _hovered ? 1f : 0f);
            _sel.Add(i == selected ? 1f : 0f);
        }
        _selected = selected;
        QueueRedraw();
    }

    /// <summary>Moves the selection highlight (with a fade) and scrolls the row into view.</summary>
    public void Select(int index)
    {
        if (index == _selected) return;
        _selected = index;
        EnsureVisible(index);
        SetProcess(true);
        QueueRedraw();
    }

    // ------------------------------------------------------------------

    private float ListWidth => Size.X - (_vbar.Visible ? 10f : 0f);

    /// <summary>A row's rectangle in this control's coordinates (after scrolling).</summary>
    public Rect2 RowRect(int index) => new(0, index * Pitch - _scroll, ListWidth, RowHeight);

    private int RowAt(Vector2 pos)
    {
        if (pos.X < 0 || pos.X > ListWidth) return -1;
        float y = pos.Y + _scroll;
        if (y < 0) return -1;
        int i = (int)(y / Pitch);
        if (i >= _titles.Count || y - i * Pitch > RowHeight) return -1;
        return i;
    }

    private void EnsureVisible(int index)
    {
        if (index < 0) return;
        _glide.Stop();
        float top = index * Pitch;
        if (top < _scroll) _scroll = top;
        else if (top + RowHeight > _scroll + Size.Y) _scroll = top + RowHeight - Size.Y;
        SyncScrollbar();
    }

    private void SyncScrollbar()
    {
        float content = _titles.Count * Pitch;
        _scroll = Mathf.Clamp(_scroll, 0f, Mathf.Max(0f, content - Size.Y));
        _syncing = true;
        _vbar.MaxValue = content;
        _vbar.Page = Size.Y;
        _vbar.Value = _scroll;
        _vbar.Visible = content > Size.Y + 1f;
        _syncing = false;
    }

    private static float Approach(float value, float target, float dt)
        => value < target ? Mathf.Min(target, value + dt / FadeIn) : Mathf.Max(target, value - dt / FadeOut);

    public override void _Process(double delta)
    {
        float dt = (float)delta;
        bool animating = false;
        if (_glide.Active)
        {
            _scroll = _glide.Step(_scroll, dt);
            SyncScrollbar();
            var mouse = GetLocalMousePosition();
            if (new Rect2(Vector2.Zero, Size).HasPoint(mouse)) SetHovered(RowAt(mouse));
            animating |= _glide.Active;
        }
        for (int i = 0; i < _titles.Count; i++)
        {
            float th = i == _hovered ? 1f : 0f;
            float ts = i == _selected ? 1f : 0f;
            _hover[i] = Approach(_hover[i], th, dt);
            _sel[i] = Approach(_sel[i], ts, dt);
            animating |= _hover[i] != th || _sel[i] != ts;
        }
        QueueRedraw();
        if (!animating) SetProcess(false);
    }

    public override void _Draw()
    {
        SyncScrollbar();
        float width = ListWidth;
        if (width != _lineWidth)
        {
            _lineWidth = width;
            for (int i = 0; i < _lines.Count; i++) _lines[i] = null;
        }

        var canvas = GetCanvasItem();
        int first = Math.Max(0, (int)(_scroll / Pitch));
        for (int i = first; i < _titles.Count; i++)
        {
            float y = i * Pitch - _scroll;
            if (y > Size.Y) break;
            var rect = new Rect2(0, y, width, RowHeight);

            float sel = _sel[i];
            if (sel > 0.001f)
            {
                _selBox.BgColor = new Color(AppTheme.Active, sel);
                _selBox.Draw(canvas, rect);
            }
            float hover = _hover[i] * (1f - sel);
            if (hover > 0.001f)
            {
                _hoverBox.BgColor = new Color(AppTheme.Raised, hover);
                _hoverBox.Draw(canvas, rect);
            }

            var line = _lines[i] ??= MakeLine(_titles[i], width - PadX * 2f);
            float emphasis = Mathf.Max(_hover[i], sel);
            var color = AppTheme.TextDim.Lerp(AppTheme.Text, emphasis);
            line.Draw(canvas, new Vector2(PadX, y + (RowHeight - line.GetSize().Y) * 0.5f), color);
        }
    }

    private static TextLine MakeLine(string text, float width)
    {
        var line = new TextLine
        {
            Width = Mathf.Max(10f, width),
            TextOverrunBehavior = TextServer.OverrunBehavior.TrimEllipsis,
        };
        line.AddString(text, AppFonts.Regular, AppTheme.FontSize);
        return line;
    }

    // ------------------------------------------------------------------

    public override void _GuiInput(InputEvent @event)
    {
        switch (@event)
        {
            case InputEventMouseMotion mm:
                SetHovered(RowAt(mm.Position));
                break;

            case InputEventMouseButton { Pressed: true } mb:
                if (mb.ButtonIndex is MouseButton.WheelUp or MouseButton.WheelDown)
                {
                    float factor = mb.Factor > 0 ? mb.Factor : 1f;
                    _glide.Push(_scroll, (mb.ButtonIndex == MouseButton.WheelUp ? -1f : 1f) * Pitch * 3f * factor,
                        _titles.Count * Pitch - Size.Y);
                    SetProcess(true);
                    AcceptEvent();
                    break;
                }
                int row = RowAt(mb.Position);
                if (row < 0) break;
                if (mb.ButtonIndex == MouseButton.Left)
                {
                    Select(row);
                    ItemActivated?.Invoke(row);
                    AcceptEvent();
                }
                else if (mb.ButtonIndex == MouseButton.Right)
                {
                    ItemContextRequested?.Invoke(row, mb.Position);
                    AcceptEvent();
                }
                break;

            case InputEventKey { Pressed: true } key when _titles.Count > 0:
                int next = key.Keycode switch
                {
                    Key.Up => Math.Max(0, _selected - 1),
                    Key.Down => Math.Min(_titles.Count - 1, _selected + 1),
                    _ => -1,
                };
                if (next < 0 || next == _selected) break;
                Select(next);
                ItemActivated?.Invoke(next);
                AcceptEvent();
                break;
        }
    }

    private void SetHovered(int row)
    {
        if (row == _hovered) return;
        _hovered = row;
        SetProcess(true);
    }

    public override void _Notification(int what)
    {
        switch ((long)what)
        {
            case NotificationMouseExit:
                SetHovered(-1);
                break;
            case NotificationResized:
                QueueRedraw();
                break;
        }
    }
}
