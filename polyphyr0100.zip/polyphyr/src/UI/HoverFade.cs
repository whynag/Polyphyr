using Godot;

namespace Polyphyr.UI;

/// <summary>
/// Gives every button a hover highlight that fades in quickly and out a little slower,
/// instead of snapping. Installed once; it attaches itself to each button as it's created.
/// </summary>
public static class HoverFade
{
    public const float FadeIn = 0.08f;
    public const float FadeOut = 0.16f;
    private const string MetaKey = "_hover_fade";

    private static bool _installed;

    public static void Install(SceneTree tree)
    {
        // Once per run: the main scene is reloaded when switching light/dark mode.
        if (_installed) return;
        _installed = true;
        tree.NodeAdded += node =>
        {
            if (node is BaseButton button)
                Callable.From(() => Attach(button)).CallDeferred();
        };
    }

    /// <summary>Stops the automatic fade from being added to this control (call before it enters the tree).</summary>
    public static void OptOut(Control control) => control.SetMeta(MetaKey, true);

    public static void Attach(Control control, int radius = AppTheme.Radius, float strength = HoverOverlay.DefaultStrength)
    {
        if (!GodotObject.IsInstanceValid(control) || control.HasMeta(MetaKey)) return;
        control.SetMeta(MetaKey, true);

        var overlay = new HoverOverlay(radius, strength);
        control.AddChild(overlay, false, Node.InternalMode.Front);
        overlay.SetAnchorsAndOffsetsPreset(Control.LayoutPreset.FullRect);

        control.MouseEntered += () =>
        {
            if (control is BaseButton { Disabled: true }) return;
            overlay.FadeTo(1f, FadeIn);
        };
        control.MouseExited += () => overlay.FadeTo(0f, FadeOut);
    }
}

/// <summary>A faint rounded highlight laid over a control; its opacity is animated.</summary>
public partial class HoverOverlay : Panel
{
    private Tween? _tween;

    public const float DefaultStrength = 0.06f;

    public HoverOverlay() : this(AppTheme.Radius) { }

    public HoverOverlay(int radius, float strength = DefaultStrength)
    {
        MouseFilter = MouseFilterEnum.Ignore;
        Modulate = new Color(1, 1, 1, 0);
        AddThemeStyleboxOverride("panel", AppTheme.Box(new Color(AppTheme.Overlay, strength), radius));
    }

    public void FadeTo(float alpha, float seconds)
    {
        _tween?.Kill();
        _tween = CreateTween();
        _tween.TweenProperty(this, "modulate:a", alpha, seconds)
            .SetTrans(Tween.TransitionType.Sine)
            .SetEase(Tween.EaseType.Out);
    }
}
