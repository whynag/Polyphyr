using System;
using System.Collections.Generic;
using Godot;

namespace Polyphyr.UI;

/// <summary>
/// One thin bar split by how many tasks are in each standard status, with a small legend under it.
/// The custom status is left out.
/// </summary>
public partial class StatusBar : Control
{
    public readonly record struct Segment(string Name, int Count, Color Color);

    /// <summary>The empty part of the bar: only just lighter than the page.</summary>
    private static Color TrackColor => AppTheme.Track;

    public static Color NoneColor => AppTheme.Pick("4a4a4f", "d0d0cf");
    public static Color IdeaColor => AppTheme.Pick("919196", "a0a6b0");
    public static Color ToDoColor => AppTheme.Pick("cdcdcf", "6b7380");
    public static Color InProgressColor => AppTheme.Pick("4f8cff", "3d6fe6");
    public static Color CompletedColor => AppTheme.Pick("3fb950", "2f9e44");

    private const float BarHeight = 8f, LegendTop = 20f, Gap = 2f;
    private IReadOnlyList<Segment> _segments = Array.Empty<Segment>();
    private readonly List<(Rect2 Rect, Segment Segment)> _hit = new();

    public StatusBar()
    {
        CustomMinimumSize = new Vector2(0, 40);
        MouseFilter = MouseFilterEnum.Pass;
        TooltipText = " ";
    }

    public void SetSegments(IReadOnlyList<Segment> segments)
    {
        _segments = segments;
        QueueRedraw();
    }

    public override void _Draw()
    {
        _hit.Clear();
        int total = 0;
        foreach (var s in _segments) total += s.Count;

        // Track
        var track = new Rect2(0, 0, Size.X, BarHeight);
        DrawStyleBox(AppTheme.Box(TrackColor, 4), track);

        if (total > 0)
        {
            int shown = 0;
            foreach (var s in _segments) if (s.Count > 0) shown++;
            float usable = Size.X - Gap * Math.Max(0, shown - 1);
            float x = 0;
            int drawn = 0;
            foreach (var s in _segments)
            {
                if (s.Count == 0) continue;
                drawn++;
                float w = drawn == shown ? Size.X - x : Mathf.Round(usable * s.Count / total);
                var rect = new Rect2(x, 0, Mathf.Max(2f, w), BarHeight);
                var box = AppTheme.Box(s.Color, 0);
                // Round only the outer ends of the bar.
                if (drawn == 1) { box.CornerRadiusTopLeft = 4; box.CornerRadiusBottomLeft = 4; }
                if (drawn == shown) { box.CornerRadiusTopRight = 4; box.CornerRadiusBottomRight = 4; }
                DrawStyleBox(box, rect);
                _hit.Add((new Rect2(rect.Position, new Vector2(rect.Size.X, Size.Y)), s));
                x += w + Gap;
            }
        }

        // Legend: ● Idea 3   ● To-Do 5 ...
        var font = GetThemeDefaultFont();
        const int fontSize = 12;
        float lx = 0;
        float baseline = LegendTop + font.GetAscent(fontSize);
        foreach (var s in _segments)
        {
            // Statuses with no tasks are dimmed in the legend.
            DrawCircle(new Vector2(lx + 4, LegendTop + font.GetHeight(fontSize) * 0.5f), 3.5f, s.Count > 0 ? s.Color : new Color(s.Color, 0.3f));
            lx += 13;
            DrawString(font, new Vector2(lx, baseline), s.Name, HorizontalAlignment.Left, -1, fontSize, AppTheme.TextDim);
            lx += font.GetStringSize(s.Name + "  ", HorizontalAlignment.Left, -1, fontSize).X;
            string count = s.Count.ToString();
            DrawString(font, new Vector2(lx, baseline), count, HorizontalAlignment.Left, -1, fontSize, AppTheme.TextFaint);
            lx += font.GetStringSize(count, HorizontalAlignment.Left, -1, fontSize).X + 22;
        }
    }

    public override string _GetTooltip(Vector2 atPosition)
    {
        if (atPosition.Y > BarHeight + 4) return "";
        foreach (var (rect, s) in _hit)
            if (rect.HasPoint(atPosition)) return s.Count == 1 ? $"{s.Name}: 1 task" : $"{s.Name}: {s.Count} tasks";
        return "";
    }
}

/// <summary>
/// Calendar-style grid of the current quarter: one row per week (Monday to Sunday left to right),
/// from the week containing the quarter's first day to the week containing its last.
/// Days in those weeks that fall outside the quarter are dimmed; days still to come are left empty.
/// </summary>
public partial class ActivityHeatmap : Control
{
    private const float Cell = 11f, Gap = 3f;
    private const float OutsideAlpha = 0.3f;

    private Func<DateOnly, int> _countFor = _ => 0;
    private DateOnly _today;
    private DateOnly _quarterStart, _quarterEnd;
    private DateOnly _gridStart;
    private int _weeks = 13;
    private int _max = 1;

    /// <summary>1–4 for the quarter currently shown.</summary>
    public int Quarter { get; private set; } = 1;

    public ActivityHeatmap()
    {
        MouseFilter = MouseFilterEnum.Pass;
        TooltipText = " ";
        UpdateSize();
    }

    private void UpdateSize() => CustomMinimumSize = new Vector2(7 * (Cell + Gap) - Gap, _weeks * (Cell + Gap) - Gap);

    private static DateOnly MondayOf(DateOnly day) => day.AddDays(-(((int)day.DayOfWeek + 6) % 7));

    public void SetData(Func<DateOnly, int> countFor)
    {
        _countFor = countFor;
        _today = DateOnly.FromDateTime(DateTime.Now);
        Quarter = (_today.Month - 1) / 3 + 1;
        _quarterStart = new DateOnly(_today.Year, (Quarter - 1) * 3 + 1, 1);
        _quarterEnd = _quarterStart.AddMonths(3).AddDays(-1);
        _gridStart = MondayOf(_quarterStart);
        _weeks = (MondayOf(_quarterEnd).DayNumber - _gridStart.DayNumber) / 7 + 1;
        UpdateSize();

        _max = 1;
        for (var d = _gridStart; d <= _today; d = d.AddDays(1)) _max = Math.Max(_max, countFor(d));
        QueueRedraw();
    }

    private static Color Empty => AppTheme.EmptyCell;

    private Color ColorFor(int count)
    {
        if (count <= 0) return Empty;
        float t = (float)count / _max;
        float alpha = t switch { <= 0.25f => 0.3f, <= 0.5f => 0.5f, <= 0.75f => 0.75f, _ => 1f };
        return new Color(StatusBar.InProgressColor, alpha);
    }

    private bool InQuarter(DateOnly day) => day >= _quarterStart && day <= _quarterEnd;

    public override void _Draw()
    {
        for (int w = 0; w < _weeks; w++)
            for (int d = 0; d < 7; d++)
            {
                var day = _gridStart.AddDays(w * 7 + d);
                var rect = new Rect2(d * (Cell + Gap), w * (Cell + Gap), Cell, Cell);
                float alpha = InQuarter(day) ? 1f : OutsideAlpha;
                DrawStyleBox(AppTheme.Box(new Color(Empty, alpha), 2), rect);
                if (day > _today) continue;
                int count = _countFor(day);
                if (count <= 0) continue;
                var c = ColorFor(count);
                DrawStyleBox(AppTheme.Box(new Color(c, c.A * alpha), 2), rect);
            }
        // Ring today so it's easy to find.
        int index = _today.DayNumber - _gridStart.DayNumber;
        if (index >= 0 && index < _weeks * 7)
        {
            var r = new Rect2(index % 7 * (Cell + Gap), index / 7 * (Cell + Gap), Cell, Cell).Grow(1f);
            var ring = AppTheme.Box(new Color(0, 0, 0, 0), 3, 0, 0, new Color(AppTheme.Text, 0.55f), 1);
            DrawStyleBox(ring, r);
        }
    }

    public override string _GetTooltip(Vector2 atPosition)
    {
        int d = (int)(atPosition.X / (Cell + Gap));
        int w = (int)(atPosition.Y / (Cell + Gap));
        if (w < 0 || w >= _weeks || d < 0 || d >= 7) return "";
        var day = _gridStart.AddDays(w * 7 + d);
        string date = day.ToDateTime(TimeOnly.MinValue).ToString("ddd, MMM d");
        if (day > _today) return date;
        int count = _countFor(day);
        string what = count == 0 ? "No activity" : count == 1 ? "1 change" : $"{count} changes";
        return $"{what} on {date}";
    }
}

/// <summary>A small circled "i"; hover it to read its tooltip.</summary>
public partial class InfoIcon : Control
{
    public InfoIcon()
    {
        CustomMinimumSize = new Vector2(16, 16);
        MouseFilter = MouseFilterEnum.Stop;
        MouseDefaultCursorShape = CursorShape.Help;
        MouseEntered += QueueRedraw;
        MouseExited += QueueRedraw;
    }

    public override void _Draw()
    {
        bool hover = GetGlobalRect().HasPoint(GetGlobalMousePosition());
        var color = hover ? AppTheme.TextDim : AppTheme.TextFaint;
        var c = Size / 2;
        DrawArc(c, 6.5f, 0, Mathf.Tau, 32, color, 1.2f, true);
        DrawCircle(c + new Vector2(0, -3f), 1f, color);
        DrawLine(c + new Vector2(0, -0.5f), c + new Vector2(0, 3.5f), color, 1.5f, true);
    }
}
