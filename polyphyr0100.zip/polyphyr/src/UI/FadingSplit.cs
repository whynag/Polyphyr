using Godot;

namespace Polyphyr.UI;

/// <summary>
/// A horizontal split whose divider shows a small rounded handle that fades in on hover or drag
/// (same look as the notes sidebar), over a thin always-visible divider line.
/// Uses its first two child controls as the left and right panes.
/// </summary>
public partial class FadingSplit : HSplitContainer
{
    private float _alpha;
    private bool _dragging;
    private bool _mouseWasDown;
    private Rect2 _lastGap;
    private readonly StyleBoxFlat _style = AppTheme.Box(AppTheme.TextDim, 2);

    private bool TryGetPanes(out Control left, out Control right)
    {
        left = null!;
        right = null!;
        int found = 0;
        foreach (var child in GetChildren())
        {
            if (child is not Control c || !c.Visible) continue;
            if (found == 0) left = c;
            else right = c;
            if (++found == 2) return true;
        }
        return false;
    }

    private Rect2 GapRect(Control left, Control right)
    {
        float l = left.Position.X + left.Size.X;
        float r = right.Position.X;
        return new Rect2(l, 0, Mathf.Max(1f, r - l), Size.Y);
    }

    public override void _Process(double delta)
    {
        if (!IsVisibleInTree() || !TryGetPanes(out var left, out var right)) return;

        bool down = Input.IsMouseButtonPressed(MouseButton.Left);
        bool over = GapRect(left, right).Grow(2f).HasPoint(GetLocalMousePosition());
        if (down && !_mouseWasDown && over) _dragging = true;
        if (!down) _dragging = false;
        _mouseWasDown = down;

        // Redraw when the divider moves (dragging, window resize) so the line and handle follow it.
        var gap = GapRect(left, right);
        if (gap != _lastGap)
        {
            _lastGap = gap;
            QueueRedraw();
        }

        float target = over || _dragging ? 1f : 0f;
        if (_alpha == target) return;
        float dt = (float)delta;
        _alpha = target > _alpha
            ? Mathf.Min(target, _alpha + dt / HoverFade.FadeIn)
            : Mathf.Max(target, _alpha - dt / HoverFade.FadeOut);
        QueueRedraw();
    }

    /// <summary>Draw a faint full-height line in the middle of the gap.</summary>
    public bool ShowDivider { get; set; } = true;

    public override void _Draw()
    {
        if (!TryGetPanes(out var left, out var right)) return;
        var gap = GapRect(left, right);
        if (ShowDivider)
        {
            float x = Mathf.Round(gap.Position.X + gap.Size.X * 0.5f) + 0.5f;
            DrawLine(new Vector2(x, 0), new Vector2(x, Size.Y), AppTheme.Border, 1f);
        }
        if (_alpha <= 0.001f) return;
        const float width = 4f, height = 44f;
        var rect = new Rect2(gap.Position.X + (gap.Size.X - width) * 0.5f, (Size.Y - height) * 0.5f, width, height);
        _style.BgColor = new Color(_dragging ? AppTheme.Text : AppTheme.TextDim, 0.85f * _alpha);
        _style.Draw(GetCanvasItem(), rect);
    }
}
